#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "characters.h"

int main(int argc, char *argv[])
{
  int c, row, col, block, width, height, new_width, max_luminance, luminance;
  char buffer[64];
  char *code_table;
  unsigned char *data;

  srandom(time(NULL));

  /* Check for the PGM ASCII header. */
  fgets(buffer, 4, stdin);
  if (strncmp(buffer, "P2\n", 3) != 0) {
    fprintf(stderr, "%s: error: incorrect header\n", argv[0]);
    exit(EXIT_FAILURE);
  }

  /* Read away any comments. */
  while (1) {
    c = fgetc(stdin);
    if (c != '#') {
      ungetc(c, stdin);
      break;
    } else {
      while ((c = fgetc(stdin)) != EOF) {
        if (c == '\n')
          break;
      }
    }
  }

  fgets(buffer, sizeof(buffer), stdin);
  if (sscanf(buffer, "%d %d\n", &width, &height) != 2) {
    fprintf(stderr, "%s: error: expected picture dimensions\n", argv[0]);
    exit(EXIT_FAILURE);
  }

  fgets(buffer, sizeof(buffer), stdin);
  if (sscanf(buffer, "%d\n", &max_luminance) != 1) {
    fprintf(stderr, "%s: error: expected max luminance value\n", argv[0]);
    exit(EXIT_FAILURE);
  }

  /* Calculate the new width needed to cover block (font width) boundaries. */
  if (width % CHAR_WIDTH == 0)
    new_width = width;
  else
    new_width = width + (CHAR_WIDTH - (width % CHAR_WIDTH));

  /* Allocate space for 20 scanlines. */
  data = (unsigned char *)malloc(sizeof(char) * new_width * CHAR_HEIGHT);

  if (data == NULL) {
    fprintf(stderr, "%s: error: malloc() failed\n", argv[0]);
    exit(EXIT_FAILURE);
  }

  /* Output "new" PGM header. */
  printf("P2\n%d %d\n%d\n",
    new_width, (height % CHAR_HEIGHT == 0) ? height :
      height + (CHAR_HEIGHT - (height % CHAR_HEIGHT)), max_luminance);

  /* Read 20 scanlines at a time, process data, and continue until done. */
  while (height > 0) {

    row = col = 0;
    while (scanf("%d", &luminance) > 0) {
      *(data + col + (row * new_width)) = luminance;

      col++;
      if (col >= width) {
        col = 0;
        row++;
        if (row >= CHAR_HEIGHT || row == height)
          break; /* Enough, process the information. */
      }
    }
    height -= CHAR_HEIGHT;

    /* Go trough all "blocks" of 10 pixels, and process them. */
    for (block = 0; block < new_width / CHAR_WIDTH; block++) {

      /* Find average luminance for block. */
      luminance = 0;
      for (row = 0; row < CHAR_HEIGHT; row++) {
        if (row >= (height + CHAR_HEIGHT))
          break; /* Stop on the last set of scanlines's last row. */
        for (col = 0; col < CHAR_WIDTH; col++) {
          if ((block * CHAR_WIDTH + col) >= width)
            break; /* Stop on the last block's last column. */
          luminance += *(data + col + (block * CHAR_WIDTH) +
            (row * new_width));
        }
      }

      luminance /= (row * col);

      while ((code_table = translation[random() % CHAR_AMOUNT]) == NULL)
        ;

      for (row = 0; row < CHAR_HEIGHT; row++) {
        for (col = 0; col < CHAR_WIDTH; col++) {
          if (*(code_table + col + (row * CHAR_WIDTH)))
            *(data + col + (block * CHAR_WIDTH) +
              (row * new_width)) = 0;
          else
            *(data + col + (block * CHAR_WIDTH) +
              (row * new_width)) = luminance;
        }
      }
    }

    /* Output the finished blocks. */
    for (row = 0; row < CHAR_HEIGHT; row++) {
      for (col = 0; col < new_width; col++) {
        printf("%d ", *(data + col + (row * new_width)));
      }
      printf("\n");
    }
  }

  return EXIT_SUCCESS;
}

