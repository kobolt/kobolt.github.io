/* TinyBasic (Program line functions header file.)
 * Version 0.1 (13/09-08)
 * Copyright 2008 Kjetil Erga (kobolt.anarion -AT- gmail -DOT- com)
 *
 *
 * This file is part of TinyBasic.
 *
 * TinyBasic is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * TinyBasic is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with TinyBasic. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _TB_PRG_H
#define _TB_PRG_H

#include "tb-ast.h"
#include <stdio.h> /* FILE definition. */

typedef enum {
  PRG_JUMP_NONE,
  PRG_JUMP_NORMAL,
  PRG_JUMP_POP,
  PRG_JUMP_PUSH,
  PRG_JUMP_END,
} prg_jump_flag_t;

void prg_add_line(int line_number, ast_node_t *statement);
void prg_free(void);
void prg_tree_print(void);
void prg_list_print(FILE *fh);
void prg_exec(void);
void prg_jump(unsigned int line_number, prg_jump_flag_t flag);
void prg_init(void);

#endif /* _TB_PRG_H */
