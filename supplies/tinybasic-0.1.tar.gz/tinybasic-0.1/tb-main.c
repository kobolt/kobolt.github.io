/* TinyBasic (Main program entry.)
 * Version 0.1 (13/09-08)
 * Copyright 2008 Kjetil Erga (kobolt.anarion -AT- gmail -DOT- com)
 *
 *
 * This file is part of TinyBasic.
 *
 * TinyBasic is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * TinyBasic is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with TinyBasic. If not, see <http://www.gnu.org/licenses/>.
 */

#include "tb-ast.h"
#include "tb-prg.h"
#include <stdlib.h> /* For NULL definition. */
#include <stdio.h>

extern int yyparse();

int main(int argc, char *argv[])
{
  ast_node_t *temp_ast;

  atexit(prg_free);
  ast_init();
  prg_init();

  if (argc >= 2) {
    /* Cool hack: Generate a small AST with a load instruction,
       to start the lexer and parser from there directly. */
    temp_ast = ast_add_node_sub(AST_LOAD, ast_add_node_string(AST_STRING,
      NULL, argv[1]));
    ast_exec(temp_ast);
    ast_free(temp_ast);
    prg_exec();
  } else {
    /* Start lexer and parser to read BASIC instructions from standard in. */
    if (yyparse() > 0)
      return 1;
  }

  return 0;
}

