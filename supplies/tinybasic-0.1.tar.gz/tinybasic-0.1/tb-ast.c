/* TinyBasic (AST functions.)
 * Version 0.1 (13/09-08)
 * Copyright 2008 Kjetil Erga (kobolt.anarion -AT- gmail -DOT- com)
 *
 *
 * This file is part of TinyBasic.
 *
 * TinyBasic is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * TinyBasic is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with TinyBasic. If not, see <http://www.gnu.org/licenses/>.
 */

#include "tb-ast.h"
#include "tb-prg.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <errno.h>
#include <sys/wait.h> /* WEXITSTATUS() */



#define MAX_VARIABLES 26 /* A-Z */



extern int yyparse();
extern void lex_file_read_start(FILE *);
extern void lex_file_read_stop(void);

static int ast_variables[MAX_VARIABLES];



void ast_init(void)
{
  int i;
  for (i = 0; i < MAX_VARIABLES; i++) {
    ast_variables[i] = 0;
  }

  srandom(time(NULL));
}



static void ast_variable_set(char var, int value)
{
  if (isupper(var)) {
    ast_variables[var - 0x41] = value;
  } else if (islower(var)) {
    ast_variables[var - 0x61] = value;
  } else {
    fprintf(stderr, "%s: error: invalid variable: %c\n", __FILE__, var);
    exit(1);
  }
}



static int ast_variable_get(char var)
{
  if (isupper(var)) {
    return ast_variables[var - 0x41];
  } else if (islower(var)) {
    return ast_variables[var - 0x61];
  } else {
    fprintf(stderr, "%s: error: invalid variable: %c\n", __FILE__, var);
    exit(1);
  }
}



/* Note: Standard code block for code-reuse. */
#define AST_ALLOC() \
  ast_node_t *p; \
  p = malloc(sizeof(ast_node_t)); \
  if (p == NULL) { \
    fprintf(stderr, "%s: error: out of memory.\n", __FILE__); \
    exit(1); \
  } \
  p->type = type; \
  p->sub_node = NULL;



ast_node_t *ast_add_node_leaf(ast_node_type_t type)
{
  AST_ALLOC()
  return p;
}



ast_node_t *ast_add_node_sub(ast_node_type_t type, void *node)
{
  AST_ALLOC()
  p->sub_node = node;
  return p;
}



ast_node_t *ast_add_node_expr(ast_node_type_t type, void *sub_node,
  void *expr_node)
{
  AST_ALLOC()
  p->sub_node = sub_node;
  p->expr_node = expr_node;
  return p;
}



ast_node_t *ast_add_node_complex(ast_node_type_t type, void *sub_node,
  void *expr_node, void *extra_node_1, void *extra_node_2)
{
  AST_ALLOC()
  p->sub_node = sub_node;
  p->expr_node = expr_node;
  p->extra_node_1 = extra_node_1;
  p->extra_node_2 = extra_node_2;
  return p;
}



ast_node_t *ast_add_node_var(ast_node_type_t type, void *sub_node, char var)
{
  AST_ALLOC()
  p->sub_node = sub_node;
  p->var = var;
  return p;
}



ast_node_t *ast_add_node_number(ast_node_type_t type, int number)
{
  AST_ALLOC()
  p->number = number;
  return p;
}



ast_node_t *ast_add_node_string(ast_node_type_t type, void *sub_node,
  char *string)
{
  AST_ALLOC()
  p->sub_node = sub_node;
  p->string = malloc(sizeof(char) * (strlen(string) + 1));
  if (p->string == NULL) {
    fprintf(stderr, "%s: error: out of memory.\n", __FILE__);
    exit(1);
  }
  memset(p->string, '\0', strlen(string) + 1);
  strncpy(p->string, string, strlen(string));
  return p;
}



void ast_free(ast_node_t *node)
{
  if (node == NULL)
    return;

  switch (node->type) {
  case AST_REM:
    free(node->string);
    break;

  case AST_VAR:
    if (node->sub_node != NULL)
      ast_free(node->sub_node);
    break;

  case AST_STRING:
    free(node->string);
    if (node->sub_node != NULL)
      ast_free(node->sub_node);
    break;

  case AST_IF:
    ast_free(node->sub_node);
    ast_free(node->expr_node);
    ast_free(node->extra_node_1);
    ast_free(node->extra_node_2);
    break;

  case AST_PRINT:
    ast_free(node->sub_node);
    break;
    
  case AST_GOTO:
    ast_free(node->sub_node);
    break;

  case AST_INPUT:
    ast_free(node->sub_node);
    break;
    
  case AST_LET:
    ast_free(node->sub_node);
    break;
    
  case AST_GOSUB:
    ast_free(node->sub_node);
    break;
    
  case AST_RND:
    ast_free(node->expr_node);
    break;

  case AST_USR:
    ast_free(node->expr_node);
    if (node->extra_node_1 != NULL)
      ast_free(node->extra_node_1);
    if (node->extra_node_2 != NULL)
      ast_free(node->extra_node_2);
    break;

  case AST_LOAD:
    ast_free(node->sub_node);
    break;

  case AST_SAVE:
    ast_free(node->sub_node);
    break;

  case AST_SYSTEM:
    free(node->string);
    break;
    
  case AST_EXPR:
    ast_free(node->expr_node);
    if (node->sub_node != NULL)
      ast_free(node->sub_node);
    break;
    
  case AST_PLUS:
    ast_free(node->expr_node);
    if (node->sub_node != NULL)
      ast_free(node->sub_node);
    break;
    
  case AST_MINUS:
    ast_free(node->expr_node);
    if (node->sub_node != NULL)
      ast_free(node->sub_node);
    break;

  case AST_MULTIPLY:
    ast_free(node->expr_node);
    ast_free(node->sub_node);
    break;

  case AST_DIVIDE:
    ast_free(node->expr_node);
    ast_free(node->sub_node);
    break;

  default:
    break; /* Nothing additional to free. */
  }

  free(node); /* Free the node itself before leaving. */
}



/* Note: This function is used mostly for debugging. */
void ast_tree_print(ast_node_t *node, int indent)
{
  int i;

  for (i = 0; i < indent; i++)
    printf("  ");

  if (node == NULL) {
    printf("(null)\n");
    return;
  }

  switch (node->type) {
  case AST_REM:
    printf("REM: \"%s\"\n", node->string);
    break;

  case AST_VAR:
    printf("VAR: %c\n", node->var);
    if (node->sub_node != NULL)
      ast_tree_print(node->sub_node, indent + 1);
    break;

  case AST_NUMBER:
    printf("NUMBER: %d\n", node->number);
    break;

  case AST_STRING:
    printf("STRING: \"%s\"\n", node->string);
    if (node->sub_node != NULL)
      ast_tree_print(node->sub_node, indent + 1);
    break;

  case AST_IF:
    printf("IF\n");
    ast_tree_print(node->sub_node, indent + 1);
    ast_tree_print(node->expr_node, indent + 1);
    ast_tree_print(node->extra_node_1, indent + 1);
    ast_tree_print(node->extra_node_2, indent + 1);
    break;

  case AST_PRINT:
    printf("PRINT\n");
    ast_tree_print(node->sub_node, indent + 1);
    break;
    
  case AST_GOTO:
    printf("GOTO\n");
    ast_tree_print(node->sub_node, indent + 1);
    break;

  case AST_INPUT:
    printf("INPUT\n");
    ast_tree_print(node->sub_node, indent + 1);
    break;
    
  case AST_LET:
    printf("LET: %c\n", node->var);
    ast_tree_print(node->sub_node, indent + 1);
    break;
    
  case AST_GOSUB:
    printf("GOSUB\n");
    ast_tree_print(node->sub_node, indent + 1);
    break;
    
  case AST_RETURN:
    printf("RETURN\n");
    break;
    
  case AST_CLEAR:
    printf("CLEAR\n");
    break;
    
  case AST_LIST:
    printf("LIST\n");
    break;
    
  case AST_RUN:
    printf("RUN\n");
    break;
    
  case AST_END:
    printf("END\n");
    break;
    
  case AST_RND:
    printf("RND\n");
    ast_tree_print(node->expr_node, indent + 1);
    break;

  case AST_USR:
    printf("USR\n");
    ast_tree_print(node->expr_node, indent + 1);
    if (node->extra_node_1 != NULL)
      ast_tree_print(node->extra_node_1, indent + 1);
    if (node->extra_node_2 != NULL)
      ast_tree_print(node->extra_node_2, indent + 1);
    break;

  case AST_SYSTEM:
    printf("SYSTEM\n");
    ast_tree_print(node->sub_node, indent + 1);
    break;

  case AST_LOAD:
    printf("LOAD\n");
    ast_tree_print(node->sub_node, indent + 1);
    break;

  case AST_SAVE:
    printf("SAVE\n");
    ast_tree_print(node->sub_node, indent + 1);
    break;

  case AST_TREELIST:
    printf("TREELIST\n");
    break;

  case AST_EXPR:
    printf("EXPR\n");
    ast_tree_print(node->expr_node, indent + 1);
    if (node->sub_node != NULL)
      ast_tree_print(node->sub_node, indent + 1);
    break;
    
  case AST_PLUS:
    printf("PLUS\n");
    ast_tree_print(node->expr_node, indent + 1);
    if (node->sub_node != NULL)
      ast_tree_print(node->sub_node, indent + 1);
    break;
    
  case AST_MINUS:
    printf("MINUS\n");
    ast_tree_print(node->expr_node, indent + 1);
    if (node->sub_node != NULL)
      ast_tree_print(node->sub_node, indent + 1);
    break;

  case AST_MULTIPLY:
    printf("MULTIPLY\n");
    ast_tree_print(node->expr_node, indent + 1);
    ast_tree_print(node->sub_node, indent + 1);
    break;

  case AST_DIVIDE:
    printf("DIVIDE\n");
    ast_tree_print(node->expr_node, indent + 1);
    ast_tree_print(node->sub_node, indent + 1);
    break;

  case AST_EQ:
    printf("EQ\n");
    break;

  case AST_NE:
    printf("NE\n");
    break;

  case AST_LT:
    printf("LT\n");
    break;

  case AST_LE:
    printf("LE\n");
    break;

  case AST_GT:
    printf("GT\n");
    break;

  case AST_GE:
    printf("GE\n");
    break;

  default:
    printf("(unknown)\n");
    break;
  }
}



void ast_list_print(ast_node_t *node, FILE *fh)
{
  if (node == NULL)
    return;

  switch (node->type) {
  case AST_REM:
    fprintf(fh, "REM%s", node->string);
    break;

  case AST_VAR:
    if (node->sub_node != NULL)
      ast_list_print(node->sub_node, fh);
    fprintf(fh, "%c", toupper(node->var));
    break;

  case AST_NUMBER:
    fprintf(fh, "%d", node->number);
    break;

  case AST_STRING:
    if (node->sub_node != NULL)
      ast_list_print(node->sub_node, fh);
    fprintf(fh, "\"%s\"", node->string);
    break;

  case AST_IF:
    fprintf(fh, "IF ");
    ast_list_print(node->expr_node, fh);
    ast_list_print(node->extra_node_1, fh);
    ast_list_print(node->extra_node_2, fh);
    fprintf(fh, " THEN ");
    ast_list_print(node->sub_node, fh);
    break;

  case AST_PRINT:
    fprintf(fh, "PRINT ");
    ast_list_print(node->sub_node, fh);
    break;
    
  case AST_GOTO:
    fprintf(fh, "GOTO ");
    ast_list_print(node->sub_node, fh);
    break;

  case AST_INPUT:
    fprintf(fh, "INPUT ");
    ast_list_print(node->sub_node, fh);
    break;
    
  case AST_LET:
    fprintf(fh, "LET %c = ", node->var);
    ast_list_print(node->sub_node, fh);
    break;
    
  case AST_GOSUB:
    fprintf(fh, "GOSUB ");
    ast_list_print(node->sub_node, fh);
    break;
    
  case AST_RETURN:
    fprintf(fh, "RETURN");
    break;
    
  case AST_CLEAR:
    fprintf(fh, "CLEAR");
    break;
    
  case AST_LIST:
    fprintf(fh, "LIST");
    break;
    
  case AST_RUN:
    fprintf(fh, "RUN");
    break;
    
  case AST_END:
    fprintf(fh, "END");
    break;
    
  case AST_RND:
    fprintf(fh, "RND(");
    ast_list_print(node->expr_node, fh);
    fprintf(fh, ")");
    break;

  case AST_USR:
    fprintf(fh, "USR(");
    ast_list_print(node->expr_node, fh);
    if (node->extra_node_1 != NULL) {
      fprintf(fh, ", ");
      ast_list_print(node->extra_node_1, fh);
    }
    if (node->extra_node_2 != NULL) {
      fprintf(fh, ", ");
      ast_list_print(node->extra_node_2, fh);
    }
    fprintf(fh, ")");
    break;

  case AST_SYSTEM:
    fprintf(fh, "SYSTEM(");
    ast_list_print(node->sub_node, fh);
    fprintf(fh, ")");
    break;

  case AST_LOAD:
    fprintf(fh, "LOAD ");
    ast_list_print(node->sub_node, fh);
    break;

  case AST_SAVE:
    fprintf(fh, "SAVE ");
    ast_list_print(node->sub_node, fh);
    break;

  case AST_TREELIST:
    fprintf(fh, "TREELIST");
    break;

  case AST_EXPR:
    if (node->sub_node == NULL) {
      ast_list_print(node->expr_node, fh);
      fprintf(fh, "; ");
    } else {
      ast_list_print(node->sub_node, fh);
      fprintf(fh, "; ");
      ast_list_print(node->expr_node, fh);
      fprintf(fh, "; ");
    }
    break;
    
  case AST_PLUS:
    if (node->sub_node == NULL) {
      fprintf(fh, "+");
      ast_list_print(node->expr_node, fh);
    } else {
      fprintf(fh, "(");
      ast_list_print(node->sub_node, fh);
      fprintf(fh, " + ");
      ast_list_print(node->expr_node, fh);
      fprintf(fh, ")");
    }
    break;
    
  case AST_MINUS:
    if (node->sub_node == NULL) {
      fprintf(fh, "-");
      ast_list_print(node->expr_node, fh);
    } else {
      fprintf(fh, "(");
      ast_list_print(node->sub_node, fh);
      fprintf(fh, " - ");
      ast_list_print(node->expr_node, fh);
      fprintf(fh, ")");
    }
    break;

  case AST_MULTIPLY:
    fprintf(fh, "(");
    ast_list_print(node->sub_node, fh);
    fprintf(fh, " * ");
    ast_list_print(node->expr_node, fh);
    fprintf(fh, ")");
    break;

  case AST_DIVIDE:
    fprintf(fh, "(");
    ast_list_print(node->sub_node, fh);
    fprintf(fh, " / ");
    ast_list_print(node->expr_node, fh);
    fprintf(fh, ")");
    break;

  case AST_EQ:
    fprintf(fh, " = ");
    break;

  case AST_NE:
    fprintf(fh, " <> ");
    break;

  case AST_LT:
    fprintf(fh, " < ");
    break;

  case AST_LE:
    fprintf(fh, " <= ");
    break;

  case AST_GT:
    fprintf(fh, " > ");
    break;

  case AST_GE:
    fprintf(fh, " >= ");
    break;

  default:
    break;
  }
}



static void ast_print_statement(ast_node_t *node)
{
  if (node != NULL) {
    if (node->sub_node != NULL)
      ast_print_statement(node->sub_node);

    if (node->type == AST_STRING)
      printf("%s", node->string);
    else if (node->type == AST_EXPR)
      printf("%d", ast_exec(node->expr_node));
  }
}



static void ast_input_statement(ast_node_t *node)
{
  char buffer[8];
  int number;

  if (node->sub_node != NULL)
    ast_input_statement(node->sub_node);

  printf("? ");
  fgets(buffer, 8, stdin);

  /* Check for variable name or number. */
  if (buffer[1] == '\n' && isupper(buffer[0])) {
    number = ast_variable_get(buffer[0]);
  } else if (buffer[1] == '\n' && islower(buffer[0])) {
    number = ast_variable_get(buffer[0]);
  } else {
    number = atoi(buffer);
  }

  ast_variable_set(node->var, number);
}



static void ast_load_statement(ast_node_t *node)
{
  FILE *fh;

  /* Recursively load all files given in list. */
  if (node->sub_node != NULL)
    ast_load_statement(node->sub_node);

  if (node->string == NULL)
    return;

  fh = fopen(node->string, "r");
  if (fh == NULL) {
    fprintf(stderr, "%s: error: cannot load '%s': %s\n",
      __FILE__, node->string, strerror(errno));
    exit(1);
  }

  lex_file_read_start(fh);
  if (yyparse() > 0) {
    lex_file_read_stop();
    fclose(fh);
    exit(1);
  }
  lex_file_read_stop();

  fclose(fh);
}



static void ast_save_statement(ast_node_t *node)
{
  FILE *fh;

  if (node == NULL) {
    prg_list_print(stdout);
  } else {
    if (node->string == NULL)
      return;

    if (node->sub_node != NULL) {
      fprintf(stderr, "%s: error: can only save to one file!\n", __FILE__);
      exit(1);
    }

    fh = fopen(node->string, "w");
    if (fh == NULL) {
      fprintf(stderr, "%s: error: cannot save '%s': %s\n",
        __FILE__, node->string, strerror(errno));
      exit(1);
    }

    prg_list_print(fh);
    fclose(fh);
  }
}



int ast_exec(ast_node_t *node)
{
  int status;

  if (node == NULL)
    return 0;

  switch (node->type) {
  case AST_REM:
    break; /* Ignore remarks. */

  case AST_VAR:
    return ast_variable_get(node->var);

  case AST_NUMBER:
    return node->number;

  case AST_IF:
    switch (((ast_node_t *)(node->extra_node_1))->type) {
    case AST_EQ:
      if (ast_exec(node->expr_node) == ast_exec(node->extra_node_2))
        ast_exec(node->sub_node);
      break;

    case AST_NE:
      if (ast_exec(node->expr_node) != ast_exec(node->extra_node_2))
        ast_exec(node->sub_node);
      break;
      
    case AST_LT:
      if (ast_exec(node->expr_node) < ast_exec(node->extra_node_2))
        ast_exec(node->sub_node);
      break;

    case AST_LE:
      if (ast_exec(node->expr_node) <= ast_exec(node->extra_node_2))
        ast_exec(node->sub_node);
      break;

    case AST_GT:
      if (ast_exec(node->expr_node) > ast_exec(node->extra_node_2))
        ast_exec(node->sub_node);
      break;

    case AST_GE:
      if (ast_exec(node->expr_node) >= ast_exec(node->extra_node_2))
        ast_exec(node->sub_node);
      break;

    default:
      break;
    }
    break;

  case AST_PRINT:
    ast_print_statement(node->sub_node);
    printf("\n");
    break;
    
  case AST_GOTO:
    prg_jump(ast_exec(node->sub_node), PRG_JUMP_NORMAL);
    break;

  case AST_INPUT:
    ast_input_statement(node->sub_node);
    break;
    
  case AST_LET:
    ast_variable_set(node->var, ast_exec(node->sub_node));
    break;
    
  case AST_GOSUB:
    prg_jump(ast_exec(node->sub_node), PRG_JUMP_PUSH);
    break;
    
  case AST_RETURN:
    prg_jump(0, PRG_JUMP_POP);
    break;
    
  case AST_CLEAR:
    /* Note: Need to abort program execution in case it is running,
       to prevent referencing freed memory. */
    prg_jump(0, PRG_JUMP_END);
    prg_free();
    break;
    
  case AST_LIST:
    ast_save_statement(NULL); /* NULL = Use standard out. */
    break;
    
  case AST_RUN:
    prg_exec();
    break;
    
  case AST_END:
    prg_jump(0, PRG_JUMP_END);
    break;
    
  case AST_RND:
    if (ast_exec(node->expr_node) == 0) {
      fprintf(stderr, "%s: warning: division by zero!\n", __FILE__);
      return 0;
    }
    return random() % ast_exec(node->expr_node);

  case AST_USR:
    /* This function is supposed to make a system calls in assembler for */
    /* 6800 or 6502 CPUs. This is obviously difficult to implement without */
    /* some kind of special knowledge... */
    fprintf(stderr, "%s: warning: USR() not implemented!\n", __FILE__);
    return 0;

  case AST_SYSTEM:
    /* This special function will do a normal C-like system() call */
    /* and return the exit status (return code) from the called command. */
    status = system(node->string);
    if (status == -1) {
      fprintf(stderr, "%s: warning: system command failed: %s\n",
        __FILE__, node->string);
      return 0;
    } else
      return WEXITSTATUS(status);

  case AST_LOAD:
    /* Note: Loading from a BASIC program is supported, in order to support
       a concept of "loadable modules". This also works when the program line
       with the LOAD instruction is replaced, because only the AST is freed,
       and not the element of the linked list in the program itself. */
    ast_load_statement(node->sub_node);
    break;

  case AST_SAVE:
    ast_save_statement(node->sub_node);
    break;

  case AST_TREELIST:
    prg_tree_print();
    break;

  case AST_EXPR:
    /* Note: If expr->node contains something, it is not executed. */
    return ast_exec(node->sub_node);
    
  case AST_PLUS:
    if (node->sub_node == NULL)
      return 0 + ast_exec(node->expr_node);
    return ast_exec(node->sub_node) + ast_exec(node->expr_node);
    
  case AST_MINUS:
    if (node->sub_node == NULL)
      return 0 - ast_exec(node->expr_node);
    return ast_exec(node->sub_node) - ast_exec(node->expr_node);

  case AST_MULTIPLY:
    return ast_exec(node->sub_node) * ast_exec(node->expr_node);

  case AST_DIVIDE:
    if (ast_exec(node->expr_node) == 0) {
      fprintf(stderr, "%s: warning: division by zero!\n", __FILE__);
      return 0;
    }
    return ast_exec(node->sub_node) / ast_exec(node->expr_node);

  default:
    fprintf(stderr, "%s: error: non-executable statement!\n", __FILE__);
    exit(1);
    break;
  }

  return 0;
}

