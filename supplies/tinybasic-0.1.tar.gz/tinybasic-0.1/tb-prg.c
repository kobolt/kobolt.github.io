/* TinyBasic (Program line functions.)
 * Version 0.1 (13/09-08)
 * Copyright 2008 Kjetil Erga (kobolt.anarion -AT- gmail -DOT- com)
 *
 *
 * This file is part of TinyBasic.
 *
 * TinyBasic is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * TinyBasic is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with TinyBasic. If not, see <http://www.gnu.org/licenses/>.
 */

#include "tb-prg.h"
#include "tb-ast.h"
#include <stdlib.h>
#include <stdio.h>



#define STACK_SIZE 64



typedef struct line_s {
  unsigned int number;
  ast_node_t *statement;
  struct line_s *next;
  struct line_s *prev;
} line_t;



static line_t *prg_program_start = NULL;
static int prg_stack_pointer = 0;
static line_t *prg_stack[STACK_SIZE];

static prg_jump_flag_t prg_jump_flag;
static unsigned int prg_jump_line_number;



void prg_jump(unsigned int line_number, prg_jump_flag_t flag)
{
  prg_jump_flag = flag;
  prg_jump_line_number = line_number;
}



void prg_init(void)
{
  prg_stack_pointer = 0;
}



static void prg_stack_push(line_t *line)
{
  prg_stack_pointer++;
  if (prg_stack_pointer >= STACK_SIZE) {
    fprintf(stderr, "%s: error: stack overflow!\n", __FILE__);
    exit(1);
  }
  prg_stack[prg_stack_pointer] = line;
}



static line_t *prg_stack_pop(void)
{
  prg_stack_pointer--;
  if (prg_stack_pointer < 0) {
    fprintf(stderr, "%s: error: stack underflow!\n", __FILE__);
    exit(1);
  }
  return prg_stack[prg_stack_pointer + 1];
}



static line_t *prg_allocate_new(int line_number, ast_node_t *statement)
{
  line_t *new;
  new = malloc(sizeof(line_t));
  if (new == NULL) {
    fprintf(stderr, "%s: error: out of memory!\n", __FILE__);
    exit(1);
  }
  new->number = line_number;
  new->statement = statement;
  return new;
}



void prg_add_line(int line_number, ast_node_t *statement)
{
  line_t *new, *current, *last;

  if (prg_program_start == NULL) {
    /* Add first statement to the program. */
    new = prg_allocate_new(line_number, statement);
    new->next = NULL;
    new->prev = NULL;
    prg_program_start = new;
    return;
  }

  /* Check where to place statement in program. */
  for (current = prg_program_start; current != NULL; current = current->next) {
    if (current->number == line_number) {
      if (statement == NULL) {
        /* Delete statement from program. */
        if (current == prg_program_start) {
          /* If the first statement is removed, program start changes. */
          prg_program_start = current->next;
        }

        if (current->prev != NULL) /* Only if not first statement. */
          current->prev->next = current->next;
        if (current->next != NULL) /* Only if not last statement. */
          current->next->prev = current->prev;

        ast_free(current->statement);
        free(current);
        return;

      } else {
        /* Replace statement. */
        ast_free(current->statement);
        current->statement = statement;
        return;

      }
    } else if (current->number > line_number) {
      /* Insert new statement in between lines. */
      if (statement == NULL)
        return;
      new = prg_allocate_new(line_number, statement);
      if (current->prev == NULL) {
        prg_program_start = new;
      } else {
        current->prev->next = new;
      }
      new->prev = current->prev;
      current->prev = new;
      new->next = current;
      return;

    }
    
    last = current; /* Always save the last one, in case the end is reached. */
  }

  /* Append new statement at the end of the program. */
  if (statement == NULL)
    return;
  new = prg_allocate_new(line_number, statement);
  new->next = NULL;
  new->prev = last;
  last->next = new;
}



void prg_free(void)
{
  line_t *current, *next;

  if (prg_program_start == NULL)
    return;

  current = prg_program_start;
  do {
    next = current->next;
    ast_free(current->statement);
    free(current);
    current = next;
  } while (current != NULL);

  prg_program_start = NULL;
}



void prg_tree_print(void)
{
  line_t *current;

  if (prg_program_start == NULL)
    return;

  for (current = prg_program_start; current != NULL; current = current->next) {
    printf("%d\n", current->number);
    ast_tree_print(current->statement, 1);
  }
}



void prg_list_print(FILE *fh)
{
  line_t *current;

  if (prg_program_start == NULL)
    return;

  for (current = prg_program_start; current != NULL; current = current->next) {
    fprintf(fh, "%d ", current->number);
    ast_list_print(current->statement, fh);
    fprintf(fh, "\n");
  }
}



static line_t *prg_find_line(int number)
{
  line_t *search;

  for (search = prg_program_start; search != NULL; search = search->next) {
    if (search->number == number)
      return search;
  }

  return NULL;
}



/* Note: It is possible to have a RUN instruction in the BASIC program.
   This will effectively put the program pointer back to the start.
   But it will eventually cause a stack overflow after successive calls,
   so this "feature" should be used with caution. */
void prg_exec(void)
{
  line_t *current;

  if (prg_program_start == NULL)
    return;

  current = prg_program_start;
  do {
    prg_jump_flag = PRG_JUMP_NONE;
    ast_exec(current->statement);

    switch (prg_jump_flag) {
    case PRG_JUMP_NONE:
      /* Standard program execution, continue with next. */
      current = current->next;
      break;

    case PRG_JUMP_NORMAL:
      current = prg_find_line(prg_jump_line_number);
      if (current == NULL) {
        fprintf(stderr, "%s: error: jump to unknown location: %d\n",
          __FILE__, prg_jump_line_number);
        exit(1);
      }
      break;

    case PRG_JUMP_POP:
      current = prg_stack_pop();
      break;

    case PRG_JUMP_PUSH:
      prg_stack_push(current->next);
      current = prg_find_line(prg_jump_line_number);
      if (current == NULL) {
        fprintf(stderr, "%s: error: jump to unknown location: %d\n",
          __FILE__, prg_jump_line_number);
        exit(1);
      }
      break;

    case PRG_JUMP_END:
      current = NULL;
      break;
    }

  } while (current != NULL);
}

