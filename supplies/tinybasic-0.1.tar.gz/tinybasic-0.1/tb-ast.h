/* TinyBasic (AST functions header file.)
 * Version 0.1 (13/09-08)
 * Copyright 2008 Kjetil Erga (kobolt.anarion -AT- gmail -DOT- com)
 *
 *
 * This file is part of TinyBasic.
 *
 * TinyBasic is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * TinyBasic is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with TinyBasic. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _TB_AST_H
#define _TB_AST_H

#include <stdio.h> /* FILE definition. */

typedef enum {
  AST_REM,
  AST_VAR,
  AST_NUMBER,
  AST_STRING,
  AST_IF,
  AST_PRINT,
  AST_GOTO,
  AST_INPUT,
  AST_LET,
  AST_GOSUB,
  AST_RETURN,
  AST_CLEAR,
  AST_LIST,
  AST_RUN,
  AST_END,
  AST_RND,
  AST_USR,
  AST_LOAD,
  AST_SAVE,
  AST_TREELIST,
  AST_SYSTEM,
  AST_EXPR,
  AST_PLUS,
  AST_MINUS,
  AST_MULTIPLY,
  AST_DIVIDE,
  AST_EQ,
  AST_NE,
  AST_LT,
  AST_LE,
  AST_GT,
  AST_GE,
} ast_node_type_t;

/* Generic node structure. (One size fits all.) */
typedef struct ast_node_s {
  ast_node_type_t type;
  void *sub_node;
  union {
    void *expr_node;
    char var;
    int number;
    char *string;
  };
  void *extra_node_1;
  void *extra_node_2;
} ast_node_t;

ast_node_t *ast_add_node_leaf(ast_node_type_t type);
ast_node_t *ast_add_node_sub(ast_node_type_t type, void *node);
ast_node_t *ast_add_node_expr(ast_node_type_t type, void *sub_node,
  void *expr_node);
ast_node_t *ast_add_node_complex(ast_node_type_t type, void *sub_node,
  void *expr_node, void *extra_node_1, void *extra_node_2);
ast_node_t *ast_add_node_var(ast_node_type_t type, void *sub_node, char var);
ast_node_t *ast_add_node_number(ast_node_type_t type, int number);
ast_node_t *ast_add_node_string(ast_node_type_t type, void *sub_node,
  char *string);

void ast_free(ast_node_t *node);
void ast_tree_print(ast_node_t *node, int indent);
void ast_list_print(ast_node_t *node, FILE *fh);
int ast_exec(ast_node_t *node);
void ast_init(void);

#endif /* _TB_AST_H */
