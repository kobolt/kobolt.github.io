#ifndef _AEGL_H
#define _AEGL_H

#include "pic.h"

void aegl_init(pic_t *pic);

#endif /* _AEGL_H */
