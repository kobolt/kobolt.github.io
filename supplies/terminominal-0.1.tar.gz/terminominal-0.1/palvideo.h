#ifndef _PALVIDEO_H
#define _PALVIDEO_H

int palvideo_init(void);
void palvideo_update(void);

#endif /* _PALVIDEO_H */
