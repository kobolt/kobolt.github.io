#ifndef _SDLGUI_H
#define _SDLGUI_H

int sdlgui_init(void);
void sdlgui_update(void);

#endif /* _SDLGUI_H */
