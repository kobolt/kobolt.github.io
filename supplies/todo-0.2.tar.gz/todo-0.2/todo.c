/* Simple Todo Application
 * Version 0.2 (30/06-08)
 * Copyright 2008 Kjetil Erga (kobolt.anarion -AT- gmail -DOT- com)
 * 
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <curses.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>



#define FIELD_DELIMITER '�'

#define STATUS_ACTIVE '.'
#define STATUS_PENDING ':'
#define STATUS_CLOSED '*'
#define STATUS_SEMI_CLOSED '/'
#define STATUS_ABORTED '-'

#define MAX_LINE_LENGTH 512
#define MAX_TOPIC_LENGTH 8
#define MAX_DESCRIPTION_LENGTH 256
#define MAX_WAIT_INFO_LENGTH 128
#define MAX_COMMAND_LENGTH 128



typedef struct list_entry_s {
  char status;
  char topic[MAX_TOPIC_LENGTH];
  char description[MAX_DESCRIPTION_LENGTH];
  char wait_info[MAX_WAIT_INFO_LENGTH];
  time_t created;
  time_t closed;
  struct list_entry_s *next;
} list_entry_t;



static list_entry_t *list_start;
static int selected_entry;
static int view_entry; /* Flag indicating that the entry is being viewed. */
static int scroll_offset;



static int load_list(FILE *fh)
{
  char line[MAX_LINE_LENGTH];
  char field[MAX_LINE_LENGTH];
  int i, n, field_no;
  list_entry_t *new, *current;

  while (fgets(line, MAX_LINE_LENGTH, fh) != NULL) {
    n = field_no = 0;

    if ((new = malloc(sizeof(list_entry_t))) == NULL) {
      fprintf(stderr, "Error: could not allocate memory for list entry.\n");
      return 1;
    }
    new->status = STATUS_PENDING;
    new->topic[0] = '\0';
    new->description[0] = '\0';
    new->wait_info[0] = '\0';
    new->created = 0;
    new->closed = 0;

    for (i = 0; i < strlen(line); i++) {
      if (line[i] == FIELD_DELIMITER || line[i] == '\n') {
        field[n] = '\0';
        switch (field_no) {
        case 0: /* status */
          new->status = field[0];
          break;

        case 1: /* topic */
          strncpy(new->topic, field, MAX_TOPIC_LENGTH);
          /* Make sure it is NULL-terminated. */
          new->topic[MAX_TOPIC_LENGTH - 1] = '\0';
          break;

        case 2: /* description */
          strncpy(new->description, field, MAX_DESCRIPTION_LENGTH);
          new->description[MAX_DESCRIPTION_LENGTH - 1] = '\0';
          break;

        case 3: /* wait info */
          strncpy(new->wait_info, field, MAX_WAIT_INFO_LENGTH);
          new->wait_info[MAX_WAIT_INFO_LENGTH - 1] = '\0';
          break;

        case 4: /* creation time */
          new->created = (time_t)atoi(field);
          break;

        case 5: /* closed time */
          new->closed = (time_t)atoi(field);
          break;

        }
        field_no++;
        n = 0;
      } else {
        field[n] = line[i];
        n++;
      }
    }

    new->next = NULL;

    if (list_start == NULL)
      list_start = new;
    else {
      for (current = list_start; current->next != NULL; current = current->next)
        ;
      current->next = new;
    }

  }

  return 0;
}



static int save_list(FILE *fh)
{
  list_entry_t *current;

  if (list_start == NULL)
    return 0;

  for (current = list_start; current != NULL; current = current->next) {
    fprintf(fh, "%c%c%s%c%s%c%s%c%d%c%d\n",
      current->status, FIELD_DELIMITER,
      current->topic, FIELD_DELIMITER,
      current->description, FIELD_DELIMITER,
      current->wait_info, FIELD_DELIMITER,
      (int)current->created, FIELD_DELIMITER,
      (int)current->closed);
  }

  return 0;
}



static void free_list(void)
{
  list_entry_t *current, *temp;

  if (list_start == NULL)
    return;

  for (current = list_start; current != NULL; ) {
    temp = current;
    current = current->next;
    free(temp);
  }
}



static int no_of_list_entries(void)
{
  list_entry_t *current;
  int n;

  if (list_start == NULL)
    return 0;

  n = 0;
  for (current = list_start; current != NULL; current = current->next) {
    n++;
  }
  return n;
}



static list_entry_t *entry_by_no(int no)
{
  list_entry_t *current;
  int n;

  if (list_start == NULL)
    return NULL;

  n = 0;
  for (current = list_start; current != NULL; current = current->next) {
    if (n == no)
      return current;
    n++;
  }

  return NULL;
}



static void update_screen(void)
{
  int i, maxy, maxx, entry_no, split, skip_counter;
  list_entry_t *current;
  
  getmaxyx(stdscr, maxy, maxx);

  erase(); /* erase() is flicker-free compared to clear(). */

  if (list_start == NULL)
    return;

  if (view_entry) {
    if ((current = entry_by_no(selected_entry)) != NULL) {
      attron(A_BOLD);
      mvprintw(0, 0, "Status : ");
      attroff(A_BOLD);
      switch(current->status) {
      case STATUS_ACTIVE:
        mvprintw(0, 9, "Active");
        break;
      case STATUS_PENDING:
        mvprintw(0, 9, "Pending");
        break;
      case STATUS_CLOSED:
        mvprintw(0, 9, "Closed");
        break;
      case STATUS_SEMI_CLOSED:
        mvprintw(0, 9, "Semi-Closed");
        break;
      case STATUS_ABORTED:
        mvprintw(0, 9, "Aborted");
        break;
      default:
        break;
      }

      attron(A_BOLD);
      mvprintw(1, 0, "Topic  : ");
      attroff(A_BOLD);
      mvprintw(1, 9, "%s", current->topic);

      attron(A_BOLD);
      mvprintw(2, 0, "Created: ");
      attroff(A_BOLD);
      mvprintw(2, 9, "%s", (current->created != 0)
        ? ctime(&current->created) : "-");
      
      attron(A_BOLD);
      mvprintw(3, 0, "Closed : ");
      attroff(A_BOLD);
      mvprintw(3, 9, "%s", (current->closed != 0)
        ? ctime(&current->closed) : "-");

      attron(A_BOLD);
      mvprintw(5, 0, "Description:");
      attroff(A_BOLD);
      mvprintw(6, 0, "%s", current->description);

      split = (strlen(current->description) / (float)maxx);
      attron(A_BOLD);
      mvprintw(8 + split, 0, "Waiting info:");
      attroff(A_BOLD);
      mvprintw(9 + split, 0, "%s", current->wait_info);
    }
    return;
  }

  skip_counter = entry_no = 0;
  for (current = list_start; current != NULL; current = current->next) {
    
    if (scroll_offset > skip_counter) {
      skip_counter++;
      continue;
    }

    if (entry_no == selected_entry - scroll_offset)
      attron(A_REVERSE);

    /* Fill blanks with attributes in mind. */
    for (i = 0; i < maxx; i++)
      mvaddch(entry_no, i, ' ');

    if (current->status != '\0')
      mvaddch(entry_no, 0, current->status);

    /* NOTE: mvprintw() used for other texts instead,
       because mvaddch() does not display ISO-8859-1 characters correctly. */
    for (i = 0; i < 5; i++) {
      if (current->topic[i] == '\0')
        break;
      mvprintw(entry_no, i + 2, "%c", current->topic[i]);
    }

    split = ((maxx - 8) / 100.0) * 70;
    for (i = 0; i < split - 1; i++) {
      if (current->description[i] == '\0')
        break;
      mvprintw(entry_no, i + 8, "%c", current->description[i]);
    }

    for (i = 0; i < maxx - split - 8; i++) {
      if (current->wait_info[i] == '\0')
        break;
      mvprintw(entry_no, i + split + 8, "%c", current->wait_info[i]);
    }

    if (entry_no == selected_entry - scroll_offset)
      attroff(A_REVERSE);
    entry_no++;
  }

  move(selected_entry - scroll_offset, 1);
  refresh();
}



void external_entry_edit(list_entry_t *entry)
{
  FILE *fh;
  int field_no;
  char line[MAX_LINE_LENGTH];
  char *tempfile;
  char command_buffer[MAX_COMMAND_LENGTH];

  /* NOTE: This function is considered insecure. */
  tempfile = tmpnam(NULL);

  if ((fh = fopen(tempfile, "w")) == NULL) {
    fprintf(stderr, "Warning: Unable to open temporary file for writing: %s",
      strerror(errno));
    return;
  }

  fprintf(fh, "%s\n", entry->topic);
  fprintf(fh, "%s\n", entry->description);
  fprintf(fh, "%s\n", entry->wait_info);
  fclose(fh);

  snprintf(command_buffer, MAX_COMMAND_LENGTH, "\"%s\" %s",
    getenv("EDITOR"), tempfile);

  endwin(); /* Suspend curses before running editor. */
  if (system(command_buffer) != 0) {
    fprintf(stderr, "Warning: Unable to launch editor.\n");
    remove(tempfile);
    return;
  }

  if ((fh = fopen(tempfile, "r")) == NULL) {
    fprintf(stderr, "Warning: Unable to open temporary file for reading: %s",
      strerror(errno));
    remove(tempfile);
    return;
  }

  field_no = 0;
  while (fgets(line, MAX_LINE_LENGTH, fh) != NULL) {
    line[strlen(line) - 1] = '\0'; /* Cut away the newline. */
    switch (field_no) {
    case 0: /* topic */
      strncpy(entry->topic, line, MAX_TOPIC_LENGTH);
      entry->topic[MAX_TOPIC_LENGTH - 1] = '\0';
      break;
    case 1: /* description */
      strncpy(entry->description, line, MAX_DESCRIPTION_LENGTH);
      entry->description[MAX_DESCRIPTION_LENGTH - 1] = '\0';
      break;
    case 2: /* wait info */
      strncpy(entry->wait_info, line, MAX_WAIT_INFO_LENGTH);
      entry->wait_info[MAX_WAIT_INFO_LENGTH - 1] = '\0';
      break;
    }
    field_no++;
  }
  fclose(fh);

  remove(tempfile);
}



static void exit_handler(void)
{
  if (endwin() == ERR)
    fprintf(stderr, "Warning: Failed to shutdown ncurses correctly.\n");

  free_list(); 
}



static void winch_handler(int signo)
{
  selected_entry = 0;
  scroll_offset = 0;

  endwin(); /* To get new window limits. */
  refresh();
  clear();
  update_screen();
  flushinp(); /* Avoid garbage on input afterwards. */
  keypad(stdscr, TRUE);
}



int main(int argc, char *argv[])
{
  FILE *fh;
  int c, maxy, maxx;
  list_entry_t *current, *temp;

  if (argc != 2) {
    fprintf(stderr, "Usage: %s <list file>\n", argv[0]);
    return 1;
  }

  fh = fopen(argv[1], "r");
  if (fh == NULL) {
    fprintf(stderr, "Error: Unable to open file for reading: %s\n",
      strerror(errno));
    return 1;
  }

  if (load_list(fh) != 0) {
    fclose(fh);
    return 1;
  }
  fclose(fh);

  /* Initialize curses. */
  initscr();
  atexit(exit_handler);
  noecho();
  keypad(stdscr, TRUE);

  selected_entry = 0;
  view_entry = 0;
  scroll_offset = 0;

  /* Event loop. */
  while (1) {
    update_screen();
    getmaxyx(stdscr, maxy, maxx);
    c = getch();

    switch (c) {
    case KEY_RESIZE:
      /* Use this event instead of SIGWINCH for better portability. */
      winch_handler(0);
      break;

    case KEY_DOWN:
      selected_entry++;
      if (selected_entry >= no_of_list_entries())
        selected_entry--;
      if (selected_entry > maxy - 1) {
        scroll_offset++;
        if (scroll_offset > selected_entry - maxy + 1)
          scroll_offset--;
      }
      break;

    case KEY_UP:
      selected_entry--;
      if (selected_entry < 0)
        selected_entry++;
      if (scroll_offset > selected_entry) {
        scroll_offset--;
        if (scroll_offset < 0)
          scroll_offset = 0;
      }
      break;

    case KEY_NPAGE:
      scroll_offset += maxy / 2;
      while (maxy + scroll_offset > no_of_list_entries())
        scroll_offset--;
      if (scroll_offset < 0)
        scroll_offset = 0;
      if (selected_entry < scroll_offset)
        selected_entry = scroll_offset;
      break;

    case KEY_PPAGE:
      scroll_offset -= maxy / 2;
      if (scroll_offset < 0)
        scroll_offset = 0;
      if (selected_entry > maxy + scroll_offset - 1)
        selected_entry = maxy + scroll_offset - 1;
      break;

    case KEY_ENTER: /* Enter special full-text viewing mode. */
    case '\n':
      if (view_entry)
        view_entry = 0;
      else
        view_entry = 1;
      break;

    case 'E':
    case 'e':
      if ((current = entry_by_no(selected_entry)) != NULL)
        external_entry_edit(current);
      break;

    case 'A':
    case 'a':
      if ((temp = entry_by_no(selected_entry)) != NULL) {
        if ((current = malloc(sizeof(list_entry_t))) == NULL) {
          fprintf(stderr, "Error: could not allocate memory for list entry.\n");
          return 1;
        }
        current->status = STATUS_PENDING;
        strncpy(current->topic, "TOPIC", MAX_TOPIC_LENGTH);
        strncpy(current->description, "DESCRIPTION", MAX_DESCRIPTION_LENGTH);
        strncpy(current->wait_info, "WAIT_INFO", MAX_WAIT_INFO_LENGTH);
        current->created = time(NULL);
        current->closed = 0;

        current->next = temp->next;
        temp->next = current;
        external_entry_edit(current);
      }
      break;

    case 'D':
    case 'd':
      if (list_start == NULL)
        break;
      if (selected_entry == 0) {
        temp = list_start;
        current = temp->next;
        free(temp);
        list_start = current;
      } else {
        if ((current = entry_by_no(selected_entry - 1)) != NULL) {
          temp = current->next;
          current->next = temp->next;
          free(temp);
        }
        if (selected_entry >= no_of_list_entries())
          selected_entry--; /* Step back if the last one was deleted. */
      }
      break;

    case 'S':
    case 's':
      fh = fopen(argv[1], "w");
      if (fh == NULL) {
        fprintf(stderr, "Error: Unable to open file for writing: %s\n",
        strerror(errno));
        return 1;
      }
      if (save_list(fh) != 0) {
        fclose(fh);
        return 1;
      }
      flash(); /* Indicate that the file was saved. */
      fclose(fh);
      break;

    case '1':
    case '2':
    case '3':
    case '4':
    case '5':
      if ((current = entry_by_no(selected_entry)) != NULL) {
        switch (c) {
        case '1':
          current->status = STATUS_ACTIVE;
          break;
        case '2':
          current->status = STATUS_PENDING;
          break;
        case '3':
          current->status = STATUS_CLOSED;
          current->closed = time(NULL);
          break;
        case '4':
          current->status = STATUS_SEMI_CLOSED;
          current->closed = time(NULL);
          break;
        case '5':
          current->status = STATUS_ABORTED;
          current->closed = time(NULL);
          break;
        }
      }
      if (selected_entry >= no_of_list_entries())
        selected_entry--; /* Step back if the last one was hidden. */
      break;

    case 'z':
    case 'Z':
      if (list_start == NULL)
        break;
      if (selected_entry == no_of_list_entries() - 1)
        break; /* Last entry cannot be moved down. */
      if (selected_entry == 0) {
        temp = list_start;
        list_start = temp->next;
        temp->next = list_start->next;
        list_start->next = temp;
        selected_entry++;
      } else {
        if ((current = entry_by_no(selected_entry - 1)) != NULL) {
          temp = current->next;
          current->next = temp->next;
          temp->next = temp->next->next;
          current->next->next = temp;
          selected_entry++;
          if (selected_entry > maxy - 1) {
            scroll_offset++;
            if (scroll_offset > selected_entry - maxy + 1)
              scroll_offset--;
          }
        }
      }
      break;

    case 'X':
    case 'x':
      if (list_start == NULL)
        break;
      if (selected_entry == 0)
        break; /* First entry cannot be moved up. */
      if (selected_entry == 1) {
        temp = list_start;
        list_start = temp->next;
        temp->next = list_start->next;
        list_start->next = temp;
        selected_entry--;
        if (scroll_offset > selected_entry) {
          scroll_offset--;
          if (scroll_offset < 0)
            scroll_offset = 0;
        }
      } else {
        if ((current = entry_by_no(selected_entry - 2)) != NULL) {
          temp = current->next;
          current->next = temp->next;
          temp->next = temp->next->next;
          current->next->next = temp;
          selected_entry--;
          if (scroll_offset > selected_entry) {
            scroll_offset--;
            if (scroll_offset < 0)
              scroll_offset = 0;
          }
        }
      }
      break;

    case 'Q':
    case 'q':
      if (view_entry)
        view_entry = 0;
      else
        return 0;
      break;

    default:
      view_entry = 0;
      break;
    }
  }

  return 0;
}

