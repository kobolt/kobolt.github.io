#ifndef _NAVI_H
#define _NAVI_H

#include "node.h"

void diff_navi_loop(diff_node_t *node, char *root1, char *root2);

#endif /* _NAVI_H */
