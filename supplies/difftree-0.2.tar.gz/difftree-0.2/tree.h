#ifndef _TREE_H
#define _TREE_H

#include "node.h"

void diff_tree_compare_dir(char *path1, char *path2, diff_node_t *current);

#endif /* _TREE_H */
