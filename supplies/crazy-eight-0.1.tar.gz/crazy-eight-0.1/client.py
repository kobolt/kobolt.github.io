#!/usr/bin/python

import socket
import time
import threading
import pygame



class CrazyEightClientNet(threading.Thread):
	def __init__(self, host, port=8888):
		threading.Thread.__init__(self)
		self._abort = False

		self._post_function = None

		self._host = host
		self._port = port
		self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		self._sock.setblocking(0)

	def __del__(self):
		self._sock.close()

	def register_callback(self, post_function):
		self._post_function = post_function

	def abort(self):
		self._abort = True

	def send(self, command):
		try:
			self._sock.sendto(command, (self._host, self._port))
			return True
		except:
			return False

	def run(self):
		while True:
			if self._abort:
				break
			try:
				packet, address = self._sock.recvfrom(512)
			except socket.error, e:
				if e[0] != 11 and e[0] != 10035:
					raise
				else:
					time.sleep(0.1)
					continue
			if len(packet) > 0:
				if self._post_function:
					self._post_function(packet.rstrip())



class CrazyEightClientGUI(object):
	def __init__(self):
		pygame.init()
		if not pygame.font:
			raise SystemExit, "Cannot work without PyGame fonts!"

		self._abort_function = None
		self._send_function = None

		self._player_name = ""

		# Disable excessive mouse motion events.
		pygame.event.set_blocked(pygame.MOUSEMOTION)

		self._screen = pygame.display.set_mode((640, 480))
		pygame.display.set_caption("Crazy Eights")

		self._font = pygame.font.Font(None, 36)

		surface = pygame.Surface(self._screen.get_size())
		self._bg = surface.convert()
		self._bg.fill((0, 100, 0)) # The color of a gambling table.

		self._card_image = [None] # Make sure index 0 is None.
		for i in range(1, 53):
			surface = pygame.image.load("card_image/%02d.png" % i)
			self._card_image.append(surface.convert())

		surface = pygame.image.load("card_image/back.png")
		self._back_image = surface.convert()
		self._back_image.set_colorkey(self._back_image.get_at((0,0)), pygame.RLEACCEL)

	def register_callback(self, abort_function, send_function):
		self._abort_function = abort_function
		self._send_function = send_function

	def event_post(self, packet):
		pygame.event.post(pygame.event.Event(pygame.USEREVENT, {'packet' : packet}))

	def set_player_name(self, name):
		self._player_name = name

	def register(self):
		if not self._send_function("REGISTER %s" % (self._player_name)):
			self._abort_function()
			raise SystemExit, "Invalid hostname for server."

		timeout = 50
		while True:
			event = pygame.event.poll()
			if event.type == pygame.USEREVENT:
				reply = event.packet.split(' ', 1)
				if reply[0] == 'REGISTER':
					if reply[1] == '0':
						break # Connection OK!
					else:
						self._abort_function()
						raise SystemExit, "Server rejected the connection. (%s)" % (reply[1])

			elif event.type == pygame.NOEVENT:
				time.sleep(0.1)
				timeout -= 1
				if timeout < 0:
					self._abort_function()
					raise SystemExit, "Connection to server timed out."

	def run_dialog(self):
		self._screen.blit(self._bg, (0, 0))
		pygame.display.flip()

		name_label = self._font.render("What is your name?", 1, (255, 255, 255))
		host_label = self._font.render("Address of server host?", 1, (255, 255, 255))
		name_text = None
		host_text = None
		name_entered = False
		host_entered = False
		name = str()
		host = str()

		while (not name_entered) or (not host_entered):
			event = pygame.event.wait()
			if event.type == pygame.QUIT:
				raise SystemExit, "User quit during registration process."
			elif event.type == pygame.KEYDOWN:
				if not name_entered:
					if event.key == pygame.K_BACKSPACE:
						name = name[:-1]
					elif event.key == pygame.K_RETURN:
						if len(name) > 0:
							name_entered = True
					else:
						try:
							name += str(event.unicode)
						except UnicodeEncodeError:
							pass
					name_text = self._font.render(name, 1, (255, 255, 255))
				else:
					if event.key == pygame.K_BACKSPACE:
						host = host[:-1]
					elif event.key == pygame.K_RETURN:
						if len(host) > 0:
							host_entered = True
					else:
						try:
							host += str(event.unicode)
						except UnicodeEncodeError:
							pass
					host_text = self._font.render(host, 1, (255, 255, 255))

			self._screen.blit(self._bg, (0, 0))
			self._screen.blit(name_label, (20, 220))
			if name_text:
				self._screen.blit(name_text, (265, 220))
			if name_entered:
				self._screen.blit(host_label, (20, 260))
				if host_text:
					self._screen.blit(host_text, (310, 260))

			pygame.display.flip()

		self._player_name = name
		return host

	def run_game(self):
		self._screen.blit(self._bg, (0, 0))
		pygame.display.flip()

		card_zones = []
		supply_zone = pygame.Rect(238, 192, 72, 96)

		old_state = None

		while True:
			event = pygame.event.wait()
			if event.type == pygame.QUIT:
				break

			elif event.type == pygame.MOUSEBUTTONDOWN:
				if supply_zone.collidepoint(event.pos):
					self._send_function("GETCARD")
				else:
					for zone in reversed(card_zones):
						if zone[0].collidepoint(event.pos):
							self._send_function("PUTCARD %d" % (zone[1]))
							break

			elif event.type == pygame.USEREVENT:
				reply = event.packet.split(' ', 1)
				if reply[0] == 'STATE':
					state = reply[1].split(';')

					# Start with background...
					self._screen.blit(self._bg, (0, 0))

					# Draw player's name:
					if int(state[0]) > 0:
						text = self._font.render(state[6] + ' (' + state[10] + ')', \
							1, (255, 255, 255))
					else:
						text = self._font.render(state[6] + ' (' + state[10] + ')', \
							1, (128, 128, 128))
					self._screen.blit(text, (50, self._bg.get_height() - text.get_height() - 5))

					# Draw other player names:
					text = self._font.render(state[7] + ' (' + state[11] + ')', \
						1, (128, 128, 128))
					self._screen.blit(text, (5, 50))
					text = self._font.render(state[8] + ' (' + state[12] + ')', \
						1, (128, 128, 128))
					self._screen.blit(text, (self._bg.get_width() - text.get_width() - 50, 5))
					text = self._font.render(state[9] + ' (' + state[13] + ')', \
						1, (128, 128, 128))
					self._screen.blit(text, (self._bg.get_width() - text.get_width() - 5, \
						self._bg.get_height() - text.get_height() - 50))

					# NOTE: Card images are 72x96 pixels.

					# Draw discard card:
					if int(state[5]) > 0:
						self._screen.blit(self._card_image[int(state[5])], (330, 192))

					# Draw supply pile:
					self._screen.blit(self._back_image, (238, 192))
					for i in range(1, 9):
						if int(state[4]) > i * 5:
							self._screen.blit(self._back_image, (238 - i, 192 - i))

					# Draw left player's deck:
					x = 240 - ((72 + ((int(state[1]) - 1) * 8)) / 2)
					for i in range(0, int(state[1])):
						self._screen.blit(pygame.transform.rotate(self._back_image, 90), (20, x))
						x += 8

					# Draw opposite player's deck:
					y = 320 + ((72 + ((int(state[2]) - 1) * 8)) / 2) - 72
					for i in range(0, int(state[2])):
						self._screen.blit(self._back_image, (y, 20))
						y -= 8

					# Draw right player's deck:
					x = 240 + ((72 + ((int(state[3]) - 1) * 8)) / 2) - 72
					for i in range(0, int(state[3])):
						self._screen.blit(pygame.transform.rotate(self._back_image, 90), (524, x))
						x -= 8

					# Draw player's deck:
					del card_zones[:]
					if len(state[14]) > 0:
						deck = state[14].split(',')
						y = 320 - ((72 + ((len(deck) - 1) * 12)) / 2)
						for i in range(0, len(deck)):
							self._screen.blit(self._card_image[int(deck[i])], (y, 364))
							card_zones.append((pygame.Rect(y, 364, 72, 96), int(deck[i])))
							y += 12

					pygame.display.flip()

					if old_state:
						# Animate player's move:
						if len(old_state[14]) > len(state[14]):
							self._animate_card((284, 364), (330, 192))
						elif len(old_state[14]) < len(state[14]):
							self._animate_card((238, 192), (284, 364))

						# Animate left player's move:
						if int(old_state[1]) > int(state[1]):
							self._animate_card((20, 204), (330, 192))
						elif int(old_state[1]) < int(state[1]):
							self._animate_card((238, 192), (20, 204))

						# Animate opposite player's move:
						if int(old_state[2]) > int(state[2]):
							self._animate_card((284, 20), (330, 192))
						elif int(old_state[2]) < int(state[2]):
							self._animate_card((238, 192), (284, 20))

						# Animate right player's move:
						if int(old_state[3]) > int(state[3]):
							self._animate_card((524, 204), (330, 192))
						elif int(old_state[3]) < int(state[3]):
							self._animate_card((238, 192), (524, 204))

					old_state = state

		self._abort_function()

	def _animate_card(self, from_pos, to_pos):
		y_step = (to_pos[0] - from_pos[0]) / 16
		x_step = (to_pos[1] - from_pos[1]) / 16
		original = self._screen.copy()

		for i in range(0, 16):
			self._screen.blit(pygame.transform.rotate(self._back_image, (i * 22.5) % 360), \
				(from_pos[0] + (i * y_step), from_pos[1] + (i * x_step)))
			pygame.display.flip()
			self._screen.blit(original, (0, 0))
			time.sleep(0.01)

		pygame.display.flip()



if __name__ == "__main__":
	import sys

	gui = CrazyEightClientGUI()

	if len(sys.argv) > 2:
		name = sys.argv[1]
		host = sys.argv[2]
		gui.set_player_name(name)
	else:
		host = gui.run_dialog()

	net = CrazyEightClientNet(host)
	gui.register_callback(net.abort, net.send)
	net.register_callback(gui.event_post)

	net.start()
	gui.register()
	gui.run_game()

