#!/usr/bin/python

import socket
import random
import time



class CrazyEightState(object):
	def __init__(self):
		self.game_finished = False
		self.winners = 0
		self.current_player = None
		self.discard_deck = []
		self.supply_deck = []
		self.player_deck = [[],[],[],[]] # Placeholders for 4 players.
		self.player_name = [None, None, None, None]
		self.no_of_supply_picked = 0
		self.player_score = [0, 0, 0, 0]

	def _advance_player(self):
		if self.winners >= 3:
			# There is one looser and the game is over.
			self.game_finished = True

		self.no_of_supply_picked = 0
		for i in range(0, 4):
			if self.current_player == 3:
				self.current_player = 0
			else:
				self.current_player += 1
			# If player does not have any cards left, try next.
			if len(self.player_deck[self.current_player]) > 0:
				break
		else:
			# No one has any cards left. (Should not happen.)
			self.game_finished = True

	def start_game(self):
		self.game_finished = False
		self.no_of_supply_picked = 0
		self.winners = 0

		# Put 52 cards in the supply deck and shuffle them.
		random.seed()
		self.supply_deck = range(1, 53)
		random.shuffle(self.supply_deck)

		# Start the discard deck by taking first card form supply deck.
		self.discard_deck = []
		self.discard_deck.append(self.supply_deck.pop())

		# Give each player 5 cards from the supply deck.
		self.player_deck = [[],[],[],[]]
		for player_id in range(0, 4):
			for i in range(0, 5):
				self.player_deck[player_id].append(self.supply_deck.pop())

		# Select a random starting player.
		self.current_player = random.randint(0, 3)

	def put_card(self, player_id, card_id):
		# Check if it's that player's turn.
		if player_id != self.current_player:
			return False

		# Check if player actually has the card.
		if card_id not in self.player_deck[player_id]:
			return False

		# Check rules.
		if card_id % 13 == 8 or \
			card_id % 13 == (self.discard_deck[-1] % 13) or \
			(card_id - 1) / 13 == (self.discard_deck[-1] - 1) / 13:
			self.discard_deck.append(card_id)
			self.player_deck[player_id].remove(card_id)
		else:
			return False

		# If no cards left, add a winner and scores.
		if len(self.player_deck[player_id]) == 0:
			self.player_score[player_id] += (3 - self.winners)
			self.winners += 1

		self._advance_player()
		return True

	def get_card(self, player_id):
		# Check if it's that player's turn.
		if player_id != self.current_player:
			return False

		if self.no_of_supply_picked == 3:
			# Interpret 3+ picked cards as skipping the round.
			self._advance_player()
			return True

		if len(self.supply_deck) == 0:
			# Supply deck empty, get fresh cards from discard deck if possible.
			if len(self.discard_deck) > 1:
				self.supply_deck.extend(self.discard_deck[:-1])
				del self.discard_deck[:-1]
				random.shuffle(self.supply_deck)
			else:
				self._advance_player()
				return True

		card_id = self.supply_deck.pop()
		self.player_deck[player_id].append(card_id)
		self.no_of_supply_picked += 1
		return True

	def as_string(self, player_id):
		if player_id == 3:
			left_player_id = 0
		else:
			left_player_id = player_id + 1

		if player_id == 0:
			right_player_id = 3
		else:
			right_player_id = player_id - 1

		if player_id >= 2:
			opposite_player_id = player_id - 2
		else:
			opposite_player_id = player_id + 2

		if len(self.discard_deck) == 0:
			discard_top = 0
		else:
			discard_top = self.discard_deck[-1]

		if player_id == self.current_player:
			your_turn = 1
		else:
			your_turn = 0

		return "%d;%d;%d;%d;%d;%d;%s;%s;%s;%s;%d;%d;%d;%d;%s" % (\
			your_turn,
			len(self.player_deck[left_player_id]),
			len(self.player_deck[opposite_player_id]),
			len(self.player_deck[right_player_id]),
			len(self.supply_deck),
			discard_top,
			self.player_name[player_id],
			self.player_name[left_player_id],
			self.player_name[opposite_player_id],
			self.player_name[right_player_id],
			self.player_score[player_id],
			self.player_score[left_player_id],
			self.player_score[opposite_player_id],
			self.player_score[right_player_id],
			','.join(map(str,self.player_deck[player_id])))



class CrazyEightServer(object):
	def __init__(self, no_of_players, listen_port=8888):
		self._no_of_players = no_of_players
		self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		self._sock.bind(("", listen_port))
		self._state = CrazyEightState()
		print "Configuring game for %d player(s)." % (no_of_players)

	def run(self):
		self._ready_to_start = False
		self._clients = dict() # Address to player ID mapping.
		self._bots = list()
		if self._no_of_players < 4:
			self._state.player_name[0] = "Groucho"
			self._bots.append(0)
		if self._no_of_players < 3:
			self._state.player_name[1] = "Chico"
			self._bots.append(1)
		if self._no_of_players < 2:
			self._state.player_name[2] = "Harpo"
			self._bots.append(2)
		if self._no_of_players < 1:
			self._state.player_name[3] = "Zeppo"
			self._bots.append(3)

		while True:
			if self._ready_to_start or self._state.game_finished:
				print "Starting game."
				self._state.start_game()
				self._distribute_state()
				self._ready_to_start = False

			# Play for the bots...
			while self._state.current_player in self._bots:
				if self._state.game_finished:
					break
				print "Playing for Bot #%d" % (self._state.current_player + 1)
				# Simple Bot-Logic, just try all cards at random.
				random.shuffle(self._state.player_deck[self._state.current_player])
				for card_id in self._state.player_deck[self._state.current_player]:
					if self._state.put_card(self._state.current_player, card_id):
						break
				else:
					self._state.get_card(self._state.current_player)
				# Distibutution of state is needed to see that the game actually progresses.
				self._distribute_state()
				# Excessive computer playing may cause event problems at the client, so delay.
				time.sleep(0.1)

			if self._state.game_finished:
				continue

			# Special mode: Just bots.
			if self._no_of_players == 0:
				continue

			# ...Then wait for command from a real client.
			print "Waiting for client..."
			packet, address = self._sock.recvfrom(512)
			command = packet.split(' ', 1)
			if len(command) <= 0:
				continue

			if command[0] == 'REGISTER':
				# Check if already registered.
				if address in self._clients:
					self._sock.sendto("REGISTER -1\n", address)
					continue

				player_id = self._next_player_id()

				if player_id == None:
					# Too many players already.
					self._sock.sendto("REGISTER -2\n", address)
					continue
				else:
					self._clients[address] = player_id
					if len(command) >= 2:
						self._state.player_name[player_id] = command[1]
					else:
						self._state.player_name[player_id] = "Player #" + str(player_id + 1)
					print "Player '%s' has joined." % (self._state.player_name[player_id])
					self._sock.sendto("REGISTER 0\n", address)

				if self._next_player_id() == None:
					# No space for players left? Start the game!
					self._ready_to_start = True

			elif command[0] == 'PUTCARD':
				if address not in self._clients:
					self._sock.sendto("PUTCARD -1\n", address)
					continue

				if len(command) < 2:
					self._sock.sendto("PUTCARD -2\n", address)
					continue
				else:
					try:
						if self._state.put_card(self._clients[address], int(command[1])):
							self._sock.sendto("PUTCARD 0\n", address)
						else:
							self._sock.sendto("PUTCARD -3\n", address)
							continue
					except ValueError:
						self._sock.sendto("PUTCARD -4\n", address)
						continue

			elif command[0] == 'GETCARD':
				if address not in self._clients:
					self._sock.sendto("GETCARD -1\n", address)
					continue
				if self._state.get_card(self._clients[address]):
					self._sock.sendto("GETCARD 0\n", address)
				else:
					self._sock.sendto("GETCARD -2\n", address)
					continue

			elif command[0] == 'STATE':
				pass

			else:
				# Unknown command.
				self._sock.sendto("UNKNOWN -1\n", address)
				continue

			# Distribute state to all clients.
			self._distribute_state()

	def _distribute_state(self):
		for address in self._clients:
			self._sock.sendto("STATE %s\n" % \
				(self._state.as_string(self._clients[address])), address)

	def _next_player_id(self):
		for player_id, name in enumerate(self._state.player_name):
			if name == None:
				return player_id
		else:
			return None



if __name__ == "__main__":
	import sys

	if len(sys.argv) > 1:
		s = CrazyEightServer(int(sys.argv[1]))
	else:
		s = CrazyEightServer(1)

	s.run()

