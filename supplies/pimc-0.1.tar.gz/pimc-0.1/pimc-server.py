#!/usr/bin/python

import socket
import time

class Server(object):

	def __init__(self, listen_port):
		self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		self._sock.bind(("", listen_port))
		self._clients = {}
		self._gone = []

	def loop(self):
		self._sock.listen(5)
		self._sock.setblocking(0)
		self._id = 1

		while True:
			time.sleep(0.01)

			# Check for new connections.
			try:
				client_sock, client_addr = self._sock.accept()
				print "%d: new connection from %s" % (self._id, client_addr[0])
				client_sock.setblocking(0)
				self._clients[self._id] = { \
					'sock' : client_sock, \
					'addr' : client_addr[0], \
					'port' : client_addr[1], \
					'nick' : None}
				self._id += 1
				self.broadcast("@: A new user has arrived from %s!\n" % (client_addr[0]))
				continue
			except socket.error, e:
				if e[0] == 11:
					pass

			# Check for messages on established connections.
			for recv_id in self._clients:
				recv = self._clients[recv_id]
				try:
					data = recv['sock'].recv(4096).rstrip("\n\r")
				except socket.error, e:
					if e[0] == 11:
						continue
					self._gone.append((recv_id, recv['nick']))
					continue

				if not data:
					self._gone.append((recv_id, recv['nick']))
					continue

				# Check if command, and handle seperately:
				if data[0] == '/': 
					print "%d: sent command: %s" % (recv_id, data)

					try:
						cmd, arg = data[1:].split(" ")
					except ValueError:
						cmd = data[1:]

					if cmd == 'nick':
						if len(arg) == 0 or arg[0] == '@':
							recv['sock'].send('@: Invalid nick.\n')
						else:
							if recv['nick'] == None:
								self.broadcast("@: User from %s calls himself '%s'.\n" % (recv['addr'], arg))
							else:
								self.broadcast("@: '%s' is now known as '%s'.\n" % (recv['nick'], arg))
							recv['nick'] = arg

					elif cmd == 'who':
						users = ""
						for id in self._clients:
							if self._clients[id]['nick'] == None:
								users = users + " " + self._clients[id]['addr']
							else:
								users = users + " '" + \
									self._clients[id]['nick'] + "'"
						recv['sock'].send('@: Users:' + users + "\n")

					else:
						recv['sock'].send('@: Unknown command.\n')

					continue

				# Do not broadcast anything before the client has set a nick.
				if recv['nick'] == None:
					recv['sock'].send('@: You have not identified yourself.\n')
					continue

				# If not command, then assume it is a message.
				self.broadcast(recv['nick'] + ": " + data + "\n")

			# Remove disconnected clients.
			for gone_id, gone_nick in self._gone:
				print "%d: went offline" % (gone_id)
				del self._clients[gone_id]
			for gone_id, gone_nick in self._gone:
				self.broadcast("@: '%s' has gone offline.\n" % (gone_nick))
			del self._gone[:]

	def broadcast(self, data):
		# Send something to all connected clients.
		for send_id in self._clients:
			send = self._clients[send_id]
			try:
				send['sock'].send(data)
			except socket.error:
				self._gone.append((send_id, send['nick']))
				continue

if __name__ == "__main__":
	import sys

	if len(sys.argv) != 2:
		print "Usage: %s <port>" % (sys.argv[0])
		sys.exit(1)

	server = Server(int(sys.argv[1]))
	server.loop()

