#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <sys/time.h>

#define ELEMENT_BUFFER_MAX 7

static int unit_time;
static struct timeval last_time;

typedef enum {
  ELEMENT_DOT,        /* '.' */
  ELEMENT_DASH,       /* '-' */
  ELEMENT_INTER,      /* Between elements. */
  ELEMENT_SHORT_GAP,  /* Between letters. */
  ELEMENT_MEDIUM_GAP, /* Between words. */
  ELEMENT_LONG_GAP,   /* Between sentences. */
  ELEMENT_TIMEOUT,
} element_t;



static int power_of_two(int n)
{
  if (n == 0)
    return 1;
  else
    return 2 * power_of_two(n - 1);
}



static char code_to_character[] = {
  '*', 'E', 'T', 'I', 'N', 'A', 'M', 'S', 'D', 'R',
  'G', 'U', 'K', 'W', 'O', 'H', 'B', 'L', 'Z', 'F',
  'C', 'P', '*', 'V', 'X', '*', 'Q', '*', 'Y', 'J',
  '*', '5', '6', '&', '7', '*', '*', '*', '8', '*',
  '/', '+', '*', '(', '*', '*', '9', '4', '=', '*',
  '*', '*', '*', '*', '*', '3', '*', '*', '*', '2',
  '*', '1', '0', '*', '*', '*', '*', '*', '*', '*',
};



static char buffer_to_character(element_t *buffer, int buffer_size)
{
  int i, code;

  code = 0;
  for (i = 0; i < buffer_size; i++) {
    if (buffer[i] == ELEMENT_DOT)
      code += 1 * power_of_two(i);
    else if (buffer[i] == ELEMENT_DASH)
      code += 2 * power_of_two(i);
  }

  if (code > sizeof(code_to_character))
    return '*';
  else
    return code_to_character[code];
}



/* Buffer units and possibly generate a character. */
static void element_to_buffer(element_t element)
{
  static element_t buffer[ELEMENT_BUFFER_MAX];
  static int buffer_size = 0;

  switch (element) {
  case ELEMENT_DOT:
  case ELEMENT_DASH:
    if (buffer_size >= (ELEMENT_BUFFER_MAX - 1)) {
      buffer_size = 0;
      fprintf(stderr, "overflow");
      /* And ignore and start over. */
    } else {
      buffer[buffer_size] = element;
      buffer_size++;
    }
    break;

  case ELEMENT_INTER:
    break;

  case ELEMENT_SHORT_GAP:
    if (buffer_size > 0)
      fprintf(stderr, "%c", buffer_to_character(buffer, buffer_size));
    buffer_size = 0;
    break;

  case ELEMENT_MEDIUM_GAP:
    if (buffer_size > 0)
      fprintf(stderr, "%c ", buffer_to_character(buffer, buffer_size));
    buffer_size = 0;
    break;

  case ELEMENT_LONG_GAP:
    if (buffer_size > 0)
      fprintf(stderr, "%c\n", buffer_to_character(buffer, buffer_size));
    buffer_size = 0;
    break;

  case ELEMENT_TIMEOUT:
    fprintf(stderr, "timeout");
    buffer_size = 0;
    break;

  default:
    break;
  }
}



static int delta_ms(struct timeval *tv1, struct timeval *tv2)
{
  int delta_seconds = tv1->tv_sec - tv2->tv_sec;
  int delta_ms = (tv1->tv_usec - tv2->tv_usec) / 1000;

  if (delta_ms < 0) {
    delta_ms += 1000;
    delta_seconds--;
  }
  return (delta_seconds * 1000) + delta_ms;
}



static int units_from_ms(int ms)
{
  int units;
  units = ms / unit_time;
  if ((ms % unit_time) > (unit_time / 2))
    units++;
  return units;
}



/* Use toggle level and delta time to determine element, if any. */
void toggle_to_element(int level)
{
  static bool waiting_for_low = false;

  struct timeval current_time;
  int delta_time;
  int units;

  gettimeofday(&current_time, NULL);
  delta_time = delta_ms(&current_time, &last_time);
  units = units_from_ms(delta_time);

  if (waiting_for_low) {
    if (level == 0) {
      if (units <= 1) { /* Strictly: 1 unit. */
        element_to_buffer(ELEMENT_DOT);
        waiting_for_low = false;
      } else if (units <= 4) { /* Strictly: 3 units. */
        element_to_buffer(ELEMENT_DASH);
        waiting_for_low = false;
      }
    } else {
      /* On high-level timeout, erase pending character. */
      element_to_buffer(ELEMENT_TIMEOUT);
      waiting_for_low = false;
    }
  } else { /* Waiting for high. */
    if (level == 1) {
      if (units <= 2) { /* Strictly: 1 unit. */
        element_to_buffer(ELEMENT_INTER);
        waiting_for_low = true;
      } else if (units < 7) { /* Strictly: 3 units. */
        element_to_buffer(ELEMENT_SHORT_GAP);
        waiting_for_low = true;
      } else if (units < 20) { /* Strictly: 7 units. */
        element_to_buffer(ELEMENT_MEDIUM_GAP);
        waiting_for_low = true;
      } else {
        element_to_buffer(ELEMENT_LONG_GAP);
        waiting_for_low = true;
      }
    } else {
      /* On low-level timeout, push out pending character. */
      element_to_buffer(ELEMENT_LONG_GAP);
    }
  }

  memcpy(&last_time, &current_time, sizeof(struct timeval));
}



void convert_init(int new_unit_time)
{
  unit_time = new_unit_time;
  gettimeofday(&last_time, NULL);
}

