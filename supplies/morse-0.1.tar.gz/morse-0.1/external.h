#ifndef _EXTERNAL_H
#define _EXTERNAL_H

typedef enum {
  EXTERNAL_EVENT_NONE,
  EXTERNAL_EVENT_LOW,
  EXTERNAL_EVENT_HIGH,
} external_event_t;

int external_init(void);
external_event_t external_get(void);

#endif /* _EXTERNAL_H */
