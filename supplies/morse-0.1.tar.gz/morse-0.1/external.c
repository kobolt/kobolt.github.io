#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include "external.h"

static int serial_fd;
static int last_value;

static void external_close(void)
{
  close(serial_fd);
}

int external_init(void)
{
  int flags;

  serial_fd = open("/dev/ttyS0", O_RDONLY);
  if (serial_fd == -1) {
    fprintf(stderr, "Error: open() failed: %s\n", strerror(errno));
    return -1;
  }
  atexit(external_close);

  /* Make sure RTS is set. */
  ioctl(serial_fd, TIOCMGET, &flags);
  flags |= TIOCM_RTS;
  if (ioctl(serial_fd, TIOCMSET, &flags) == -1) {
    fprintf(stderr, "Error: ioctl() failed: %s\n", strerror(errno));
    return -1;
  }

  last_value = 0;
  return 0;
}

external_event_t external_get(void)
{
  int flags, value;

  ioctl(serial_fd, TIOCMGET, &flags);
  value = flags & TIOCM_CTS;

  if (value == 0 && last_value > 0) {
    last_value = value;
    return EXTERNAL_EVENT_LOW;
  } else if (value > 0 && last_value == 0) {
    last_value = value;
    return EXTERNAL_EVENT_HIGH;
  } else {
    return EXTERNAL_EVENT_NONE;
  }
}

