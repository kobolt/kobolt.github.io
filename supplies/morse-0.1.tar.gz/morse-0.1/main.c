#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>
#include "convert.h"
#ifdef EXTERNAL
#include "external.h"
#endif /* EXTERNAL */

#define UNIT_TIME 100

#define SAMPLE_LOW 150
#define SAMPLE_HIGH 100
#define X_SIZE 256
#define Y_SIZE 256

int main(int argc, char *argv[])
{
  int level = 0, timeout = 0;
  SDL_Surface *screen;
  SDL_Event event;
  SDL_Rect rect, src, dst;
  Mix_Chunk *tone;
#ifdef EXTERNAL
  external_event_t external_event;
#endif /* EXTERNAL */

  convert_init(UNIT_TIME);

#ifdef EXTERNAL
  if (external_init() != 0) {
    return 1;
  }
#endif /* EXTERNAL */

  if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) != 0) {
    fprintf(stderr, "Error: Unable to initalize SDL: %s\n", SDL_GetError());
    return 1;
  }
  atexit(SDL_Quit);

  screen = SDL_SetVideoMode(X_SIZE, Y_SIZE, 16, SDL_DOUBLEBUF);
  if (screen == NULL) {
    fprintf(stderr, "Error: Unable to set video mode: %s\n", SDL_GetError());
    return 1;
  }
  SDL_WM_SetCaption("Morse", "Morse");

  if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 256) < 0) {
     fprintf(stderr, "Error: Unable to open audio: %s\n", SDL_GetError());
     Mix_CloseAudio();
     return -1;
  }

  if (! (tone = Mix_LoadWAV("tone.wav"))) {
     fprintf(stderr, "Error: Unable to open sound file: %s\n",
       SDL_GetError());
     Mix_CloseAudio();
     return -1;
  }

  /* Setup for future use. */
  src.x = 1;
  dst.x = 0;
  src.y = dst.y = 0;
  src.w = dst.w = X_SIZE - 1;
  src.h = dst.h = Y_SIZE;

  rect.w = rect.h = 1;
  rect.y = SAMPLE_LOW;
  for (rect.x = 0; rect.x < X_SIZE; rect.x++)
     SDL_FillRect(screen, &rect, 0xffffff);

  while (1) {
    SDL_Flip(screen);

    SDL_BlitSurface(screen, &src, screen, &dst);

    rect.x = X_SIZE - 1;
    rect.y = 0;
    rect.w = 1;
    rect.h = Y_SIZE;
    SDL_FillRect(screen, &rect, 0x000000);

    rect.w = rect.h = 1;
    rect.x = X_SIZE - 1;
    rect.y = (level == 1) ? SAMPLE_HIGH : SAMPLE_LOW;
    SDL_FillRect(screen, &rect, 0xffffff);

#ifdef EXTERNAL
    external_event = external_get();
    if (external_event == EXTERNAL_EVENT_HIGH) {
      toggle_to_element(1);
      level = 1;
      timeout = 0;
      rect.x = X_SIZE - 1;
      rect.y = SAMPLE_HIGH;
      rect.w = 1;
      rect.h = SAMPLE_LOW - SAMPLE_HIGH;
      SDL_FillRect(screen, &rect, 0xffffff);
      Mix_PlayChannel(-1, tone, -1);
    } else if (external_event == EXTERNAL_EVENT_LOW) {
      toggle_to_element(0);
      level = 0;
      timeout = 0;
      rect.x = X_SIZE - 1;
      rect.y = SAMPLE_HIGH;
      rect.w = 1;
      rect.h = SAMPLE_LOW - SAMPLE_HIGH;
      SDL_FillRect(screen, &rect, 0xffffff);
      Mix_HaltChannel(-1);
    }
#endif /* EXTERNAL */

    if (SDL_PollEvent(&event) == 1) {
      if (event.type == SDL_KEYDOWN) {
        if (event.key.keysym.sym == SDLK_q)
          break;
#ifndef EXTERNAL
        else if (event.key.keysym.sym == SDLK_SPACE) {
          toggle_to_element(1);
          level = 1;
          timeout = 0;
          rect.x = X_SIZE - 1;
          rect.y = SAMPLE_HIGH;
          rect.w = 1;
          rect.h = SAMPLE_LOW - SAMPLE_HIGH;
          SDL_FillRect(screen, &rect, 0xffffff);
          Mix_PlayChannel(-1, tone, -1);
        }
      } else if (event.type == SDL_KEYUP) {
        if (event.key.keysym.sym == SDLK_SPACE) {
          toggle_to_element(0);
          level = 0;
          timeout = 0;
          rect.x = X_SIZE - 1;
          rect.y = SAMPLE_HIGH;
          rect.w = 1;
          rect.h = SAMPLE_LOW - SAMPLE_HIGH;
          SDL_FillRect(screen, &rect, 0xffffff);
          Mix_HaltChannel(-1);
        }
#endif /* EXTERNAL */
      } else if (event.type == SDL_QUIT) {
        break;
      }
    }

    timeout++;
    if (timeout == 150)
      toggle_to_element(level);
    SDL_Delay(10);
  }

  Mix_HaltChannel(-1);
  Mix_CloseAudio();
  Mix_FreeChunk(tone);
  return 0;
}

