#ifndef _CONVERT_H
#define _CONVERT_H

void toggle_to_element(int level);
void convert_init(int new_unit_time);

#endif /* _CONVERT_H */
