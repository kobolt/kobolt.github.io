#ifndef _SAKURA_CLOCK_H
#define _SAKURA_CLOCK_H

void sakura_clock_setup(void);

#endif /* _SAKURA_CLOCK_H */
