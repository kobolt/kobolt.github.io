#ifndef _TIMER_H
#define _TIMER_H

void timer_setup(void);
unsigned char timer_read(void);
void timer_set(unsigned char countdown);

#endif /* _TIMER_H */
