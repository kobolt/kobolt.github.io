#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <termios.h>
#include <unistd.h>

#ifdef CONIO_CONSOLE
#include <conio.h>
#else /* !CONIO_CONSOLE */
#include <poll.h>
#include <errno.h>
#endif /* CONIO_CONSOLE */

#include "panic.h"



static void console_exit_handler(void)
{
  /* Restore canonical mode and echo. */
  struct termios ts;
  tcgetattr(STDIN_FILENO, &ts);
  ts.c_lflag |= ICANON | ECHO;
  tcsetattr(STDIN_FILENO, TCSANOW, &ts);
}



void console_init(void)
{
  atexit(console_exit_handler);

  /* Turn off canonical mode and echo. */
  struct termios ts;
  tcgetattr(STDIN_FILENO, &ts);
  ts.c_lflag &= ~ICANON & ~ECHO;
  tcsetattr(STDIN_FILENO, TCSANOW, &ts);

  /* Make stdout unbuffered. */
  setvbuf(stdout, NULL, _IONBF, 0);
}



#ifdef CONIO_CONSOLE
uint8_t console_status(void)
{
  return (kbhit() == 0) ? 0x00 : 0xFF;
}
#else /* !CONIO_CONSOLE */
uint8_t console_status(void)
{
  int result;
  struct pollfd fds[1];

  fds[0].fd = STDIN_FILENO;
  fds[0].events = POLLIN;
  result = poll(fds, 1, 0);
  if (result == -1) {
    if (errno == EINTR) {
      return 0x00; /* Handle this as nothing available. */
    } else {
      panic("poll() failed with errno: %d\n", errno);
    }
  }
  return (result == 0) ? 0x00 : 0xFF;
}
#endif /* CONIO_CONSOLE */



uint8_t console_read(void)
{
  int value;

  do {
    value = fgetc(stdin);
  } while (value == EOF);

  switch (value) {
  case 0x0A: /* Convert LF to CR */
    return 0x0D;

  case 0x7F: /* Convert DEL to BS */
    return 0x08;

  case 0x1B: /* Escape */
    if (fgetc(stdin) == '[') {
      value = fgetc(stdin);
      switch (value) {
      case 'A': return 0x0B; /* Cursor Up */
      case 'B': return 0x0A; /* Cursor Down */
      case 'C': return 0x0C; /* Cursor Forward/Right */
      case 'D': return 0x08; /* Cursor Back/Left */
      default:
        panic("Unhandled console read escape code: 0x%02x\n", value);
        break;
      }
    }
    break;

  default:
    break;
  }

  return value;
}



void console_write(uint8_t value)
{
  static int escape = 0;
  static uint8_t row = 0;

  /* ADM-3A emulation of escape codes. */
  if (escape == 2) {
    row = value;
    escape++;
    return;

  } else if (escape == 3) {
    /* ANSI - Cursor Position */
    fprintf(stdout, "\033[%d;%dH", row - 31, value - 31);
    escape++;
    return;

  } else if (escape == 4) {
    if (value == 0x3D) {
      /* Repeated escape code. */
      escape = 2;
      return;

    } else {
      escape = 0;
    }
  }

  /* Pass through regular ASCII characters. */
  if (value >= 0x20 && value < 0x7F) {
    if (escape == 0) {
      fputc(value, stdout);
      return;
    }
  }

  /* Check potential non-printable characters. */
  switch (value) {
  case 0x0B:
    /* ANSI - Cursor Up */
    fprintf(stdout, "\033[A");
    break;

  case 0x0C:
    /* ANSI - Cursor Right */
    fprintf(stdout, "\033[C");
    break;

  case 0x1B:
    if (escape == 0) {
      escape++;
    } else {
      escape = 0;
    }
    break;

  case 0x1A:
    /* ANSI - Erase in Display */
    fprintf(stdout, "\033[2J");
    /* Fallthrough! */
  case 0x1E:
    /* ANSI - Cursor Home */
    fprintf(stdout, "\033[H");
    break;

  case 0x3D:
    if (escape == 1) {
      escape++;
    } else {
      fputc('=', stdout);
      escape = 0;
    }
    break;

  case 0xA4:
    /* Copyright Symbol */
    fputc('c', stdout);
    break;

  default:
    /* Passthrough all other characters. */
    fputc(value, stdout);
    break;
  }
}



