#ifndef _PS2KBD_H
#define _PS2KBD_H

int ps2kbd_init(void);

#endif /* _PS2KBD_H */
