#ifndef _LCD_COMMON_H
#define _LCD_COMMON_H

#include <stdio.h>
#include <sys/io.h>
#include <unistd.h> /* usleep() */

void lcd_init(unsigned long port, int cursor_on);
void lcd_clear_display(unsigned long port);
void lcd_put_character(unsigned long port, unsigned char character);
void lcd_set_position(unsigned long port, int row, int col);

#endif /* _LCD_COMMON_H */
