#include "lcd-common.h"
#include <stdio.h>
#include <stdlib.h> /* atoi() */
#include <errno.h>
#include <string.h> /* strerror() */
#include <unistd.h> /* getuid() */
#include <sys/types.h> /* setreuid() */

int main(int argc, char *argv[])
{
  int row, i;
  unsigned long port = 0;

  if (argc < 3) {
    fprintf(stderr, "Usage: %s <row> <string> [port]\n", argv[0]);
    fprintf(stderr, "If row is 0, LCD will be initalized instead.\n");
    return 1;
  }
  
  if (argc > 3)
    sscanf(argv[3], "%x", (unsigned int *)&port);
  else 
    port = 0x378; /* Default, parallel port 1. */

  row = atoi(argv[1]);
  if (row < 0 || row > 4) {
    fprintf(stderr, "%s: Row is out of range. (1-4 or 0)\n", argv[0]);
    return 1;
  }

  if (strlen(argv[2]) > 20) {
    fprintf(stderr, "%s: String is too long. (Max 20)\n", argv[0]);
    return 1;
  }

  if (ioperm(port, 3, 1) != 0) {
    fprintf(stderr, "%s: ioperm(): %s\n", argv[0], strerror(errno));
    return 1;
  }

  /* Drop privileges. */
  if (setreuid(getuid(), getuid()) != 0) {
    fprintf(stderr, "%s: setreuid(): %s\n", argv[0], strerror(errno));
    return 1;
  }
  if (setregid(getgid(), getgid()) != 0) {
    fprintf(stderr, "%s: setregid(): %s\n", argv[0], strerror(errno));
    return 1;
  }

  if (row == 0) {
    lcd_init(port, 0);
  } else {
    lcd_set_position(port, row - 1, 0);
    for (i = 0; i < 20; i++) {
      if (argv[2][i] == '\0' || argv[2][i] == '\n')
        break;
      lcd_put_character(port, argv[2][i]);
    }
    for (; i < 20; i++)
      lcd_put_character(port, ' '); /* Clear rest of line. */
  }

  if (ioperm(port, 3, 0) != 0) {
    fprintf(stderr, "%s: ioperm(): %s\n", argv[0], strerror(errno));
    return 1;
  }

  return 0;
}

