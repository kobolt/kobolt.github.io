#include "lcd-common.h"
#include <stdio.h>
#include <errno.h>
#include <string.h> /* strerror() */
#include <unistd.h> /* getuid() */
#include <sys/types.h> /* setreuid() */

#define MAX_LINE_LEN 256

int main(int argc, char *argv[])
{
  unsigned long port = 0;
  char buffer[MAX_LINE_LEN];
  char display[4][20]; /* To keep track for scrolling. */
  int row, i, j;

  if (argc > 1)
    sscanf(argv[1], "%x", (unsigned int *)&port);
  else 
    port = 0x378; /* Default, parallel port 1. */

  if (ioperm(port, 3, 1) != 0) {
    fprintf(stderr, "%s: ioperm(): %s\n", argv[0], strerror(errno));
    return 1;
  }

  /* Drop privileges. */
  if (setreuid(getuid(), getuid()) != 0) {
    fprintf(stderr, "%s: setreuid(): %s\n", argv[0], strerror(errno));
    return 1;
  }
  if (setregid(getgid(), getgid()) != 0) {
    fprintf(stderr, "%s: setregid(): %s\n", argv[0], strerror(errno));
    return 1;
  }

  lcd_init(port, 0);

  display[0][0] = '\0';
  display[1][0] = '\0';
  display[2][0] = '\0';
  display[3][0] = '\0';
  row = -1;

  while (fgets(buffer, MAX_LINE_LEN, stdin)) {
    row++;
    if (row > 3) {
      row = 3; /* Keep this position, and scroll. */
      strncpy(display[0], display[1], 20);
      strncpy(display[1], display[2], 20);
      strncpy(display[2], display[3], 20);
    }
    strncpy(display[row], buffer, 20);

    /* Refresh real LCD. */
    lcd_clear_display(port);
    for (i = 0; i < 4; i++) {
      lcd_set_position(port, i, 0);
      for (j = 0; j < 20; j++) {
        if (display[i][j] == '\0' || display[i][j] == '\n')
          break;
        lcd_put_character(port, display[i][j]);
      }
    }
  }

  lcd_clear_display(port);

  if (ioperm(port, 3, 0) != 0) {
    fprintf(stderr, "%s: ioperm(): %s\n", argv[0], strerror(errno));
    return 1;
  }

  return 0;
}

