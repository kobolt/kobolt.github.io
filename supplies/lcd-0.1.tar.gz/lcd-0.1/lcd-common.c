#include "lcd-common.h"

#define CONTROL_INVERT_MASK 0xb /* 1011 */
#define ENABLE_ON  0x1 /* Control Bit 0. */
#define ENABLE_OFF 0x0
#define READ_MODE  0x2 /* Control Bit 1. */
#define WRITE_MODE 0x0
#define RS_DATA    0x4 /* Control Bit 2. (Register select.) */
#define RS_CONTROL 0x0

#define CMD_CLEAR_DISPLAY 0x1
#define CMD_RETURN_HOME 0x2
#define CMD_ENTRY_MODE_SET 0x4
#define CMD_DISPLAY_CONTROL 0x8
#define CMD_FUNCTION_SET 0x20
#define CMD_SET_DDRAM_ADDR 0x80

static void lcd_control_write(unsigned long port, unsigned char byte)
{
  /* Make sure correct bits are set first. */
  outb((RS_CONTROL | ENABLE_OFF | WRITE_MODE) ^ CONTROL_INVERT_MASK, port + 2);

  /* Place data on data port. */
  outb(byte, port);

  /* Toggle enable bit. */
  outb((RS_CONTROL | ENABLE_ON | WRITE_MODE) ^ CONTROL_INVERT_MASK, port + 2); 
  usleep(2);
  outb((RS_CONTROL | ENABLE_OFF | WRITE_MODE) ^ CONTROL_INVERT_MASK, port + 2); 
}

static void lcd_data_write(unsigned long port, unsigned char byte)
{
  /* Make sure correct bits are set first. */
  outb((RS_DATA | ENABLE_OFF | WRITE_MODE) ^ CONTROL_INVERT_MASK, port + 2);

  /* Place data on data port. */
  outb(byte, port);

  /* Toggle enable bit. */
  outb((RS_DATA | ENABLE_ON | WRITE_MODE) ^ CONTROL_INVERT_MASK, port + 2); 
  usleep(2);
  outb((RS_DATA | ENABLE_OFF | WRITE_MODE) ^ CONTROL_INVERT_MASK, port + 2); 
}

void lcd_init(unsigned long port, int cursor_on)
{
  /* Set 8-bit mode, and correct size. */
  lcd_control_write(port, CMD_FUNCTION_SET | 0x10 | 0x8 | 0x4);

  /* Set increment mode. */
  lcd_control_write(port, CMD_ENTRY_MODE_SET | 0x2);

  /* Turn on display and maybe a blinking cursor. */
  if (cursor_on)
    lcd_control_write(port, CMD_DISPLAY_CONTROL | 0x4 | 0x2 | 0x1);
  else
    lcd_control_write(port, CMD_DISPLAY_CONTROL | 0x4);

  lcd_control_write(port, CMD_CLEAR_DISPLAY);
  lcd_control_write(port, CMD_RETURN_HOME);
}

void lcd_clear_display(unsigned long port)
{
  lcd_control_write(port, CMD_CLEAR_DISPLAY);
}

void lcd_put_character(unsigned long port, unsigned char character)
{
  lcd_data_write(port, character);
}

/* Note: Specialized for 4x20 display. Starts at 0x0. */
void lcd_set_position(unsigned long port, int row, int col)
{
  short int address;

  if (col < 0 || col >= 20) {
    fprintf(stderr, "lcd_set_position: Column outside limits.\n");
    return;
  }

  switch (row) {
  case 0:
    address = col;
    break;
  case 1:
    address = col + 64;
    break;
  case 2:
    address = col + 20;
    break;
  case 3:
    address = col + 64 + 20;
    break;
  default:
    fprintf(stderr, "lcd_set_position: Row outside limits.\n");
    return;
  }

  lcd_control_write(port, CMD_SET_DDRAM_ADDR | address);
}

