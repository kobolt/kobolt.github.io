#include <stdio.h>
#include <stdlib.h>
#include <SDL2/SDL.h>



/* General configuration */
#define STRAWMAN_WORLD_FILE          "strawman.txt"
#define STRAWMAN_TEXTURE_FILE        "strawman.bmp"
#define STRAWMAN_BLOCKSIZE           25

#define STRAWMAN_WORLD_MAX_H         15
#define STRAWMAN_WORLD_MAX_W         200
#define STRAWMAN_WORLD_WINDOW_W      20

#define STRAWMAN_WORLD_EMPTY         '\0'
#define STRAWMAN_WORLD_BLOCK         '#'
#define STRAWMAN_WORLD_PLAYER        'P'
#define STRAWMAN_WORLD_ENEMY         'E'
#define STRAWMAN_WORLD_EXIT          'X'
#define STRAWMAN_WORLD_MINE          'M'
#define STRAWMAN_WORLD_COIN          'C'

#define STRAWMAN_GAME_SPEED          33
#define STRAWMAN_PLAYER_SPEED        5
#define STRAWMAN_JUMP_HEIGHT         15
#define STRAWMAN_ENEMIES_MAX         10
#define STRAWMAN_ENEMY_SPEED         2
#define STRAWMAN_TIME_OUT            60 * (1000 / STRAWMAN_GAME_SPEED)
#define STRAWMAN_COIN_VALUE          10
#define STRAWMAN_NUMBER_SPACING      15
#define STRAWMAN_TIME_LEFT_DIGITS    5
#define STRAWMAN_COINS_TAKEN_DIGITS  3
#define STRAWMAN_COINS_TAKEN_X       428

#define STRAWMAN_PLAYER_HEIGHT       50
#define STRAWMAN_PLAYER_WIDTH        25
#define STRAWMAN_ENEMY_HEIGHT        25
#define STRAWMAN_ENEMY_WIDTH         25

/* Texture configuration */
#define STRAWMAN_TEXTURE_OFFSET_PLAYER     0
#define STRAWMAN_TEXTURE_OFFSET_ENEMY     50
#define STRAWMAN_TEXTURE_OFFSET_STUFF     75
#define STRAWMAN_TEXTURE_OFFSET_NUMBER   100

#define STRAWMAN_TEXTURE_STANDING_STILL    0
#define STRAWMAN_TEXTURE_MOVING_RIGHT_1   25
#define STRAWMAN_TEXTURE_MOVING_RIGHT_2   50
#define STRAWMAN_TEXTURE_MOVING_LEFT_1    75
#define STRAWMAN_TEXTURE_MOVING_LEFT_2   100
#define STRAWMAN_TEXTURE_JUMPING_RIGHT   125
#define STRAWMAN_TEXTURE_JUMPING_LEFT    150
#define STRAWMAN_TEXTURE_FALLING         175

#define STRAWMAN_TEXTURE_EXIT_TOP          0
#define STRAWMAN_TEXTURE_EXIT_BOTTOM      25
#define STRAWMAN_TEXTURE_MINE             50
#define STRAWMAN_TEXTURE_COIN             75

#define STRAWMAN_TEXTURE_NUMBER_HEIGHT    18
#define STRAWMAN_TEXTURE_NUMBER_WIDTH     12



typedef struct strawman_object_s {
  int x, y; /* World co-ordinates in pixels. */
  int h, w; /* Object size in pixels. */
  int moving_left;
  int moving_right;
  int walk_toggle;
  int speed;
  int jumping;
  int jump_count;
  int falling;
} strawman_object_t;



static char strawman_world[STRAWMAN_WORLD_MAX_W][STRAWMAN_WORLD_MAX_H] = 
  {STRAWMAN_WORLD_EMPTY};
static int strawman_world_limit_w = 0;
static int strawman_scroll_offset = 0;



static int strawman_load_world(char *filename)
{
  int c, w, h;
  FILE *fh;
  
  fh = fopen(filename, "r");
  if (fh == NULL) {
    fprintf(stderr, "Error: Cannot open file '%s' for reading.\n", filename);
    return -1;
  }
  
  w = 0;
  h = STRAWMAN_WORLD_MAX_H - 1;
  while ((c = fgetc(fh)) != EOF) {

    if (c == '\n') {
      w++;
      h = STRAWMAN_WORLD_MAX_H - 1;
      if (w >= STRAWMAN_WORLD_MAX_W) {
        fprintf(stderr,
          "Warning: World read stopped due to reaching max width.\n");
        break;
      }
      continue;
    }

    if (h < 0) {
      fprintf(stderr, 
        "Warning: World read skipped due to reaching max height.\n");
      continue;
    }

    strawman_world[w][h] = c;
    h--;
  }
  fclose(fh);
  
  strawman_world_limit_w = w;
  return 0;
}



static void strawman_draw_world(SDL_Renderer *renderer, SDL_Texture *texture)
{
  int w, h;
  SDL_Rect src, dst;

  /* White background. */
  dst.x = 0;
  dst.y = 0;
  dst.w = strawman_world_limit_w * STRAWMAN_BLOCKSIZE;
  dst.h = STRAWMAN_WORLD_MAX_H * STRAWMAN_BLOCKSIZE;
  SDL_SetRenderDrawColor(renderer, 0xff, 0xff, 0xff, 0xff);
  SDL_RenderFillRect(renderer, &dst);

  for (w = 0; w < strawman_world_limit_w; w++) {
    
    /* Skip blocks scrolled past. */
    if (((w + 1) * STRAWMAN_BLOCKSIZE) < strawman_scroll_offset) {
      continue;
    } 
 
    /* Stop beyond blocks not yet reached. */
    if ((w * STRAWMAN_BLOCKSIZE) >
      (STRAWMAN_WORLD_WINDOW_W * STRAWMAN_BLOCKSIZE)
      + strawman_scroll_offset) {
      break;
    }

    /* Draw blocks and stuff. */
    for (h = 0; h < STRAWMAN_WORLD_MAX_H; h++) {
      dst.x = w * STRAWMAN_BLOCKSIZE - strawman_scroll_offset;
      dst.y = h * STRAWMAN_BLOCKSIZE;
      dst.w = STRAWMAN_BLOCKSIZE;
      dst.h = STRAWMAN_BLOCKSIZE;

      switch (strawman_world[w][h]) {
      case STRAWMAN_WORLD_BLOCK:
        SDL_SetRenderDrawColor(renderer, 0x00, 0x00, 0x00, 0xff);
        SDL_RenderFillRect(renderer, &dst);
        break;

      case STRAWMAN_WORLD_EXIT:
        src.y = STRAWMAN_TEXTURE_OFFSET_STUFF;
        src.w = STRAWMAN_BLOCKSIZE;
        src.h = STRAWMAN_BLOCKSIZE;

        src.x = STRAWMAN_TEXTURE_EXIT_TOP;
        SDL_RenderCopy(renderer, texture, &src, &dst);
        src.x = STRAWMAN_TEXTURE_EXIT_BOTTOM;
        dst.y += STRAWMAN_BLOCKSIZE;
        SDL_RenderCopy(renderer, texture, &src, &dst);
        break;

      case STRAWMAN_WORLD_MINE:
        src.y = STRAWMAN_TEXTURE_OFFSET_STUFF;
        src.w = STRAWMAN_BLOCKSIZE;
        src.h = STRAWMAN_BLOCKSIZE;
        src.x = STRAWMAN_TEXTURE_MINE;
        SDL_RenderCopy(renderer, texture, &src, &dst);
        break;

      case STRAWMAN_WORLD_COIN:
        src.y = STRAWMAN_TEXTURE_OFFSET_STUFF;
        src.w = STRAWMAN_BLOCKSIZE;
        src.h = STRAWMAN_BLOCKSIZE;
        src.x = STRAWMAN_TEXTURE_COIN;
        SDL_RenderCopy(renderer, texture, &src, &dst);
        break;
      }
    }
  }
}



static void strawman_init_object(strawman_object_t *o,
  int x, int y, int h, int w)
{
  o->x = x;
  o->y = y;
  o->w = w;
  o->h = h;
  o->moving_left  = 0;
  o->moving_right = 0;
  o->walk_toggle  = 0;
  o->speed        = 0;
  o->jumping      = 0;
  o->jump_count   = 0;
  o->falling      = 0;
}



static int strawman_init_player(strawman_object_t *p)
{
  int w, h;

  for (w = 0; w < strawman_world_limit_w; w++) {
    for (h = 0; h < STRAWMAN_WORLD_MAX_H; h++) {
      if (strawman_world[w][h] == STRAWMAN_WORLD_PLAYER) {
        strawman_init_object(p,
          w * STRAWMAN_BLOCKSIZE,
          h * STRAWMAN_BLOCKSIZE,
          STRAWMAN_PLAYER_HEIGHT, STRAWMAN_PLAYER_WIDTH);
        return 0;
      }
    }
  }

  return -1; /* Did not find player in worldfile. */
}



static void strawman_init_enemies(strawman_object_t *e, int *count)
{
  int w, h;

  *count = 0;
  for (w = 0; w < strawman_world_limit_w; w++) {
    for (h = 0; h < STRAWMAN_WORLD_MAX_H; h++) {
      if (strawman_world[w][h] == STRAWMAN_WORLD_ENEMY) {
        strawman_init_object(e + (*count),
          w * STRAWMAN_BLOCKSIZE,
          h * STRAWMAN_BLOCKSIZE,
          STRAWMAN_ENEMY_HEIGHT, STRAWMAN_ENEMY_WIDTH);
        (e + (*count))->speed = STRAWMAN_ENEMY_SPEED;
        (e + (*count))->moving_left = 1;

        *count = *count + 1;

        if (*count >= STRAWMAN_ENEMIES_MAX) {
          fprintf(stderr, "Warning: Too many enemies on map.\n");
          break;
        }
      }
    }
  }
}



static void strawman_draw_object(strawman_object_t *o,
  SDL_Renderer *renderer, SDL_Texture *texture, int offset)
{
  SDL_Rect src, dst;

  src.y = offset;
  src.w = o->w;
  src.h = o->h;

  if (o->jumping) {
    if (o->moving_right)
      src.x = STRAWMAN_TEXTURE_JUMPING_RIGHT;
    else if (o->moving_left)
      src.x = STRAWMAN_TEXTURE_JUMPING_LEFT;
    else
      src.x = STRAWMAN_TEXTURE_FALLING;
  } else if (o->falling) {
    src.x = STRAWMAN_TEXTURE_FALLING;
  } else {
    if (o->moving_right)
      if (o->walk_toggle) {
        src.x = STRAWMAN_TEXTURE_MOVING_RIGHT_1;
        o->walk_toggle = 0;
      } else {
        src.x = STRAWMAN_TEXTURE_MOVING_RIGHT_2;
        o->walk_toggle = 1;
      }
    else if (o->moving_left)
      if (o->walk_toggle) {
        src.x = STRAWMAN_TEXTURE_MOVING_LEFT_1;
        o->walk_toggle = 0;
      } else {
        src.x = STRAWMAN_TEXTURE_MOVING_LEFT_2;
        o->walk_toggle = 1;
      }
    else
      src.x = STRAWMAN_TEXTURE_STANDING_STILL;
  }

  dst.x = o->x - strawman_scroll_offset;
  dst.y = o->y;
  dst.w = o->w;
  dst.h = o->h;

  SDL_RenderCopy(renderer, texture, &src, &dst);
}



static int power_of_ten(int n)
{
  if (n == 0)
    return 1;
  else
    return 10 * power_of_ten(n - 1);
}



static void strawman_draw_number(SDL_Renderer *renderer,
  SDL_Texture *texture, int number, int digits, int x_offset)
{
  SDL_Rect src, dst;
  int factor, digit;

  src.y = STRAWMAN_TEXTURE_OFFSET_NUMBER;
  src.w = STRAWMAN_TEXTURE_NUMBER_WIDTH;
  src.h = STRAWMAN_TEXTURE_NUMBER_HEIGHT;
  dst.w = STRAWMAN_TEXTURE_NUMBER_WIDTH;
  dst.h = STRAWMAN_TEXTURE_NUMBER_HEIGHT;

  for (factor = digits - 1; factor >= 0; factor--) {
    digit = number / power_of_ten(factor);
    number -= digit * power_of_ten(factor);

    src.x = digit * STRAWMAN_TEXTURE_NUMBER_WIDTH;
    dst.x = x_offset + ((digits + 1) * STRAWMAN_NUMBER_SPACING) - 
      (STRAWMAN_NUMBER_SPACING + (STRAWMAN_NUMBER_SPACING * factor));
    dst.y = STRAWMAN_NUMBER_SPACING;
    SDL_RenderCopy(renderer, texture, &src, &dst);
  }
}



static int strawman_left_collision(strawman_object_t *o,
  char target, int destroy)
{
  int i, h, w, b;

  w = (o->x / STRAWMAN_BLOCKSIZE);
  if (w >= strawman_world_limit_w || w < 0) {
    return 0;
  }
  for (i = 0; i < o->h; i++) {
    h = (o->y + i) / STRAWMAN_BLOCKSIZE;
    if (h >= STRAWMAN_WORLD_MAX_H || h < 0) {
      return 0;
    }
    if (strawman_world[w][h] == target) {
      for (b = 0; b < STRAWMAN_BLOCKSIZE; b++) {
        if ((o->x + b) / STRAWMAN_BLOCKSIZE != w) {
          if (destroy) {
            strawman_world[w][h] = STRAWMAN_WORLD_EMPTY;
          }
          return b;
        }
      }
      return 0;
    }
  }

  return 0;
}



static int strawman_right_collision(strawman_object_t *o,
  char target, int destroy)
{
  int i, h, w, b;

  w = ((o->x + o->w - 1) / STRAWMAN_BLOCKSIZE);
  if (w >= strawman_world_limit_w || w < 0) {
    return 0;
  }
  for (i = 0; i < o->h; i++) {
    h = (o->y + i) / STRAWMAN_BLOCKSIZE;
    if (h >= STRAWMAN_WORLD_MAX_H || h < 0) {
      return 0;
    }
    if (strawman_world[w][h] == target) {
      for (b = 0; b < STRAWMAN_BLOCKSIZE; b++) {
        if ((o->x + o->w - 1 - b) / STRAWMAN_BLOCKSIZE != w) {
          if (destroy) {
            strawman_world[w][h] = STRAWMAN_WORLD_EMPTY;
          }
          return b;
        }
      }
      return 0;
    }
  }

  return 0;
}



static int strawman_top_collision(strawman_object_t *o,
  char target, int destroy)
{
  int i, h, w, b;

  h = (o->y / STRAWMAN_BLOCKSIZE);
  if (h >= STRAWMAN_WORLD_MAX_H || h < 0) {
    return 0;
  }
  for (i = 0; i < o->w; i++) {
    w = (o->x + i) / STRAWMAN_BLOCKSIZE;
    if (w >= strawman_world_limit_w || w < 0) {
      return 0;
    }
    if (strawman_world[w][h] == target) {
      for (b = 0; b < STRAWMAN_BLOCKSIZE; b++) {
        if ((o->y + b) / STRAWMAN_BLOCKSIZE != h) {
          if (destroy) {
            strawman_world[w][h] = STRAWMAN_WORLD_EMPTY;
          }
          return b;
        }
      }
      return 0;
    }
  }

  return 0;
}



static int strawman_bottom_collision(strawman_object_t *o,
  char target, int destroy)
{
  int i, h, w, b;

  h = ((o->y + o->h - 1) / STRAWMAN_BLOCKSIZE);
  if (h >= STRAWMAN_WORLD_MAX_H || h < 0) {
    return 0;
  }
  for (i = 0; i < o->w; i++) {
    w = (o->x + i) / STRAWMAN_BLOCKSIZE;
    if (w >= strawman_world_limit_w || w < 0) {
      return 0;
    }
    if (strawman_world[w][h] == target) {
      for (b = 0; b < STRAWMAN_BLOCKSIZE; b++) {
        if ((o->y + o->h - 1 - b) / STRAWMAN_BLOCKSIZE != h) {
          if (destroy) {
            strawman_world[w][h] = STRAWMAN_WORLD_EMPTY;
          }
          return b;
        }
      }
      return 0;
    }
  }

  return 0;
}



static int strawman_object_near_edge(strawman_object_t *o)
{
  int h, w;

  h = ((o->y + o->h - 1) / STRAWMAN_BLOCKSIZE) + 1;
  if (h >= STRAWMAN_WORLD_MAX_H || h < 0)
    return 1;

  w = (o->x + (o->w / 2)) / STRAWMAN_BLOCKSIZE;
  if (w >= strawman_world_limit_w || w < 0)
    return 1;

  if (strawman_world[w][h] != STRAWMAN_WORLD_BLOCK) {
    return 1;
  }
 
  return 0;
}



static int strawman_object_collision(strawman_object_t *o1,
  strawman_object_t *o2)
{
  if (((o1->x + o1->w) > o2->x) && ((o1->x < (o2->x + o2->w)))) {
    if (((o1->y + o1->h) > o2->y) && ((o1->y < (o2->y + o2->h)))) {
      return 1;
    }
  }
  return 0;
}



Uint32 strawman_timer_callback(Uint32 interval, void *param)
{
  SDL_Event event;
  SDL_UserEvent uevent;

  uevent.type = SDL_USEREVENT;
  uevent.code = 0;
  uevent.data1 = NULL;
  uevent.data2 = NULL;

  event.type = SDL_USEREVENT;
  event.user = uevent;

  SDL_PushEvent(&event);
  return interval;
}



void strawman_end(char *message, int time_left, int coins_taken)
{
  if (message != NULL) {
    printf("Died: %s\n", message);
  } else {
    printf("Score: %d (Time Left: %d, Coins: %d)\n",
      time_left + (coins_taken * STRAWMAN_COIN_VALUE), time_left, coins_taken);
  }
  exit(0);
}



int main(void)
{
  SDL_Event event;
  SDL_Window *window;
  SDL_Renderer *renderer;
  SDL_Surface *temp_surface;
  SDL_Texture *texture;
  strawman_object_t player;
  strawman_object_t enemies[STRAWMAN_ENEMIES_MAX];
  int enemy, enemy_count, enemy_prev_x_pos;
  int time_left = STRAWMAN_TIME_OUT;
  int coins_taken = 0;

  /* Load resources and initalize data. */
  if (strawman_load_world(STRAWMAN_WORLD_FILE) != 0) {
    exit(1);
  }
  if (strawman_init_player(&player) != 0) {
    fprintf(stderr, "Error: Could not locate player start in world file.\n");
    exit(1);
  } 
  strawman_init_enemies(enemies, &enemy_count);

  /* Initialize SDL. */
  if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER) != 0) {
    fprintf(stderr, "Error: Unable to initalize SDL: %s\n", SDL_GetError());
    exit(1);
  }
  atexit(SDL_Quit);

  window = SDL_CreateWindow("Strawman",
    SDL_WINDOWPOS_UNDEFINED,
    SDL_WINDOWPOS_UNDEFINED,
    STRAWMAN_WORLD_WINDOW_W * STRAWMAN_BLOCKSIZE,
    STRAWMAN_WORLD_MAX_H * STRAWMAN_BLOCKSIZE, 0);
  if (window == NULL) {
    fprintf(stderr, "Error: Unable to set video mode: %s\n", SDL_GetError());
    exit(1);
  }
  
  renderer = SDL_CreateRenderer(window, -1, 0);
  if (renderer == NULL) {
    fprintf(stderr, "Error: Unable to create renderer: %s\n", SDL_GetError());
    exit(1);
  }

  temp_surface = SDL_LoadBMP(STRAWMAN_TEXTURE_FILE);
  texture = SDL_CreateTextureFromSurface(renderer, temp_surface);
  if (texture == NULL) {
    fprintf(stderr, "Error: Could not load textures.\n");
    exit(1);
  }
  SDL_FreeSurface(temp_surface);

  /* Main game loop. */
  SDL_AddTimer(STRAWMAN_GAME_SPEED, strawman_timer_callback, NULL);
  while (1) {

    /* Collect input and set appropriate flags. */
    if (SDL_WaitEvent(&event) == 1) {
      switch(event.type) {
      case SDL_QUIT:
        exit(0);
        break;

      case SDL_KEYDOWN:
        switch (event.key.keysym.sym) {
        case SDLK_q:
          exit(0);
          break;

        case SDLK_UP:
          if (! player.falling)
            player.jumping = 1;
          break;

        case SDLK_LEFT:
          player.moving_left = 1;
          break;

        case SDLK_RIGHT:
          player.moving_right = 1;
          break;

        default:
          break;
        }
        break;

      case SDL_KEYUP:
        switch (event.key.keysym.sym) {
        case SDLK_LEFT:
          player.moving_left = 0;
          player.speed = 0;
          break;

        case SDLK_RIGHT:
          player.moving_right = 0;
          player.speed = 0;
          break;

        default:
          break;
        }
        break;
      }
    }
    
    /* Move enemies */
    for (enemy = 0; enemy < enemy_count; enemy++) {
      enemy_prev_x_pos = enemies[enemy].x;

      if (enemies[enemy].moving_left) {
        enemies[enemy].x -= enemies[enemy].speed;
      }
      if (enemies[enemy].moving_right) {
        enemies[enemy].x += enemies[enemy].speed;
      }
      enemies[enemy].x += strawman_left_collision(&enemies[enemy],
        STRAWMAN_WORLD_BLOCK, 0);
      enemies[enemy].x += strawman_left_collision(&enemies[enemy],
        STRAWMAN_WORLD_COIN, 0);
      enemies[enemy].x += strawman_left_collision(&enemies[enemy],
        STRAWMAN_WORLD_MINE, 0);
      enemies[enemy].x -= strawman_right_collision(&enemies[enemy],
        STRAWMAN_WORLD_BLOCK, 0);
      enemies[enemy].x -= strawman_right_collision(&enemies[enemy],
        STRAWMAN_WORLD_COIN, 0);
      enemies[enemy].x -= strawman_right_collision(&enemies[enemy],
        STRAWMAN_WORLD_MINE, 0);

      /* Turn around if hitting a wall, coin, mine or near edge. */
      if (enemy_prev_x_pos == enemies[enemy].x ||
        strawman_object_near_edge(&enemies[enemy])) {
        if (enemies[enemy].moving_left) {
          enemies[enemy].moving_left  = 0;
          enemies[enemy].moving_right = 1;
        } else {
          enemies[enemy].moving_left  = 1;
          enemies[enemy].moving_right = 0;
        }
      }
    }

    /* Handle player jumping and falling. */
    if (player.jumping) {
      if (player.jump_count < STRAWMAN_JUMP_HEIGHT) {
        player.y -= STRAWMAN_PLAYER_SPEED;
        player.jump_count++;
      } else {
        player.jumping = 0;
        player.jump_count = 0;
        player.falling = 1;
      }
    } else {
      player.falling = 1;
      player.y += STRAWMAN_PLAYER_SPEED * 2; /* Constant gravity drag. */
    }
    if (strawman_top_collision(&player, STRAWMAN_WORLD_BLOCK, 0)) {
      player.jumping = 0;
      player.jump_count = 0;
      player.falling = 1;
    }
    player.y += strawman_top_collision(&player, STRAWMAN_WORLD_BLOCK, 0);
    if (strawman_bottom_collision(&player, STRAWMAN_WORLD_BLOCK, 0)) {
      player.falling = 0;
    }
    player.y -= strawman_bottom_collision(&player, STRAWMAN_WORLD_BLOCK, 0);

    /* Move player left and right. */
    if (player.moving_left) {
      player.speed++;
      if (player.speed > STRAWMAN_PLAYER_SPEED) {
        player.speed--;
      }
      player.x -= player.speed;
    }
    if (player.moving_right) {
      player.speed++;
      if (player.speed > STRAWMAN_PLAYER_SPEED) {
        player.speed--;
      }
      player.x += player.speed;
    }
    player.x += strawman_left_collision(&player, STRAWMAN_WORLD_BLOCK, 0);
    player.x -= strawman_right_collision(&player, STRAWMAN_WORLD_BLOCK, 0);

    /* Player and enemy collision. */
    for (enemy = 0; enemy < enemy_count; enemy++) {
      if (strawman_object_collision(&player, &enemies[enemy])) {
        strawman_end("Killed by an enemy", time_left, coins_taken);
      }
    }

    /* Player and exit collision. */
    if (strawman_left_collision(&player, STRAWMAN_WORLD_EXIT, 0) ||
      strawman_right_collision(&player, STRAWMAN_WORLD_EXIT, 0)) {
      strawman_end(NULL, time_left, coins_taken);
    }

    /* Player and mine collision. */
    if (strawman_left_collision(&player, STRAWMAN_WORLD_MINE, 0) ||
      strawman_right_collision(&player, STRAWMAN_WORLD_MINE, 0)  ||
      strawman_top_collision(&player, STRAWMAN_WORLD_MINE, 0)    ||
      strawman_bottom_collision(&player, STRAWMAN_WORLD_MINE, 0)) {
      strawman_end("Killed by a mine", time_left, coins_taken);
    }

    /* Player and coin collision. */
    if (strawman_left_collision(&player, STRAWMAN_WORLD_COIN, 1) ||
      strawman_right_collision(&player, STRAWMAN_WORLD_COIN, 1)  ||
      strawman_top_collision(&player, STRAWMAN_WORLD_COIN, 1)    ||
      strawman_bottom_collision(&player, STRAWMAN_WORLD_COIN, 1)) {
      coins_taken++;
    }

    /* Detect if player gets outside screen/world area. */
    if (player.y >= STRAWMAN_WORLD_MAX_H * STRAWMAN_BLOCKSIZE) {
      strawman_end("Fell below the world", time_left, coins_taken);
    }
    if (player.x >= strawman_world_limit_w * STRAWMAN_BLOCKSIZE) {
      strawman_end("Went outside the world", time_left, coins_taken);
    }
    if (player.x < 0 - STRAWMAN_BLOCKSIZE) {
      strawman_end("Went outside the world", time_left, coins_taken);
    }

    /* Calculate time left. */
    time_left--;
    if (time_left < 0) {
      strawman_end("No more time left", time_left, coins_taken);
    }

    /* Update scroll offset. */
    int low_limit = ((STRAWMAN_WORLD_WINDOW_W * STRAWMAN_BLOCKSIZE) / 2); 
    int high_limit = (strawman_world_limit_w * STRAWMAN_BLOCKSIZE) - low_limit;
    if (player.x > low_limit) {
      if (player.x < high_limit) {
        strawman_scroll_offset = player.x - low_limit;
      }
    }

    /* Draw graphics. */
    strawman_draw_world(renderer, texture);
    strawman_draw_object(&player, renderer, texture,
      STRAWMAN_TEXTURE_OFFSET_PLAYER);
    for (enemy = 0; enemy < enemy_count; enemy++) {
      strawman_draw_object(&enemies[enemy], renderer, texture,
        STRAWMAN_TEXTURE_OFFSET_ENEMY);
    }
    strawman_draw_number(renderer, texture,
      time_left, STRAWMAN_TIME_LEFT_DIGITS, 0);
    strawman_draw_number(renderer, texture,
      coins_taken, STRAWMAN_COINS_TAKEN_DIGITS, STRAWMAN_COINS_TAKEN_X);
    SDL_RenderPresent(renderer);
  }
  
  exit(0);
}

