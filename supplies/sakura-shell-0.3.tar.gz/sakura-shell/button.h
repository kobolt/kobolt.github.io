#ifndef _BUTTON_H
#define _BUTTON_H

void button_setup(void);
void button_state_print(void);

#endif /* _BUTTON_H */
