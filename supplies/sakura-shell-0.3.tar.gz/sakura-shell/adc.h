#ifndef _ADC_H
#define _ADC_H

void adc_setup(void);
void adc_data_print(void);

#endif /* _ADC_H */
