#!/bin/bash
set -e

TARGET="i486-linux-uclibc"
# PREFIX="${HOME}/opt/gcc-${TARGET}/"
PREFIX="`pwd`/gcc-${TARGET}/"
SYSROOT="${PREFIX}/${TARGET}/sysroot"
MAKE_JOBS="-j32"

GCC_SRC="gcc-15.1.0.tar.xz"
BINUTILS_SRC="binutils-2.44.tar.xz"
UCLIBC_SRC="uClibc-ng-1.0.52.tar.xz"
LINUX_SRC="linux-6.15.tar.xz"
BUSYBOX_SRC="busybox-1.37.0.tar.bz2"

export PATH="${PREFIX}bin:$PATH"

# Prepare Prefix and System Root
if [ -d "$SYSROOT" ]; then
  echo "Old system root directory detected, please remove it."
  exit 1
else
  mkdir -p "$SYSROOT/usr"
fi

# Prepare Build Directories:
if [ -d build ]; then
  echo "Old build directory detected, please remove it."
  exit 1
else
  mkdir -p build/binutils
  mkdir -p build/gcc-stage1
  mkdir -p build/gcc-stage2
  mkdir -p build/uclibc
  mkdir -p build/linux
  mkdir -p build/busybox
fi

# Unpack Sources:
if [ -d source ]; then
  cd source
  tar -xvJf "$GCC_SRC"
  tar -xvJf "$BINUTILS_SRC"
  tar -xvJf "$UCLIBC_SRC" -C ../build/uclibc
  tar -xvJf "$LINUX_SRC" -C ../build/linux
  tar -xvjf "$BUSYBOX_SRC" -C ../build/busybox
  cd -
else
  echo "No source directory, please download sources."
  exit 1
fi

# Install Linux 6.15 Headers:
cd build/linux/linux-*
make ARCH=x86 defconfig
make ARCH=x86 INSTALL_HDR_PATH="$SYSROOT/usr" headers_install
cd -

# Build binutils:
cd build/binutils
../../source/binutils-*/configure --target="$TARGET" --prefix="$PREFIX" --with-sysroot="$SYSROOT" --disable-werror --enable-languages=c,c++ --enable-shared --without-newlib --disable-libgomp --enable-fast-install=N/A
make all-{binutils,ld,gas} $MAKE_JOBS
make install-{binutils,ld,gas}
cd -

# Build Stage 1 GCC (Without libgcc):
cd build/gcc-stage1
../../source/gcc-*/configure --target=$TARGET --prefix=$PREFIX --with-sysroot=$SYSROOT --disable-fast-install --disable-werror --disable-multilib --enable-languages=c --without-headers --disable-shared --disable-libssp --disable-libmudflap --without-newlib --disable-libgomp
make all-gcc $MAKE_JOBS
make install-gcc
cd -

# Install uClibc headers:
cd build/uclibc/uClibc-*
cp -v ../../../config-uclibc .config
sed -i -e "s%KERNEL_HEADERS=.*%KERNEL_HEADERS=\"$SYSROOT/usr/include/\"%" .config
make ARCH=i486 PREFIX="$SYSROOT" install_headers
cd -

# Build Stage 1 GCC (libgcc):
cd build/gcc-stage1
make all-target-libgcc $MAKE_JOBS
make install-target-libgcc
cd -

# Build uClibc:
cd build/uclibc/uClibc-*
make ARCH=i486 PREFIX="$SYSROOT" $MAKE_JOBS
make ARCH=i486 PREFIX="$SYSROOT" install
cd -

# Build Stage 2 GCC:
cd build/gcc-stage2
../../source/gcc-*/configure --target=$TARGET --prefix=$PREFIX --with-sysroot=$SYSROOT --with-cpu=i486 --enable-fast-install=N/A --disable-werror --enable-languages=c,c++ --enable-shared --without-newlib --disable-libgomp
make all-{gcc,target-libgcc,target-libstdc++-v3} $MAKE_JOBS
make install-{gcc,target-libgcc,target-libstdc++-v3}
cd -

# Build Linux 6.15:
cd build/linux/linux-*
cp -v ../../../config-linux .config
make ARCH=x86 CROSS_COMPILE=i486-linux-uclibc- bzImage $MAKE_JOBS
cp -v ./arch/x86/boot/bzImage ../../../bzImage
cd -

# Build Busybox:
cd build/busybox/busybox-*
cp -v ../../../config-busybox .config
make CROSS_COMPILE=i486-linux-uclibc- $MAKE_JOBS
cd -

