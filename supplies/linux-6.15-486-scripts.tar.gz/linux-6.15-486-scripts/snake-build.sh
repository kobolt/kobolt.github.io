#!/bin/bash
set -e

TARGET="i486-linux-uclibc"
# PREFIX="${HOME}/opt/gcc-${TARGET}/"
PREFIX="`pwd`/gcc-${TARGET}/"

export PATH="${PREFIX}bin:$PATH"

i486-linux-uclibc-gcc snake.c -o snake -I${PREFIX}/include -I${PREFIX}/include/ncurses -lncurses -L${PREFIX}/lib -static

