#!/bin/bash
set -e

ROOTFS="`pwd`/rootfs/"

TARGET="i486-linux-uclibc"
# PREFIX="${HOME}/opt/gcc-${TARGET}/"
PREFIX="`pwd`/gcc-${TARGET}/"
SYSROOT="${PREFIX}/${TARGET}/sysroot"

export PATH="${PREFIX}bin:$PATH"

if [ -d "$ROOTFS" ]; then
  echo "Old root FS directory detected, please remove it."
  exit 1
fi
mkdir -p "$ROOTFS"

# Install Busybox:
cd build/busybox/busybox-*
make CROSS_COMPILE=i486-linux-uclibc- CONFIG_PREFIX="$ROOTFS" install
cd -

# Create some essential directories:
cd "$ROOTFS"
mkdir -v etc
mkdir -v etc/init.d
mkdir -v lib
mkdir -v proc
mkdir -v sys
mkdir -v tmp
mkdir -v root
mkdir -v dev
cd -

# Initial rc.S:
cat > rcS <<EOF
#!/bin/sh
mount -t proc /proc /proc
mount -t tmpfs /tmp /tmp
loadkmap < /etc/no-latin1.bmap
hostname busybox
EOF
mv -v rcS "$ROOTFS/etc/init.d/"

# Initial inittab:
cat > inittab <<EOF
::sysinit:/etc/init.d/rcS
::respawn:-/bin/sh
::ctrlaltdel:/sbin/reboot
::shutdown:/bin/umount -a -r
::restart:/sbin/init
EOF
mv -v inittab "$ROOTFS/etc/"

# Copy this system's keymap:
loadkeys -b /usr/share/kbd/keymaps/i386/qwerty/no-latin1.map.gz > "$ROOTFS/etc/no-latin1.bmap"

# Generate termcap if NCurses was built:
if [ -d build/ncurses ]; then
  tic -C -t -r -e 'linux,vt102,vt100,xterm,ansi' source/ncurses-*/misc/terminfo.src > "$ROOTFS/etc/termcap"
fi

# Copy snake if it was built:
if [ -x snake ]; then
  cp -v snake "$ROOTFS/bin/snake"
fi

# Make everything root user:
sudo chown -v -R root:root "$ROOTFS"

# SetUID on busybox binary:
sudo chmod +s "$ROOTFS/bin/busybox"

# Make rcS executable:
sudo chmod +x "$ROOTFS/etc/init.d/rcS"

# Make Compressed ROM archive:
mkfs.cramfs rootfs rootfs.cramfs

