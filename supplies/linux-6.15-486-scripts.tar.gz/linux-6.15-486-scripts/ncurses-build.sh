#!/bin/bash
set -e

TARGET="i486-linux-uclibc"
# PREFIX="${HOME}/opt/gcc-${TARGET}/"
PREFIX="`pwd`/gcc-${TARGET}/"
MAKE_JOBS="-j32"

NCURSES_SRC="ncurses-6.5.tar.gz"

export PATH="${PREFIX}bin:$PATH"

# Unpack NCurses source:
mkdir -p build/ncurses
cd source
tar -xvzf "$NCURSES_SRC"
cd -

# Build NCurses:
cd build/ncurses
CFLAGS="--std=gnu17" ../../source/ncurses-*/configure --build=x86_64 --host="$TARGET" --target="$TARGET" --prefix="$PREFIX" --disable-database --enable-termcap --disable-widec --without-cxx-binding --without-ada
CFLAGS="--std=gnu17" make $MAKE_JOBS
make install
cd -

