#!/bin/sh

if [ ! -f disk.dd ]; then
  dd if=/dev/zero of=disk.dd bs=512 count=65536
fi

if [ "$1" = "s" ]; then
  qemu-system-i386 \
    -kernel bzImage \
    -initrd rootfs.cramfs \
    -append "earlycon=uart8250,io,0x3f8,115200n8 console=ttyS0" \
    -cpu 486 \
    -m 32 \
    -serial mon:stdio \
    -nographic \
    -drive file=disk.dd,format=raw,if=none,id=dr0 \
    -device drive=dr0,driver=ide-hd \
    -netdev user,id=net0 \
    -device ne2k_isa,irq=5,netdev=net0
else
  qemu-system-i386 \
    -kernel bzImage \
    -initrd rootfs.cramfs \
    -cpu 486 \
    -m 32 \
    -monitor stdio \
    -drive file=disk.dd,format=raw,if=none,id=dr0 \
    -device drive=dr0,driver=ide-hd \
    -netdev user,id=net0 \
    -device ne2k_isa,irq=5,netdev=net0
fi

