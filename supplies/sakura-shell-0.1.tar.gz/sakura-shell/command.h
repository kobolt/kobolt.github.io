#ifndef _COMMAND_H
#define _COMMAND_H

void command_loop(void);

#endif /* _COMMAND_H */
