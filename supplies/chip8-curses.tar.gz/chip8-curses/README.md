# CHIP-8 Interpreter using Curses
A simple implementation of a [CHIP-8](https://en.wikipedia.org/wiki/CHIP-8) interpreter using the curses terminal handling library, compatible with most Unix systems.

Build it with make:
```
make
```

