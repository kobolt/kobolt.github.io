#include <curses.h>
#include <signal.h>
#include <stdarg.h>
#if (__STDC_VERSION__ >= 199901L)
#include <stdint.h>
#else
typedef unsigned short uint16_t;
typedef unsigned char uint8_t;
#endif /* (__STDC_VERSION__ >= 199901L) */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#define CHIP8_STACK_SIZE 16
#define CHIP8_SCREEN_Y_SIZE 32
#define CHIP8_SCREEN_X_SIZE 64
#define CHIP8_KEY_NONE 0xFF
#define CHIP8_KEY_LINGER 5
#define CHIP8_CYCLE_LIMIT 1024

#define CHIP8_TRACE_BUFFER_SIZE 256
#define CHIP8_TRACE_BUFFER_ENTRY 80

typedef struct chip8_s {
  uint16_t pc;
  uint16_t i;
  uint8_t sp;
  uint8_t dt;
  uint8_t st;
  uint8_t k;
  uint8_t v[16];
  uint8_t m[4096];
  uint16_t stack[CHIP8_STACK_SIZE];
  uint8_t screen[CHIP8_SCREEN_Y_SIZE][CHIP8_SCREEN_X_SIZE];
} chip8_t;

static const uint16_t chip8_font[16] = {
  0x100, 0x110, 0x120, 0x130, 0x140, 0x150, 0x160, 0x170,
  0x180, 0x190, 0x1A0, 0x1B0, 0x1C0, 0x1D0, 0x1E0, 0x1F0,
};

static chip8_t chip8;
static int chip8_timer_expired = 0;



#ifdef CHIP8_TRACE
static char chip8_trace_buffer[CHIP8_TRACE_BUFFER_SIZE]
                              [CHIP8_TRACE_BUFFER_ENTRY];
static int chip8_trace_buffer_index = 0;



static void chip8_trace(uint16_t opcode, const char *format, ...)
{
  va_list args;
  char b[CHIP8_TRACE_BUFFER_SIZE];
  int n;
  int i;

  n = 0;
  n += snprintf(&b[n], sizeof(b) - n, "%04x   ", chip8.pc - 2);

  n += snprintf(&b[n], sizeof(b) - n, "%04x   ", opcode);

  for (i = 0; i < chip8.sp; i++) {
    n += snprintf(&b[n], sizeof(b) - n, "_");
  }

  va_start(args, format);
  n += vsnprintf(&b[n], sizeof(b) - n, format, args);
  va_end(args);

  n += snprintf(&b[n], sizeof(b) - n, "\n");

  strncpy(chip8_trace_buffer[chip8_trace_buffer_index],
    b, CHIP8_TRACE_BUFFER_ENTRY);
  chip8_trace_buffer_index++;
  if (chip8_trace_buffer_index >= CHIP8_TRACE_BUFFER_SIZE) {
    chip8_trace_buffer_index = 0;
  }
}



static void chip8_trace_init(void)
{
  int i;

  for (i = 0; i < CHIP8_TRACE_BUFFER_SIZE; i++) {
    chip8_trace_buffer[i][0] = '\0';
  }
  chip8_trace_buffer_index = 0;
}



void chip8_trace_dump(FILE *fh)
{
  int i;

  for (i = chip8_trace_buffer_index; i < CHIP8_TRACE_BUFFER_SIZE; i++) {
    if (chip8_trace_buffer[i][0] != '\0') {
      fprintf(fh, "%s", chip8_trace_buffer[i]);
    }
  }
  for (i = 0; i < chip8_trace_buffer_index; i++) {
    if (chip8_trace_buffer[i][0] != '\0') {
      fprintf(fh, "%s", chip8_trace_buffer[i]);
    }
  }
}
#else
#if (__STDC_VERSION__ >= 199901L)
#define chip8_trace(...)
#else
static void chip8_trace(uint16_t opcode, const char *format, ...) {}
#endif /* (__STDC_VERSION__ >= 199901L) */
#endif /* CHIP8_TRACE */



static void chip8_screen_exit(void)
{
  endwin();
}



static void chip8_screen_init(void)
{
  initscr();
  noecho();
  keypad(stdscr, TRUE);
  timeout(0);
}



static void chip8_screen_display(void)
{
  uint8_t x;
  uint8_t y;

  for (y = 0; y < CHIP8_SCREEN_Y_SIZE; y++) {
    for (x = 0; x < CHIP8_SCREEN_X_SIZE; x++) {
      mvprintw(y, x, "%c", chip8.screen[y][x] ? '#' : ' ');
    }
  }
  refresh();
}



static void chip8_screen_draw(uint8_t x_start, uint8_t y_start, uint8_t size)
{
  uint8_t i;
  uint8_t j;
  uint8_t value;
  uint8_t y;
  uint8_t x;
  int unset;

  y_start %= CHIP8_SCREEN_Y_SIZE;
  x_start %= CHIP8_SCREEN_X_SIZE;
  unset = 0;

  for (i = 0; i < size; i++) {
    y = (y_start + i);
    if (y >= CHIP8_SCREEN_Y_SIZE) {
      break;
    }
    for (j = 0; j < 8; j++) {
      x = (x_start + j);
      if (x >= CHIP8_SCREEN_X_SIZE) {
        break;
      }
      value = (chip8.m[(chip8.i + i) & 0xFFF] >> (7 - j)) & 1;
      unset |= (value & chip8.screen[y][x]);
      chip8.screen[y][x] ^= value;
    }
  }

  if (unset) {
    chip8.v[0xF] = 1;
  } else {
    chip8.v[0xF] = 0;
  }
}



static void chip8_screen_clear(void)
{
  uint8_t x;
  uint8_t y;

  for (y = 0; y < CHIP8_SCREEN_Y_SIZE; y++) {
    for (x = 0; x < CHIP8_SCREEN_X_SIZE; x++) {
      chip8.screen[y][x] = 0;
    }
  }
}



static void chip8_key_read(void)
{
  static int linger = 0;
  int ch;

  if (linger > 0) {
    linger--;
    return;
  }

  ch = getch();
  switch (ch) {
  case '1':
    chip8.k = 0x1;
    break;

  case '2':
    chip8.k = 0x2;
    break;

  case '3':
    chip8.k = 0x3;
    break;

  case '4':
    chip8.k = 0xC;
    break;

  case 'q':
    chip8.k = 0x4;
    break;

  case 'w':
    chip8.k = 0x5;
    break;

  case 'e':
    chip8.k = 0x6;
    break;

  case 'r':
    chip8.k = 0xD;
    break;

  case 'a':
    chip8.k = 0x7;
    break;

  case 's':
    chip8.k = 0x8;
    break;

  case 'd':
    chip8.k = 0x9;
    break;

  case 'f':
    chip8.k = 0xE;
    break;

  case 'z':
    chip8.k = 0xA;
    break;

  case 'x':
    chip8.k = 0x0;
    break;

  case 'c':
    chip8.k = 0xB;
    break;

  case 'v':
    chip8.k = 0xF;
    break;

  default:
    chip8.k = CHIP8_KEY_NONE;
    break;
  }

  if (chip8.k != CHIP8_KEY_NONE) {
    linger = CHIP8_KEY_LINGER;
  }
}



static void chip8_signal_handler(int sig)
{
  switch (sig) {
  case SIGALRM:
    chip8_timer_expired = 1;
    break;

  case SIGINT:
    exit(EXIT_SUCCESS);
    break;
  }
}



static void chip8_timer_check()
{
  if (chip8_timer_expired) {
    if (chip8.dt > 0) {
      chip8.dt--;
    }
    if (chip8.st > 0) {
      beep();
      chip8.st--;
    }
    chip8_key_read();
    chip8_timer_expired = 0;
  }
}



static void chip8_init()
{
  memset(&chip8, 0, sizeof(chip8_t));
  chip8.k = CHIP8_KEY_NONE;
}



static void chip8_panic(const char *format, ...)
{
  va_list args;

  chip8_screen_exit();

  va_start(args, format);
  vfprintf(stderr, format, args);
  va_end(args);

  exit(EXIT_FAILURE);
}



static int chip8_load(const char *filename)
{
  FILE *fh;
  int c;
  uint16_t n;

  fh = fopen(filename, "rb");
  if (fh == NULL) {
    return -1;
  }

  n = 0x200;
  while ((c = fgetc(fh)) != EOF) {
    chip8.m[n & 0xFFF] = c;
    n++;
  }

  fclose(fh);
  return 0;
}



static void chip8_execute(void)
{
  uint16_t opcode;
  uint8_t reg1;
  uint8_t reg2;
  uint8_t imm;
  uint8_t flag;
  uint16_t address;
  int i;
  
  opcode = chip8.m[chip8.pc & 0xFFF] * 0x100;
  chip8.pc++;
  opcode += chip8.m[chip8.pc & 0xFFF];
  chip8.pc++;

  switch (opcode >> 12) {
  case 0x0:
    switch (opcode & 0xFF) {
    case 0xE0:
      chip8_trace(opcode, "CLS");
      chip8_screen_clear();
      break;

    case 0xEE:
      chip8_trace(opcode, "RET");
      chip8.pc = chip8.stack[chip8.sp];
      if (chip8.sp > 0) {
        chip8.sp--;
      } else {
        chip8_panic("Stack underrun!\n");
      }
      break;

    default:
      chip8_panic("Unhandled 0x0 instruction: 0x%04x\n", opcode);
      break;
    }
    break;

  case 0x1:
    address = opcode & 0xFFF;
    chip8_trace(opcode, "JP 0x%03x", address);
    chip8.pc = address;
    break;

  case 0x2:
    address = opcode & 0xFFF;
    chip8_trace(opcode, "CALL 0x%03x", address);
    if (chip8.sp < (CHIP8_STACK_SIZE - 1)) {
      chip8.sp++;
    } else {
      chip8_panic("Stack overflow!\n");
    }
    chip8.stack[chip8.sp] = chip8.pc;
    chip8.pc = address;
    break;

  case 0x3:
    reg1 = (opcode >> 8) & 0xF;
    imm = opcode & 0xFF;
    chip8_trace(opcode, "SE V%X, 0x%02x", reg1, imm);
    if (chip8.v[reg1] == imm) {
      chip8.pc += 2;
    }
    break;

  case 0x4:
    reg1 = (opcode >> 8) & 0xF;
    imm = opcode & 0xFF;
    chip8_trace(opcode, "SNE V%X, 0x%02x", reg1, imm);
    if (chip8.v[reg1] != imm) {
      chip8.pc += 2;
    }
    break;

  case 0x5:
    if ((opcode & 0xF) == 0) {
      reg1 = (opcode >> 8) & 0xF;
      reg2 = (opcode >> 4) & 0xF;
      chip8_trace(opcode, "SE V%X, V%X", reg1, reg2);
      if (chip8.v[reg1] == chip8.v[reg2]) {
        chip8.pc += 2;
      }
    } else {
      chip8_panic("Unhandled 0x5 instruction: 0x%04x\n", opcode);
    }
    break;

  case 0x6:
    reg1 = (opcode >> 8) & 0xF;
    imm = opcode & 0xFF;
    chip8_trace(opcode, "LD V%X, 0x%02x", reg1, imm);
    chip8.v[reg1] = imm;
    break;

  case 0x7:
    reg1 = (opcode >> 8) & 0xF;
    imm = opcode & 0xFF;
    chip8_trace(opcode, "ADD V%X, 0x%02x", reg1, imm);
    chip8.v[reg1] += imm;
    break;

  case 0x8:
    reg1 = (opcode >> 8) & 0xF;
    reg2 = (opcode >> 4) & 0xF;
    switch (opcode & 0xF) {
    case 0x0:
      chip8_trace(opcode, "LD V%X, V%X", reg1, reg2);
      chip8.v[reg1] = chip8.v[reg2];
      break;

    case 0x1:
      chip8_trace(opcode, "OR V%X, V%X", reg1, reg2);
      chip8.v[reg1] |= chip8.v[reg2];
      chip8.v[0xF] = 0;
      break;

    case 0x2:
      chip8_trace(opcode, "AND V%X, V%X", reg1, reg2);
      chip8.v[reg1] &= chip8.v[reg2];
      chip8.v[0xF] = 0;
      break;

    case 0x3:
      chip8_trace(opcode, "XOR V%X, V%X", reg1, reg2);
      chip8.v[reg1] ^= chip8.v[reg2];
      chip8.v[0xF] = 0;
      break;

    case 0x4:
      chip8_trace(opcode, "ADD V%X, V%X", reg1, reg2);
      flag = ((chip8.v[reg2] + chip8.v[reg1]) > 255) ? 1 : 0;
      chip8.v[reg1] += chip8.v[reg2];
      chip8.v[0xF] = flag;
      break;

    case 0x5:
      chip8_trace(opcode, "SUB V%X, V%X", reg1, reg2);
      flag = (chip8.v[reg1] >= chip8.v[reg2]) ? 1 : 0;
      chip8.v[reg1] -= chip8.v[reg2];
      chip8.v[0xF] = flag;
      break;

    case 0x6:
      chip8_trace(opcode, "SHR V%X, V%X", reg1, reg2);
      flag = chip8.v[reg1] & 1;
      chip8.v[reg1] = chip8.v[reg2] >> 1;
      chip8.v[0xF] = flag;
      break;

    case 0x7:
      chip8_trace(opcode, "SUBN V%X, V%X", reg1, reg2);
      flag = (chip8.v[reg2] >= chip8.v[reg1]) ? 1 : 0;
      chip8.v[reg1] = chip8.v[reg2] - chip8.v[reg1];
      chip8.v[0xF] = flag;
      break;

    case 0xE:
      chip8_trace(opcode, "SHL V%X, V%X", reg1, reg2);
      flag = (chip8.v[reg1] >> 7) & 1;
      chip8.v[reg1] = chip8.v[reg2] << 1;
      chip8.v[0xF] = flag;
      break;

    default:
      chip8_panic("Unhandled 0x8 instruction: 0x%04x\n", opcode);
      break;
    }
    break;

  case 0x9:
    if ((opcode & 0xF) == 0) {
      reg1 = (opcode >> 8) & 0xF;
      reg2 = (opcode >> 4) & 0xF;
      chip8_trace(opcode, "SNE V%X, V%X", reg1, reg2);
      if (chip8.v[reg1] != chip8.v[reg2]) {
        chip8.pc += 2;
      }
    } else {
      chip8_panic("Unhandled 0x9 instruction: 0x%04x\n", opcode);
    }
    break;

  case 0xA:
    address = opcode & 0xFFF;
    chip8_trace(opcode, "LD I, 0x%03x", address);
    chip8.i = address;
    break;

  case 0xB:
    address = opcode & 0xFFF;
    chip8_trace(opcode, "JP V0, 0x%03x", address);
    chip8.pc = address + chip8.v[0x0];
    break;

  case 0xC:
    reg1 = (opcode >> 8) & 0xF;
    imm = opcode & 0xFF;
    chip8_trace(opcode, "RND V%X, 0x%02x", reg1, imm);
    chip8.v[reg1] = (rand() % 255) & imm;
    break;

  case 0xD:
    reg1 = (opcode >> 8) & 0xF;
    reg2 = (opcode >> 4) & 0xF;
    imm = opcode & 0xF;
    chip8_trace(opcode, "DRW V%X, V%X, 0x%1x", reg1, reg2, imm);
    chip8_screen_draw(chip8.v[reg1], chip8.v[reg2], imm);
    chip8_screen_display();
    pause(); /* Wait for interrupt. */
    break;

  case 0xE:
    reg1 = (opcode >> 8) & 0xF;
    switch (opcode & 0xFF) {
    case 0x9E:
      chip8_trace(opcode, "SKP V%X", reg1);
      if (chip8.v[reg1] == chip8.k) {
        chip8.pc += 2;
      }
      break;

    case 0xA1:
      chip8_trace(opcode, "SKNP V%X", reg1);
      if (chip8.v[reg1] != chip8.k) {
        chip8.pc += 2;
      }
      break;

    default:
      chip8_panic("Unhandled 0xE instruction: 0x%04x\n", opcode);
      break;
    }
    break;

  case 0xF:
    reg1 = (opcode >> 8) & 0xF;
    switch (opcode & 0xFF) {
    case 0x07:
      chip8_trace(opcode, "LD V%X, DT", reg1);
      chip8.v[reg1] = chip8.dt;
      break;

    case 0x0A:
      chip8_trace(opcode, "LD V%X, K", reg1);
      /* Wait for key press. */
      while (chip8.k == CHIP8_KEY_NONE) {
        pause();
        chip8_timer_check();
      }
      chip8.v[reg1] = chip8.k;
      /* Wait for key release. */
      while (chip8.k != CHIP8_KEY_NONE) {
        pause();
        chip8_timer_check();
      }
      break;

    case 0x15:
      chip8_trace(opcode, "LD DT, V%X", reg1);
      chip8.dt = chip8.v[reg1];
      break;

    case 0x18:
      chip8_trace(opcode, "LD ST, V%X", reg1);
      chip8.st = chip8.v[reg1];
      break;

    case 0x1E:
      chip8_trace(opcode, "ADD I, V%X", reg1);
      chip8.i += chip8.v[reg1];
      break;

    case 0x29:
      chip8_trace(opcode, "LD F, V%X", reg1);
      chip8.i = chip8_font[chip8.v[reg1] & 0xF];
      break;

    case 0x33:
      chip8_trace(opcode, "LD B, V%X", reg1);
      chip8.m[(chip8.i    ) & 0xFFF] =  chip8.v[reg1] / 100;
      chip8.m[(chip8.i + 1) & 0xFFF] = (chip8.v[reg1] % 100) / 10;
      chip8.m[(chip8.i + 2) & 0xFFF] =  chip8.v[reg1] % 10;
      break;

    case 0x55:
      chip8_trace(opcode, "LD [I], V%X", reg1);
      for (i = 0; i < (reg1 + 1); i++) {
        chip8.m[(chip8.i + i) & 0xFFF] = chip8.v[i];
      }
      chip8.i += (reg1 + 1);
      break;

    case 0x65:
      chip8_trace(opcode, "LD V%X, [I]", reg1);
      for (i = 0; i < (reg1 + 1); i++) {
        chip8.v[i] = chip8.m[(chip8.i + i) & 0xFFF];
      }
      chip8.i += (reg1 + 1);
      break;

    default:
      chip8_panic("Unhandled 0xF instruction: 0x%04x\n", opcode);
      break;
    }
    break;

  default:
    chip8_panic("Unhandled instruction: 0x%04x\n", opcode);
    break;
  }
}



void chip8_exit(void)
{
  chip8_screen_exit();
#ifdef CHIP8_TRACE
  chip8_trace_dump(stdout);
#endif /* CHIP8_TRACE */
}



int main(int argc, char *argv[])
{
  int cycle;
  struct sigaction sa;
  struct itimerval new;

  if (argc != 2) {
    fprintf(stderr, "Usage: %s <rom>\n", argv[0]);
    return EXIT_FAILURE;
  }

  chip8_init();
#ifdef CHIP8_TRACE
  chip8_trace_init();
#endif /* CHIP8_TRACE */
  srand(time(NULL));
  atexit(chip8_exit);

  if (chip8_load(argv[1]) != 0) {
    fprintf(stderr, "ROM load failed!\n");
    return EXIT_FAILURE;
  }

  chip8_screen_init();

  memset(&sa, 0, sizeof(struct sigaction));
  sa.sa_handler = &chip8_signal_handler;
  sigaction(SIGALRM, &sa, NULL);
  sigaction(SIGINT, &sa, NULL);

  new.it_value.tv_sec = 0;
  new.it_value.tv_usec = 16666;
  new.it_interval.tv_sec = 0;
  new.it_interval.tv_usec = 16666;
  setitimer(ITIMER_REAL, &new, NULL);

  /* Load built-in font data: */
  memcpy(&chip8.m[chip8_font[0x0]], "\xF0\x90\x90\x90\xF0", 5);
  memcpy(&chip8.m[chip8_font[0x1]], "\x20\x60\x20\x20\x70", 5);
  memcpy(&chip8.m[chip8_font[0x2]], "\xF0\x10\xF0\x80\xF0", 5);
  memcpy(&chip8.m[chip8_font[0x3]], "\xF0\x10\xF0\x10\xF0", 5);
  memcpy(&chip8.m[chip8_font[0x4]], "\x90\x90\xF0\x10\x10", 5);
  memcpy(&chip8.m[chip8_font[0x5]], "\xF0\x80\xF0\x10\xF0", 5);
  memcpy(&chip8.m[chip8_font[0x6]], "\xF0\x80\xF0\x90\xF0", 5);
  memcpy(&chip8.m[chip8_font[0x7]], "\xF0\x10\x20\x40\x40", 5);
  memcpy(&chip8.m[chip8_font[0x8]], "\xF0\x90\xF0\x90\xF0", 5);
  memcpy(&chip8.m[chip8_font[0x9]], "\xF0\x90\xF0\x10\xF0", 5);
  memcpy(&chip8.m[chip8_font[0xA]], "\xF0\x90\xF0\x90\x90", 5);
  memcpy(&chip8.m[chip8_font[0xB]], "\xE0\x90\xE0\x90\xE0", 5);
  memcpy(&chip8.m[chip8_font[0xC]], "\xF0\x80\x80\x80\xF0", 5);
  memcpy(&chip8.m[chip8_font[0xD]], "\xE0\x90\x90\x90\xE0", 5);
  memcpy(&chip8.m[chip8_font[0xE]], "\xF0\x80\xF0\x80\xF0", 5);
  memcpy(&chip8.m[chip8_font[0xF]], "\xF0\x80\xF0\x80\x80", 5);

  chip8.pc = 0x200;
  cycle = 0;
  while (1) {
    chip8_execute();
    cycle++;
    if (cycle > CHIP8_CYCLE_LIMIT) {
      cycle = 0;
      /* Not strictly necessary, but this helps relax the host CPU. */
      pause();
    }
    chip8_timer_check();
  }

  return EXIT_SUCCESS;
}



