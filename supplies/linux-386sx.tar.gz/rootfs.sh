#!/bin/bash
set -e

ROOTFS="`pwd`/rootfs/"

TARGET="i386-linux-uclibc"
PREFIX="/opt/gcc-${TARGET}/"
SYSROOT="${PREFIX}/${TARGET}/sysroot"

export PATH="/opt/gcc-i386-linux-uclibc/bin:$PATH"

if [ -d "$ROOTFS" ]; then
  echo "Old root FS directory detected, please remove it."
  exit 1
fi
mkdir -p "$ROOTFS"

# Install Busybox:
cd build/busybox/busybox-*
make CROSS_COMPILE=i386-linux-uclibc- PREFIX="$ROOTFS" install
cd -

# Create some essential directories
cd "$ROOTFS"
mkdir etc
mkdir etc/init.d
mkdir lib
mkdir proc
mkdir sys
mkdir tmp
mkdir root
mkdir dev
mkdir dev/pts
cd -

# Initial rc.S:
cat > rcS <<EOF
#!/bin/sh
mount -t proc /proc /proc
mount -t devpts /dev/pts /dev/pts
loadkmap < /etc/no-latin1.bmap
EOF
mv -v rcS "$ROOTFS/etc/init.d/"

# Initial inittab:
cat > inittab <<EOF
::sysinit:/etc/init.d/rcS
::respawn:-/bin/sh
::ctrlaltdel:/sbin/reboot
::shutdown:/bin/umount -a -r
::restart:/sbin/init
EOF
mv -v inittab "$ROOTFS/etc/"

# Copy this system's keymap:
loadkeys -b /usr/share/kbd/keymaps/i386/qwerty/no-latin1.map.gz > "$ROOTFS/etc/no-latin1.bmap"

# Make everything root user:
sudo chown -R root:root "$ROOTFS"

# Create some critical devices:
sudo mknod "$ROOTFS/dev/tty" c 5 0
sudo mknod "$ROOTFS/dev/console" c 5 1
sudo mknod -m 0666 "$ROOTFS/dev/null" c 1 3

# Create some useful devices:
sudo mknod "$ROOTFS/dev/rtc" c 10 135
sudo mknod "$ROOTFS/dev/tty0" c 4 0
sudo mknod "$ROOTFS/dev/tty1" c 4 1
sudo mknod "$ROOTFS/dev/tty2" c 4 2
sudo mknod "$ROOTFS/dev/tty3" c 4 3
sudo mknod "$ROOTFS/dev/ttyS0" c 4 64
sudo mknod "$ROOTFS/dev/ttyS1" c 4 65
sudo mknod "$ROOTFS/dev/fd0" b 2 0
sudo mknod "$ROOTFS/dev/fd1" b 2 1
sudo mknod "$ROOTFS/dev/root" b 4 0
sudo mknod "$ROOTFS/dev/lp0" c 6 0

# SetUID on busybox binary:
sudo chmod +s "$ROOTFS/bin/busybox"

# Make rcS executable:
sudo chmod +x "$ROOTFS/etc/init.d/rcS"

