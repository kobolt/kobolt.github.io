/*
 * This file is part of the M80 Framework.
 *
 * The M80 Framework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * The M80 Framework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with the M80 Framework.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "m80.h"
#include <time.h>



void clock_event(m80_module_t *m, int event)
{
  (void)m;
  (void)event;
}



void clock_tick(m80_module_t *m)
{
  time_t t;
  struct tm *tm;

  t = time(NULL);
  tm = localtime(&t);
  mvwprintw(m->w, 0, 0, "%02d:%02d:%02d", tm->tm_hour, tm->tm_min, tm->tm_sec);
}



void clock_redraw(m80_module_t *m, int focus)
{
  if (has_colors()) {
    wbkgd(m->w, COLOR_PAIR(focus ? M80_COLOR_FOCUS : M80_COLOR_COMMON));
  } else {
    wbkgd(m->w, focus ? A_BOLD : A_NORMAL);
  }
}



void clock_unload(void)
{
}



void clock_init(m80_module_t *m)
{
  m->size_y = 1;
  m->size_x = 8;
}

