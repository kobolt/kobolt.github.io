/*
 * This file is part of the M80 Framework.
 *
 * The M80 Framework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * The M80 Framework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with the M80 Framework.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <curses.h>

#define M80_COLOR_COMMON 1
#define M80_COLOR_FOCUS 2

#define M80_MAX_MODULES 10
#define M80_MAX_MODULE_NAME 16
#define M80_MAX_ARG_LENGTH 16

#define M80_CMD_RESULT_OK 0
#define M80_CMD_RESULT_FAIL -1

typedef enum {
  M80_COMMAND_NONE        = 0,
  M80_COMMAND_EXIT        = 1,
  M80_COMMAND_LOAD        = 2,
  M80_COMMAND_UNLOAD      = 3,
  M80_COMMAND_MOD_EXISTS  = 4,
  M80_COMMAND_NEW_FOCUS   = 5,
  M80_COMMAND_SAVE_LAYOUT = 6,
} m80_command_t;

typedef struct m80_module_s {
  WINDOW *w;
  void *dl_handle;
  char name[M80_MAX_MODULE_NAME];
  int y;
  int x;
  int size_y;
  int size_x;
  void (*event_function)(struct m80_module_s *m, int event);
  void (*tick_function)(struct m80_module_s *m);
  void (*redraw_function)(struct m80_module_s *m, int focus);
  void (*unload_function)(void);
  m80_command_t manager_command;
  int manager_return;
  char manager_argument[M80_MAX_ARG_LENGTH];
  char *module_directory;
} m80_module_t;

