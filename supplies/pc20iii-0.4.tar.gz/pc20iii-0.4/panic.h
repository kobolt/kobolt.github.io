#ifndef _PANIC_H
#define _PANIC_H

#include <stdarg.h>

void panic(const char *format, ...);

#endif /* _PANIC_H */
