/* One-Time Pad Communicator
 * Version 0.1 (18/11-07)
 * Copyright 2007 Kjetil Erga (kobolt.anarion -AT- gmail -DOT- com)
 * 
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <stdio.h>
#include <stdlib.h> /* getenv(), atexit() */
#include <errno.h>
#include <unistd.h> /* getopt() */
#include <string.h> /* memset() */
#include <sys/types.h>
#include <sys/stat.h> /* mkdir() */
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h> /* gethostbyname() */
#include <fcntl.h>
#include <ncurses.h>
#include <signal.h>



#define OTP_NETWORK_PORT 2648
#define OTP_PADSIZE 1048576 /* Size in bytes for each pad file. */
#define OTP_EMPTY_PAD_CHAR '?'

#define OTP_RANDOM_SOURCE "/dev/urandom"

#define OTP_USER_DIRECTORY ".otp"
#define OTP_LOCAL_SYNC_FILE "local.sync"
#define OTP_LOCAL_PAD_FILE "local.pad"
#define OTP_REMOTE_SYNC_FILE "remote.sync"
#define OTP_REMOTE_PAD_FILE "remote.pad"

#define OTP_MAX_PATH_LENGTH 256
#define OTP_MAX_LINE_LENGTH 1024



static unsigned char otp_local_pad[OTP_PADSIZE];
static unsigned char otp_remote_pad[OTP_PADSIZE];
static unsigned long otp_local_sync, otp_remote_sync;

static int otp_abort_loop; /* Flag for external abort of main loop. */



static void otp_abort_handler(int signo)
{
  otp_abort_loop = 1;
}



static int otp_copy_pad(char *from_path, char *to_path)
{
  int c, i;
  FILE *in, *out;

  in = fopen(from_path, "r");
  if (in == NULL) {
    fprintf(stderr, "Error: Could not open source for reading: %s\n",
      strerror(errno));
    return -1;
  }

  out = fopen(to_path, "w");
  if (out == NULL) {
    fprintf(stderr, "Error: Could not open destination for writing: %s\n",
      strerror(errno));
    fclose(in);
    return -1;
  }

  for (i = 0; i < OTP_PADSIZE; i++) {
    c = fgetc(in);
    if (c == EOF) {
      fprintf(stderr, "Error: Pad not big enough.\n");
      return -1;
    }
    fputc(c, out);
  }

  fclose(in);
  fclose(out);
  return 0;
}



static int otp_use_pad(unsigned char *pad_pointer, char *path)
{
  int i;
  FILE *fh;

  fh = fopen(path, "r");
  if (fh == NULL) {
    fprintf(stderr, "Error: Could not open pad file for reading: %s\n",
      strerror(errno));
    return -1;
  }

  for (i = 0; i < OTP_PADSIZE; i++)
    pad_pointer[i] = fgetc(fh);

  fclose(fh);
  return 0;
}



static int otp_generate_directories(char *home, char *user)
{
  /* Generate all directories needed if they do not exist. */
  int i;
  char temp_path[OTP_MAX_PATH_LENGTH];

  snprintf(temp_path, OTP_MAX_PATH_LENGTH, "%s/%s", home, OTP_USER_DIRECTORY);
  if (mkdir(temp_path, 0755) == -1) {
    if (errno != EEXIST) { /* Ignore already exist error. */
      fprintf(stderr, "Error: Cannot create directory under home: %s\n",
        strerror(errno));
      return -1;
    }
  }

  /* Check for, and dissalow slashes in remote user names. */
  for (i = 0; i < strlen(user); i++) {
    if (user[i] == '/') {
      fprintf(stderr, "Error: Remote user names cannot contain slashes.\n");
      return -1;
    }
  }

  snprintf(temp_path, OTP_MAX_PATH_LENGTH, "%s/%s/%s",
    home, OTP_USER_DIRECTORY, user);
  if (mkdir(temp_path, 0755) == -1) {
    if (errno != EEXIST) {
      fprintf(stderr, "Error: Cannot create remote user directory: %s\n",
        strerror(errno));
      return -1;
    }
  }

  return 0;
}



static int otp_set_pad_sync(char *path, unsigned long number)
{
  FILE *fh;

  fh = fopen(path, "w+");
  if (fh == NULL) {
    fprintf(stderr, "Error: Could not open sync file for writing: %s\n",
      strerror(errno));
    return -1;
  }
  
  fprintf(fh, "%lu\n", number);
  
  fclose(fh);
  return 0;
}



static int otp_get_pad_sync(char *path, unsigned long *number)
{
  FILE *fh;
  unsigned long read;

  fh = fopen(path, "r");
  if (fh == NULL) {
    fprintf(stderr, "Error: Could not open sync file for reading: %s\n",
      strerror(errno));
    return -1;
  }

  if (fscanf(fh, "%lu\n", &read) != 1) {
    fprintf(stderr, "Error: Could not find a valid sync number in file.\n");
    return -1;
  }

  *number = read;
  return 0;
}



static int otp_load_pads(char *home, char *user)
{
  char temp_path[OTP_MAX_PATH_LENGTH];
  unsigned long temp;

  snprintf(temp_path, OTP_MAX_PATH_LENGTH, "%s/%s/%s/%s",
    home, OTP_USER_DIRECTORY, user, OTP_LOCAL_PAD_FILE);
  if (otp_use_pad(otp_local_pad, temp_path) != 0) {
    fprintf(stderr, 
      "Info: Has local pad been created for remote user '%s'?\n", user);
    return -1;
  }

  snprintf(temp_path, OTP_MAX_PATH_LENGTH, "%s/%s/%s/%s",
    home, OTP_USER_DIRECTORY, user, OTP_REMOTE_PAD_FILE);
  if (otp_use_pad(otp_remote_pad, temp_path) != 0) {
    fprintf(stderr,
      "Info: Has remote pad been imported from remote user '%s'?\n", user);
    return -1;
  }

  snprintf(temp_path, OTP_MAX_PATH_LENGTH, "%s/%s/%s/%s",
    home, OTP_USER_DIRECTORY, user, OTP_LOCAL_SYNC_FILE);
  if (otp_get_pad_sync(temp_path, &temp) != 0) {
    fprintf(stderr, "Unable to get local sync for '%s'.\n", user);
    return -1;
  }
  otp_local_sync = temp;

  snprintf(temp_path, OTP_MAX_PATH_LENGTH, "%s/%s/%s/%s",
    home, OTP_USER_DIRECTORY, user, OTP_REMOTE_SYNC_FILE);
  if (otp_get_pad_sync(temp_path, &temp) != 0) {
    fprintf(stderr, "Unable to get remote sync for '%s'.\n", user);
    return -1;
  }
  otp_remote_sync = temp;

  return 0;
}



static int otp_save_sync(char *home, char *user)
{
  char temp_path[OTP_MAX_PATH_LENGTH];

  snprintf(temp_path, OTP_MAX_PATH_LENGTH, "%s/%s/%s/%s",
    home, OTP_USER_DIRECTORY, user, OTP_LOCAL_SYNC_FILE);
  if (otp_set_pad_sync(temp_path, otp_local_sync) != 0) {
    fprintf(stderr, "Unable to save local sync for '%s'.\n", user);
    return -1;
  }

  snprintf(temp_path, OTP_MAX_PATH_LENGTH, "%s/%s/%s/%s",
    home, OTP_USER_DIRECTORY, user, OTP_REMOTE_SYNC_FILE);
  if (otp_set_pad_sync(temp_path, otp_remote_sync) != 0) {
    fprintf(stderr, "Unable to save remote sync for '%s'.\n", user);
    return -1;
  }

  return 0;
}



static int otp_client_connect(char *host, int *server_socket)
{
  struct hostent *he;
  struct sockaddr_in addr;

  if ((he = gethostbyname(host)) == NULL) {
    fprintf(stderr, "Could not get host information: %s\n", hstrerror(h_errno));
    return -1;
  }

  if ((*server_socket = socket(PF_INET, SOCK_STREAM, 0)) == -1) {
    fprintf(stderr, "Error: Unable to create socket: %s\n", strerror(errno));
    return -1;
  }

  addr.sin_family = AF_INET;
  addr.sin_port = htons(OTP_NETWORK_PORT);
  addr.sin_addr = *((struct in_addr *)he->h_addr);
  memset(addr.sin_zero, '\0', sizeof(addr.sin_zero));

  if (connect(*server_socket, (struct sockaddr *)&addr, sizeof(addr)) == -1) {
    fprintf(stderr, "Error: Unable to connect: %s\n", strerror(errno));
    return -1;
  }

  return 0;
}



static int otp_server_listen(int *client_socket)
{
  int server_socket;
  struct sockaddr_in server_addr;
  struct sockaddr_in client_addr;
  socklen_t addr_len;
  
  if ((server_socket = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
    fprintf(stderr, "Error: Unable to create server socket: %s\n",
      strerror(errno));
    return -1;
  }

  server_addr.sin_family = AF_INET;
  server_addr.sin_port = htons(OTP_NETWORK_PORT);
  server_addr.sin_addr.s_addr = INADDR_ANY;
  memset(server_addr.sin_zero, '\0', sizeof(server_addr.sin_zero));

  if (bind(server_socket, (struct sockaddr *)&server_addr, 
    sizeof(server_addr)) == -1) {
    fprintf(stderr, "Error: Unable to bind server socket: %s\n",
      strerror(errno));
    return -1;
  }

  if (listen(server_socket, 0) == -1) {
    fprintf(stderr, "Error: Unable to listen on server socket: %s\n",
      strerror(errno));
    return -1;
  }

  fprintf(stderr, "Info: Server socket ready, waiting for connection...\n");

  addr_len = sizeof(client_addr);
  if ((*client_socket = accept(server_socket, (struct sockaddr *)client_socket,
    &addr_len)) == -1) {
    fprintf(stderr, "Error: Unable to accept connection: %s\n",
      strerror(errno));
    return -1;
  }

  close(server_socket); /* Got connection, no need to listen for more. */

  return 0;
}



static void otp_local_encrypt(unsigned char *buffer, int n)
{
  int i;
  for (i = 0; i < n; i++) {
    buffer[i] = buffer[i] ^ otp_local_pad[otp_local_sync];
    otp_local_sync++;
    if (otp_local_sync > OTP_PADSIZE) {
      if (i == n - 1)
        buffer[i] = '\0'; 
      else
        buffer[i] = OTP_EMPTY_PAD_CHAR;
    }
  }
}



static void otp_remote_decrypt(unsigned char *buffer, int n)
{
  int i;
  for (i = 0; i < n; i++) {
    buffer[i] = buffer[i] ^ otp_remote_pad[otp_remote_sync];
    otp_remote_sync++;
    if (otp_remote_sync > OTP_PADSIZE) {
      if (i == n - 1)
        buffer[i] = '\0'; 
      else
        buffer[i] = OTP_EMPTY_PAD_CHAR;
    }
  }
}



static int otp_start_session(int socket)
{
  int flags, received, i, c, n;
  int max_y, max_x, out_y, out_x, out_max_y, out_max_x;
  unsigned char send_buffer[OTP_MAX_LINE_LENGTH];
  unsigned char recv_buffer[OTP_MAX_LINE_LENGTH];
  WINDOW *out_win;

  if ((flags = fcntl(socket, F_GETFL, 0)) == -1)
    flags = 0;
  if (fcntl(socket, F_SETFL, flags | O_NONBLOCK) == -1) {
    fprintf(stderr, "Error: Unable to set socket as non-blocking: %s\n",
      strerror(errno));
    return -1;
  }

  /* Setup ncurses: */
  initscr();
  atexit((void *)endwin);
  getmaxyx(stdscr, max_y, max_x);
  noecho();
  nodelay(stdscr, TRUE);
  keypad(stdscr, TRUE);

  out_win = newwin(max_y - 1, max_x, 0, 0);
  getmaxyx(out_win, out_max_y, out_max_x);
  scrollok(out_win, TRUE);
  out_y = out_x = 0;

  /* Register handlers for better shutdown on user interrupts. */
  signal(SIGINT, otp_abort_handler);
  signal(SIGTERM, otp_abort_handler);

  /* Main event loop: */
  send_buffer[0] = '\0';
  n = 1;
  otp_abort_loop = 0;
  while (! otp_abort_loop) {
    /* Get local input: */
    c = getch();
    if (c != ERR) {
      switch (c) {
      case KEY_RESIZE:
        getmaxyx(stdscr, max_y, max_x);
        /* Delete and recreate output window. */
        delwin(out_win);
        out_win = newwin(max_y - 1, max_x, 0, 0);
        getmaxyx(out_win, out_max_y, out_max_x);
        scrollok(out_win, TRUE);
        out_y = out_x = 0;
        break;

      case KEY_F(10):
        otp_abort_loop = 1;
        break;

      case KEY_BACKSPACE:
      case 0x7f: /* Some terminals use this as backspace. */
        if (n > 1) {
          n--;
          send_buffer[n - 1] = '\0';
        }
        break;

      case KEY_ENTER:
      case '\n':
        if (n > 1) {
          mvwprintw(out_win, out_y, out_x, "%s\n", send_buffer);
          getyx(out_win, out_y, out_x);
          otp_local_encrypt(send_buffer, n);
          if (send(socket, send_buffer, n, 0) == -1) {
            fprintf(stderr, "Error: Unable to send data on socket: %s\n",
              strerror(errno));
            return -1;
          }
          send_buffer[0] = '\0';
          n = 1;
        }
        break;

      default:
        send_buffer[n - 1] = c;
        send_buffer[n] = '\0';
        n++;
        if (n > OTP_MAX_LINE_LENGTH - 1)
          n--;
        break;

      }
    }
    
    /* Receive remote output: */
    received = recv(socket, recv_buffer, OTP_MAX_LINE_LENGTH - 1, 0);
    if (received == 0) {
      fprintf(stderr, "Info: Connection closed by remote host.\n");
      break;
    } else if (received > 0) {
      otp_remote_decrypt(recv_buffer, received);
      wattron(out_win, A_BOLD);
      mvwprintw(out_win, out_y, out_x, "%s\n", recv_buffer);
      wattroff(out_win, A_BOLD);
      getyx(out_win, out_y, out_x);
    } else {
      if (errno == EAGAIN) {
        /* No data available, just ignore. */
      } else {
        fprintf(stderr, "Error: Unable to receive data on socket: %s\n",
          strerror(errno));
        return -1;
      }
    }
    
    /* Update screen: */
    mvwhline(out_win, out_max_y - 1, 0, ACS_HLINE, out_max_x);
    mvwprintw(out_win, out_max_y - 1, out_max_x - 20, "[L:%3d%%]",
      (int)((otp_local_sync / (double)OTP_PADSIZE) * 100));
    mvwprintw(out_win, out_max_y - 1, out_max_x - 9, "[R:%3d%%]",
      (int)((otp_remote_sync / (double)OTP_PADSIZE) * 100));
    wrefresh(out_win);

    mvhline(max_y - 1, 0, ' ', max_x);
    for (i = 0; i < max_x - 1; i++) {
      if (n > max_x - 1) {
        mvaddch(max_y - 1, i, send_buffer[n - max_x + i]);
      } else {
        if (i < n - 1)
          mvaddch(max_y - 1, i, send_buffer[i]);
      }
    }
    refresh();

    napms(5); /* Relax CPU. */
  }
  
  return 0;
}



int main(int argc, char *argv[])
{
  extern char *optarg;
  extern int optind;
  int option;
  char *home, *user;
  char temp_path[OTP_MAX_PATH_LENGTH];
  int socket;

  home = getenv("HOME");
  if (home == NULL) {
    fprintf(stderr, "Error: Unable to determine home directory.\n");
    return 1;
  }

  /* Uncommon way to use getopt, but it is suitable when only one optional
     argument is to be used in the rest of the program. */
  option = getopt(argc, argv, "c:agi:e:l:r:");
  if (option == -1 || option == '?' || optind >= argc) {
    fprintf(stderr, "Usage: %s <option> [option argument] <remote user>\n",
      argv[0]);
    fprintf(stderr, "Options:\n");
    fprintf(stderr, "-c host    Connect to host as client.\n");
    fprintf(stderr, "-a         Accept connection as server.\n");
    fprintf(stderr, "-g         Generate pad.\n");
    fprintf(stderr, "-i path    Import pad.\n");
    fprintf(stderr, "-e path    Export pad.\n");
    fprintf(stderr, "-l sync    Set local sync.\n");
    fprintf(stderr, "-r sync    Set remote sync.\n");
    return 1;
  }
  user = argv[optind];

  switch (option) {
  case 'g':
    if (otp_generate_directories(home, user) != 0) {
      fprintf(stderr, "Error: Unable to create directories needed.\n");
      return 1;
    }

    snprintf(temp_path, OTP_MAX_PATH_LENGTH, "%s/%s/%s/%s",
      home, OTP_USER_DIRECTORY, user, OTP_LOCAL_PAD_FILE);
    if (otp_copy_pad(OTP_RANDOM_SOURCE, temp_path) != 0) {
      fprintf(stderr, "Error: Unable to create local pad for '%s'.\n", user);
      return 1;
    };

    snprintf(temp_path, OTP_MAX_PATH_LENGTH, "%s/%s/%s/%s",
      home, OTP_USER_DIRECTORY, user, OTP_LOCAL_SYNC_FILE);
    if (otp_set_pad_sync(temp_path, 0) != 0) {
      fprintf(stderr, "Unable to set local sync for '%s'.\n", user);
      return 1;
    }

    fprintf(stderr,
      "Info: Pad successfully created and synced to zero for '%s'.\n", user);
    break;

  case 'c':
    if (otp_load_pads(home, user) != 0)
      return 1;
    if (otp_client_connect(optarg, &socket) != 0)
      return 1;
    otp_start_session(socket);
    close(socket);
    if (otp_save_sync(home, user) != 0)
      return 1;
    break;

  case 'a':
    if (otp_load_pads(home, user) != 0)
      return 1;
    if (otp_server_listen(&socket) != 0)
      return 1;
    otp_start_session(socket);
    close(socket);
    if (otp_save_sync(home, user) != 0)
      return 1;
    break;

  case 'i':
    snprintf(temp_path, OTP_MAX_PATH_LENGTH, "%s/%s/%s/%s",
      home, OTP_USER_DIRECTORY, user, OTP_REMOTE_PAD_FILE);
    if (otp_copy_pad(optarg, temp_path) != 0) {
      fprintf(stderr, "Error: Unable to import remote pad for '%s'.\n", user);
      return 1;
    };
    snprintf(temp_path, OTP_MAX_PATH_LENGTH, "%s/%s/%s/%s",
      home, OTP_USER_DIRECTORY, user, OTP_REMOTE_SYNC_FILE);
    if (otp_set_pad_sync(temp_path, 0) != 0) {
      fprintf(stderr, "Unable to set remote sync for '%s'.\n", user);
      return 1;
    }
    fprintf(stderr,
      "Info: Pad successfully imported and synced to zero for '%s'.\n", user);
    break;

  case 'e':
    snprintf(temp_path, OTP_MAX_PATH_LENGTH, "%s/%s/%s/%s",
      home, OTP_USER_DIRECTORY, user, OTP_LOCAL_PAD_FILE);
    if (otp_copy_pad(temp_path, optarg) != 0) {
      fprintf(stderr, "Error: Unable to export local pad for '%s'.\n", user);
      return 1;
    };
    fprintf(stderr,
      "Info: Pad successfully exported for '%s'.\n", user);
    break;

  case 'l':
    snprintf(temp_path, OTP_MAX_PATH_LENGTH, "%s/%s/%s/%s",
      home, OTP_USER_DIRECTORY, user, OTP_LOCAL_SYNC_FILE);
    if (otp_set_pad_sync(temp_path, atoi(optarg)) != 0) {
      fprintf(stderr, "Unable to set local sync for '%s'.\n", user);
      return 1;
    }
    fprintf(stderr,
      "Info: Local sync set to '%d' for '%s'.\n", atoi(optarg), user);
    break;

  case 'r':
    snprintf(temp_path, OTP_MAX_PATH_LENGTH, "%s/%s/%s/%s",
      home, OTP_USER_DIRECTORY, user, OTP_REMOTE_SYNC_FILE);
    if (otp_set_pad_sync(temp_path, atoi(optarg)) != 0) {
      fprintf(stderr, "Unable to set remote sync for '%s'.\n", user);
      return 1;
    }
    fprintf(stderr,
      "Info: Remote sync set to '%d' for '%s'.\n", atoi(optarg), user);
    break;

  default:
    break;
  }

  return 0;
}

