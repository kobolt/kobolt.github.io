/* Block Editor
 * Version 0.1 (8/10-07)
 * Copyright 2007 Kjetil Erga (kobolt.anarion -AT- gmail -DOT- com)
 * 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <ncurses.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>



#define BLOCK_EDIT_PADDING ' '

static char *block_edit_text = NULL;
static int block_edit_scroll_y, block_edit_scroll_x;
static int block_edit_text_size_y, block_edit_text_size_x;
static int block_edit_cursor_movement;

enum
{
  BLOCK_EDIT_MOVE_NONE  = 1,
  BLOCK_EDIT_MOVE_RIGHT = 2,
  BLOCK_EDIT_MOVE_LEFT  = 3,
  BLOCK_EDIT_MOVE_DOWN  = 4,
  BLOCK_EDIT_MOVE_UP    = 5,
};

static const char block_edit_move_name[5][6] =
  {"None", "Right", "Left", "Down", "Up"};



static void block_edit_update_screen(void)
{
  int i, j, cursor_y, cursor_x, max_y, max_x;

  getyx(stdscr, cursor_y, cursor_x);
  getmaxyx(stdscr, max_y, max_x);

  /* Draw status bar. */
  attron(A_BOLD);
  for (i = 0; i < max_x; i++)
    mvaddch(max_y - 1, i, ' '); /* Clear line first. */
  mvprintw(max_y - 1, max_x - 34, "Cursor-Movement: %-5s   F1: Help",
    block_edit_move_name[block_edit_cursor_movement - 1]);
  mvprintw(max_y - 1, 0, "%d/%d,%d/%d",
    cursor_y + 1 + block_edit_scroll_y, block_edit_text_size_y,
    cursor_x + 1 + block_edit_scroll_x, block_edit_text_size_x);
  attroff(A_BOLD);

  /* Draw text in relevant area. */
  for (i = 0; i < block_edit_text_size_y; i++) {
    for (j = 0; j < block_edit_text_size_x; j++) {
      mvaddch(i, j, *(block_edit_text + (block_edit_text_size_x *
        (i + block_edit_scroll_y)) + (j + block_edit_scroll_x)));
      if (j >= max_x - 1)
        continue;
    }
    if (i >= max_y - 2)
      break;
  }

  /* Draw cross with cursor as center. */
  for (i = 0; i < max_y - 1; i++) {
    for (j = 0; j < max_x; j++) {
      if (i == cursor_y || j == cursor_x)
        attrset(A_REVERSE);
      else
        attrset(A_NORMAL);
      move(i, j);
      addch(inch() & A_CHARTEXT);
    }
  }
  attrset(A_NORMAL); /* Be sure it is back to normal afterwards. */
  
  move(cursor_y, cursor_x);
  refresh();
}



static void block_edit_help_display(void)
{
  clear();

  attron(A_BOLD);
  mvprintw(0,  0, "Keys");
  attroff(A_BOLD);
  mvprintw(2,  0, "Left:     Move cursor left.");
  mvprintw(3,  0, "Right:    Move cursor right.");
  mvprintw(4,  0, "Up:       Move cursor up.");
  mvprintw(5,  0, "Down:     Move cursor down.");
  mvprintw(6,  0, "F1:       This help display.");
  mvprintw(7,  0, "F2:       Change automatic cursor movement.");
  mvprintw(8,  0, "F3:       Save changes back to file.");
  mvprintw(9,  0, "F4:       Quit the program.");
  mvprintw(10, 0, "F5:       Increase horizontal text range.");
  mvprintw(11, 0, "F6:       Decrease horizontal text range.");
  mvprintw(12, 0, "F7:       Increase vertical text range.");
  mvprintw(13, 0, "F8:       Decrease vertical text range.");
  mvprintw(15, 0, "Press any key to continue...");

  getch(); /* Press any key to continue... */
  clear();
}



static int block_edit_load_file(char *file)
{
  int c, temp_size_x, temp_size_y, old_c;
  FILE *fh;

  fh = fopen(file, "r");
  if (fh == NULL)
    return -1;

  /* Scan file first to find limits. */
  block_edit_text_size_y = 1;
  block_edit_text_size_x = 0;
  temp_size_x = 0;
  while ((c = fgetc(fh)) != EOF) {
    if (c == '\n') {
      block_edit_text_size_y++;
      if (temp_size_x > block_edit_text_size_x)
        block_edit_text_size_x = temp_size_x;
      temp_size_x = 0;
    } else {
      if (isprint(c)) {
        temp_size_x++;
      }
    }
    old_c = c;
  }
  if (old_c == '\n')
    block_edit_text_size_y--; /* Ignore last newline if any. */

  if ((block_edit_text = (char *)malloc(sizeof(char) *
    (block_edit_text_size_y * block_edit_text_size_x))) == NULL)
    return -1;
  memset(block_edit_text, BLOCK_EDIT_PADDING,
    block_edit_text_size_y * block_edit_text_size_x);

  rewind(fh);

  temp_size_x = 0;
  temp_size_y = 0;
  while ((c = fgetc(fh)) != EOF) {
    if (c == '\n') {
      temp_size_y++;
      if (temp_size_y > block_edit_text_size_y)
        break;
      temp_size_x = 0;
    } else {
      if (isprint(c)) {
        *(block_edit_text + (block_edit_text_size_x * temp_size_y)
          + temp_size_x) = c;
        temp_size_x++;
        if (temp_size_x > block_edit_text_size_x)
          continue;
      }
    }
  }
  fclose(fh);

  return 0;
}



static int block_edit_save_file(char *file)
{
  int i, j;
  FILE *fh;

  fh = fopen(file, "w");
  if (fh == NULL)
    return -1;

  for (i = 0; i < block_edit_text_size_y; i++) {
    for (j = 0; j < block_edit_text_size_x; j++) {
      fputc(*(block_edit_text + (block_edit_text_size_x * i) + j), fh);
    }
    fputc('\n', fh);
  }
  fclose(fh);

  return 0;
}



static void block_edit_save_dialog(char *file)
{
  int i, max_y, max_x;

  getmaxyx(stdscr, max_y, max_x);

  attron(A_BOLD);
  for (i = 0; i < max_x; i++)
    mvaddch(max_y - 1, i, ' ');
  if (block_edit_save_file(file) != 0)
    mvprintw(max_y - 1, 0, "Text saving failed!");
  else
    mvprintw(max_y - 1, 0, "Text saved to file...");
  attroff(A_BOLD);
  move(0,0);
  getch(); /* Press any key to continue. */
}



static int block_edit_resize_text(int size_y, int size_x)
{
  int i, j;
  char *new;

  if ((new = (char *)malloc(sizeof(char) * (size_y * size_x))) == NULL)
    return -1;
  memset(new, BLOCK_EDIT_PADDING, size_y * size_x);

  for (i = 0; i < block_edit_text_size_y; i++) {
    if (i >= size_y)
      break; /* Truncate if lesser size. */
    for (j = 0; j < block_edit_text_size_x; j++) {
      if (j >= size_x)
        break;
      *(new + (size_x * i) + j) =
        *(block_edit_text + (block_edit_text_size_x * i) + j);
    }
  }

  free(block_edit_text);

  block_edit_text = new;
  block_edit_text_size_y = size_y;
  block_edit_text_size_x = size_x;
  return 0;
}



static void block_edit_resize_wrapper(int size_y, int size_x)
{
  if (size_y < 1 || size_x < 1)
    return;

  if (block_edit_resize_text(size_y, size_x) != 0)
    return;

  /* Make sure cursor is back in top left corner. */
  block_edit_scroll_y = 0;
  block_edit_scroll_x = 0;
  clear();
}



static void block_edit_winch_handler(int dummy)
{
  /* This combination must be executed to get new max limits, etc. */
  endwin();
  refresh();
  
  clear();
  block_edit_update_screen();

  /* This combination must be executed to avoid garbage on input. */
  flushinp();
  keypad(stdscr, TRUE);
}



static void block_edit_exit_handler(void)
{
  if (endwin() == ERR)
    fprintf(stderr, "Warning: Failed to shutdown ncurses correctly.\n");

  if (block_edit_text != NULL)
    free(block_edit_text);
}



int main(int argc, char *argv[])
{
  int c, cursor_y, cursor_x, max_y, max_x;

  if (argc != 2) {
    fprintf(stderr, "Usage: %s <file>\n", argv[0]);
    exit(1);
  }

  if (block_edit_load_file(argv[1]) != 0) {
    fprintf(stderr, "Error: Could not load file: %s\n", argv[1]);
    exit(1);
  }

  /* Initialize system. */
  initscr();
  atexit(block_edit_exit_handler);
  signal(SIGWINCH, block_edit_winch_handler);
  noecho(); /* All output controlled by program, no echo! */
  keypad(stdscr, TRUE); /* Activate arrow-keys. */
  block_edit_cursor_movement = BLOCK_EDIT_MOVE_NONE;

  /* Main event loop. */
  while (1) {
    block_edit_update_screen();
    c = getch();
    getyx(stdscr, cursor_y, cursor_x);
    getmaxyx(stdscr, max_y, max_x);

    switch (c) {
    case KEY_RIGHT:
      if (cursor_x == max_x - 1) {
        block_edit_scroll_x++;
        if (block_edit_scroll_x + max_x > block_edit_text_size_x)
          block_edit_scroll_x--;
        break;
      }
      if (cursor_x + 1 < block_edit_text_size_x)
        move(cursor_y, cursor_x + 1);
      break;

    case KEY_LEFT:
      if (cursor_x == 0) {
        block_edit_scroll_x--;
        if (block_edit_scroll_x < 0)
          block_edit_scroll_x++;
        break;
      }
      if (cursor_x > 0)
        move(cursor_y, cursor_x - 1);
      break;

    case KEY_DOWN:
      if (cursor_y == max_y - 2) {
        block_edit_scroll_y++;
        if (block_edit_scroll_y + max_y - 1> block_edit_text_size_y)
          block_edit_scroll_y--;
        break;
      }
      if (cursor_y + 1 < block_edit_text_size_y)
        move(cursor_y + 1, cursor_x);
      break;

    case KEY_UP:
      if (cursor_y == 0) {
        block_edit_scroll_y--;
        if (block_edit_scroll_y < 0)
          block_edit_scroll_y++;
        break;
      }
      if (cursor_y > 0)
        move(cursor_y - 1, cursor_x);
      break;

    case KEY_F(1):
      block_edit_help_display();
      break;

    case KEY_F(2):
      block_edit_cursor_movement++;
      if (block_edit_cursor_movement > 5)
        block_edit_cursor_movement = BLOCK_EDIT_MOVE_NONE;
      break;

    case KEY_F(3):
      block_edit_save_dialog(argv[1]);
      break;

    case KEY_F(4):
      exit(0);
      break;

    case KEY_F(5):
      block_edit_resize_wrapper(block_edit_text_size_y,
        block_edit_text_size_x + 1);
      break;

    case KEY_F(6):
      block_edit_resize_wrapper(block_edit_text_size_y,
        block_edit_text_size_x - 1);
      break;

    case KEY_F(7):
      block_edit_resize_wrapper(block_edit_text_size_y + 1,
        block_edit_text_size_x);
      break;

    case KEY_F(8):
      block_edit_resize_wrapper(block_edit_text_size_y - 1,
        block_edit_text_size_x);
      break;

    default:
      if (isprint(c)) {
        /* Only printable input allowed. */
        *(block_edit_text + (block_edit_text_size_x *
          (cursor_y + block_edit_scroll_y)) +
          (cursor_x + block_edit_scroll_x)) = c; /* Update buffer directly. */
        switch (block_edit_cursor_movement) {
        case BLOCK_EDIT_MOVE_NONE:
          /* No movement. */
          break;
        case BLOCK_EDIT_MOVE_RIGHT:
          if (cursor_x + 1 < block_edit_text_size_x)
            move(cursor_y, cursor_x + 1);
          break;
        case BLOCK_EDIT_MOVE_LEFT:
          if (cursor_x > 0)
            move(cursor_y, cursor_x - 1);
          break;
        case BLOCK_EDIT_MOVE_DOWN:
          if (cursor_y + 1 < block_edit_text_size_y)
            move(cursor_y + 1, cursor_x);
          break;
        case BLOCK_EDIT_MOVE_UP:
          if (cursor_y > 0)
            move(cursor_y - 1, cursor_x);
          break;
        }
      }
      break;

    }
  }

  exit(0);
}

