#include <iodefine.h>
#include "adc.h"

void adc_setup(void)
{
  SYSTEM.PRCR.WORD = 0xa502; /* Enable writing to MSTP registers. */
  MSTP_S12AD       = 0;      /* Disable module-stop state for 12-bit A/D. */
  SYSTEM.PRCR.WORD = 0xa500; /* Disable writing to MSTP registers. */

  /* Set analog ports as inputs. */
  PORT4.PDR.BIT.B0 = 0;
  PORT4.PDR.BIT.B1 = 0;
  PORT4.PDR.BIT.B2 = 0;
  PORT4.PDR.BIT.B3 = 0;
  PORT4.PDR.BIT.B4 = 0;
  PORT4.PDR.BIT.B5 = 0;

  /* Set analog ports as general I/O pins. */
  PORT4.PMR.BIT.B0 = 0;
  PORT4.PMR.BIT.B1 = 0;
  PORT4.PMR.BIT.B2 = 0;
  PORT4.PMR.BIT.B3 = 0;
  PORT4.PMR.BIT.B4 = 0;
  PORT4.PMR.BIT.B5 = 0;

  S12AD.ADCSR.BIT.CKS  = 0b00; /* Clock: PCLK/8 */
  S12AD.ADCSR.BIT.ADIE = 0;    /* Disable interrupt generation. */
  S12AD.ADCSR.BIT.ADCS = 0;    /* Single scan mode. */

  S12AD.ADANS0.WORD = 0b0000000000111111; /* Select channels 0 to 5. */
  S12AD.ADANS1.WORD = 0;

  S12AD.ADCER.BIT.ACE    = 0; /* Disable automatic clearing. */
  S12AD.ADCER.BIT.ADRFMT = 0; /* A/D data is flush-right. */

  MPC.PWPR.BIT.B0WI  = 0; /* Enable the PFSWE modification. */
  MPC.PWPR.BIT.PFSWE = 1; /* Disable the PFS register protect. */
  MPC.P40PFS.BIT.ASEL = 1; /* Use Port 40 as analog pin. */
  MPC.P41PFS.BIT.ASEL = 1; /* Use Port 41 as analog pin. */
  MPC.P42PFS.BIT.ASEL = 1; /* Use Port 42 as analog pin. */
  MPC.P43PFS.BIT.ASEL = 1; /* Use Port 43 as analog pin. */
  MPC.P44PFS.BIT.ASEL = 1; /* Use Port 44 as analog pin. */
  MPC.P45PFS.BIT.ASEL = 1; /* Use Port 45 as analog pin. */
  MPC.PWPR.BIT.PFSWE = 0; /* Enable the PFS register protect. */
  MPC.PWPR.BIT.B0WI  = 1; /* Disable the PFSWE modification. */
}

short adc_get(char adc_no)
{
  /* Start A/D conversion. */
  S12AD.ADCSR.BIT.ADST = 1;

  /* Wait for A/D conversion to finish; ADST bit becomes 0. */
  while (S12AD.ADCSR.BIT.ADST) {
    asm("nop");
  }

  switch (adc_no) {
  case 0:
    return S12AD.ADDR0;
  case 1:
    return S12AD.ADDR1;
  case 2:
    return S12AD.ADDR2;
  case 3:
    return S12AD.ADDR3;
  case 4:
    return S12AD.ADDR4;
  case 5:
    return S12AD.ADDR5;
  default:
    return 0;
  }
}

