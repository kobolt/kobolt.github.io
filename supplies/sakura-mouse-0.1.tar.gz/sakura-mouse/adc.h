#ifndef _ADC_H
#define _ADC_H

void adc_setup(void);
short adc_get(char adc_no);

#endif /* _ADC_H */
