#ifndef _UART_H
#define _UART_H

void uart0_setup(void);
void uart0_send(unsigned char *s, int len);

#endif /* _UART_H */
