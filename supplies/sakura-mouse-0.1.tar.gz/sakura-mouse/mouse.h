#ifndef _MOUSE_H
#define _MOUSE_H

void mouse_loop(void);

#endif /* _MOUSE_H */
