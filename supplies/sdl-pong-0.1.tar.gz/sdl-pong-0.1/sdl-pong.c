/* SDL Pong
 * Version 0.1 (15/9-07)
 * Copyright 2007 Kjetil Erga (kobolt.anarion -AT- gmail -DOT- com)
 * 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <SDL/SDL.h>
#include <stdlib.h>
#include <stdio.h>



#define GAME_SPEED      20
#define SCREEN_WIDTH   640
#define SCREEN_HEIGHT  480
#define PLAYER_WIDTH    10
#define PLAYER_HEIGHT   40
#define BALL_SIZE       10
#define BALL_SPEED_INC   1
#define CPU_ACCEL_DEF    5

#define MOVING_UP        1
#define MOVING_DOWN      2
#define MOVING_UP_INT    3
#define MOVING_DOWN_INT  4



/* Globals, for convinience: */
SDL_Rect ball;
float ball_vector_x;
float ball_vector_y;
int ball_speed;



void update_scores(int n1, int n2)
{
  char title[19]; /* "SDL Pong " + 0-9999 + colon + 0-9999 + NULL */

  if (n1 > 9999)
    n1 = 9999; /* Max score! */
  if (n2 > 9999)
    n2 = 9999;

  snprintf(title, 19, "SDL Pong %d:%d", n1, n2);
  SDL_WM_SetCaption(title, title);
}



void reset_ball(void)
{
  ball.x = (SCREEN_WIDTH / 2) - (BALL_SIZE / 2); /* Start in the middle. */
  ball.y = (SCREEN_HEIGHT / 2) - (BALL_SIZE / 2);
  ball.w = BALL_SIZE;
  ball.h = BALL_SIZE;

  /* Note: Vectors can only be from -1 to -0.2 and to 0.2 to 1,
     when using a speed of 5. (This is to avoid 0 vectors where the 
     ball does not move in one or more direction! */
  ball_vector_x = (float) 0.2 * (rand() % 5 + 1);
  ball_vector_y = (float) 0.2 * (rand() % 5 + 1);
  ball_vector_x = rand() % 2 ? ball_vector_x : -ball_vector_x;
  ball_vector_y = rand() % 2 ? ball_vector_y : -ball_vector_y;

  ball_speed = 5; /* Starting speed. */
}



int main(int argc, char *argv[])
{
  int user_moving = 0;
  int cpu_moving = 0;
  int user_acceleration = 0;
  int cpu_acceleration = 0;
  int cpu_accel_factor = CPU_ACCEL_DEF;
  int user_score = 0;
  int cpu_score = 0;

  SDL_Surface *screen;
  SDL_Rect user, cpu, background;
  SDL_Event event;



  /* Collect optional argument for cpu aggresiveness. */
  if (argc >= 2) {
    cpu_accel_factor = atoi(argv[1]);
    if (cpu_accel_factor == 0)
      cpu_accel_factor = CPU_ACCEL_DEF;
  }



  /* Define the players and background rectangles: */
  user.x = 0; /* Always on the left side. */
  user.y = (SCREEN_HEIGHT / 2) - (PLAYER_HEIGHT / 2); /* Starting position */
  user.w = PLAYER_WIDTH;
  user.h = PLAYER_HEIGHT;

  cpu.x = SCREEN_WIDTH - PLAYER_WIDTH; /* Always on the rigth side. */
  cpu.y = (SCREEN_HEIGHT / 2) - (PLAYER_HEIGHT / 2); /* Starting position */
  cpu.w = PLAYER_WIDTH;
  cpu.h = PLAYER_HEIGHT;

  background.x = 0;
  background.y = 0;
  background.w = SCREEN_WIDTH;
  background.h = SCREEN_HEIGHT;



  /* Initialize: */
  if (SDL_Init(SDL_INIT_VIDEO) != 0) {
    printf("error: unable to initalize SDL: %s\n", SDL_GetError());
    return 1;
  }
  atexit(SDL_Quit);

  screen = SDL_SetVideoMode(SCREEN_WIDTH, SCREEN_HEIGHT, 8, SDL_DOUBLEBUF);
  if (screen == NULL) {
    printf("error: unable to set video mode: %s\n", SDL_GetError());
    return 1;
  }

  update_scores(user_score, cpu_score);
  srand((unsigned)time(NULL)); /* Seed randomizer with current time. */
  reset_ball();



  /* Start the main game loop: */
  while (1) {
    /* Check for user input, and process: */
    if (SDL_PollEvent(&event) == 1) {
      switch(event.type) {
      case SDL_KEYDOWN:
        switch (event.key.keysym.sym) {
        case SDLK_q:
          exit(0);
          break;
        case SDLK_UP: 
#ifdef DEBUG
          fprintf(stderr, "debug: keypress up.\n");
#endif
          if (user_moving == 0)
            user_moving = MOVING_UP;
          else if (user_moving == MOVING_DOWN)
            user_moving = MOVING_DOWN_INT; /* This captures the situation where
                                              two keys are down at once, queue
                                              this "interrupt" to allow smoother
                                              moves! */
          break;
        case SDLK_DOWN: 
#ifdef DEBUG
          fprintf(stderr, "debug: keypress down.\n");
#endif
          if (user_moving == 0)
            user_moving = MOVING_DOWN;
          else if (user_moving == MOVING_UP)
            user_moving = MOVING_UP_INT;
          break;
        }
        break;
      case SDL_KEYUP:
        switch (event.key.keysym.sym) {
        case SDLK_UP: 
#ifdef DEBUG
          fprintf(stderr, "debug: keyrelase up.\n");
#endif
          if (user_moving == MOVING_UP_INT)
            user_moving = MOVING_DOWN;
          else
            user_moving = 0;
            user_acceleration = 0; /* Reset acceleration. */
          break;
        case SDLK_DOWN: 
#ifdef DEBUG
          fprintf(stderr, "debug: keyrelease down.\n");
#endif
          if (user_moving == MOVING_DOWN_INT)
            user_moving = MOVING_UP;
          else
            user_moving = 0;
            user_acceleration = 0;
          break;
        }
        break;
      case SDL_QUIT:
        exit(0);
        break;
      }
    }
    


    /* Move the user's player as long as the key is down,
       and prevent moving outside the edges: */
    if (user_moving == MOVING_UP || user_moving == MOVING_UP_INT) {
      user.y--;
      user_acceleration++;
      user.y -= user_acceleration;
      if (user.y < 0)
        user.y = 0;
    } else if (user_moving == MOVING_DOWN || user_moving == MOVING_DOWN_INT) {
      user.y++;
      user_acceleration++;
      user.y += user_acceleration;
      if (user.y > SCREEN_HEIGHT - PLAYER_HEIGHT)
        user.y = SCREEN_HEIGHT - PLAYER_HEIGHT;
    }



    /* Calculate cpu's movements: */
    if (cpu.y + (PLAYER_HEIGHT / 2) > ball.y + (BALL_SIZE / 2)) {
      /* Cpu wants to go upwards. */
#ifdef DEBUG
      fprintf(stderr, "debug: cpu wants to go up (%d): %d\n",
              cpu_moving, cpu_acceleration);
#endif
      if (cpu_moving == MOVING_DOWN) {
        cpu_acceleration -= cpu_accel_factor; /* Slow down acceleration. */
        cpu_moving = MOVING_DOWN;
      } else {
        cpu_acceleration += cpu_accel_factor; /* Speed up acceleration. */
        cpu_moving = MOVING_UP;
      }
      cpu.y += cpu_acceleration;
    } else { /* Cpu wants to go downwards. */
#ifdef DEBUG
      fprintf(stderr, "debug: cpu wants to go down (%d): %d\n",
              cpu_moving, cpu_acceleration);
#endif
      if (cpu_moving == MOVING_UP) {
        cpu_acceleration -= cpu_accel_factor;
        cpu_moving = MOVING_UP;
      } else {
        cpu_acceleration += cpu_accel_factor;
        cpu_moving = MOVING_DOWN;
      }
      cpu.y += cpu_acceleration;
    }

    if (cpu.y > SCREEN_HEIGHT - PLAYER_HEIGHT) {
      /* Prevent cpu from running away! */
      cpu.y = SCREEN_HEIGHT - PLAYER_HEIGHT;
      cpu_acceleration = 0; /* Acceleration is now reset! */
    } else if (cpu.y < 0) {
      cpu.y = 0;
      cpu_acceleration = 0;
    }



    /* Calculate ball movement and sense collisions: */
    ball.x += ball_vector_x * ball_speed;
    if (ball.x > SCREEN_WIDTH - BALL_SIZE)
      ball.x = SCREEN_WIDTH - BALL_SIZE;
    else if (ball.x < 0)
      ball.x = 0;

    ball.y += ball_vector_y * ball_speed;
    if (ball.y > SCREEN_HEIGHT - BALL_SIZE)
      ball.y = SCREEN_HEIGHT - BALL_SIZE;
    else if (ball.y < 0)
      ball.y = 0;

#ifdef DEBUG
    fprintf(stderr, "debug: ball -> x:%d y:%d   vector -> x:%f y:%f \n",
            ball.x, ball.y, ball_vector_x, ball_vector_y);
#endif

    if (ball.y == SCREEN_HEIGHT - BALL_SIZE) { /* Hit bottom. */
#ifdef DEBUG
      fprintf(stderr, "debug: ball hit bottom.\n");
#endif
      ball_vector_y = -ball_vector_y;
      ball_speed++;
    }

    if (ball.y == 0) { /* Hit top. */
#ifdef DEBUG
      fprintf(stderr, "debug: ball hit bottom.\n");
#endif
      ball_vector_y = -ball_vector_y;
      ball_speed++;
    }

    if (ball.x == SCREEN_WIDTH - BALL_SIZE) { /* Hit right side... */
      if (ball.y + BALL_SIZE >= cpu.y &&
          ball.y <= cpu.y + PLAYER_HEIGHT) { /* ...But cpu was in the way. */
#ifdef DEBUG
        fprintf(stderr, "debug: ball inside cpu's X area (fast)\n");
#endif
        ball_vector_x = -ball_vector_x; /* Cpu only affects the X vector.  */
        ball_speed++;
        ball.x = SCREEN_WIDTH - BALL_SIZE - PLAYER_WIDTH - 1;
      } else { /* ...And went past cpu, scoring for the user. */
        user_score++;
        update_scores(user_score, cpu_score);
#ifdef DEBUG
        fprintf(stderr, "debug: ball hit right, user score: %d\n", user_score);
#endif
        reset_ball();
      }
    }

    if (ball.x == 0) { /* Hit left side... */
      if (ball.y + BALL_SIZE >= user.y &&
          ball.y <= user.y + PLAYER_HEIGHT) { /* ...But user was in the way. */
#ifdef DEBUG
        fprintf(stderr, "debug: ball inside user's X area (fast)\n");
#endif
        ball_vector_x = -ball_vector_x;
        if ((user_moving == MOVING_DOWN || user_moving == MOVING_DOWN_INT) &&
             ball_vector_y < 0)
          ball_vector_y = -ball_vector_y;
        if ((user_moving == MOVING_UP || user_moving == MOVING_UP_INT) &&
             ball_vector_y > 0)
          ball_vector_y = -ball_vector_y;
        ball_speed++;
        ball.x = PLAYER_WIDTH + 1; /* Add one to avoid the next if-statement to 
                                      execute, resulting in strange movement. */
      } else { /* ...And went past user, scoring for the cpu. */
        cpu_score++;
        update_scores(user_score, cpu_score);
#ifdef DEBUG
        fprintf(stderr, "debug: ball hit left, cpu score: %d\n", cpu_score);
#endif
        reset_ball();
      }
    }

    if ((ball.x >= SCREEN_WIDTH - BALL_SIZE - PLAYER_WIDTH) &&
        (ball.x < SCREEN_WIDTH - BALL_SIZE)) { /* Inside cpu's X area (smooth). */
#ifdef DEBUG
      fprintf(stderr, "debug: ball inside cpu's X area (smooth)\n");
#endif
      if (ball.y + BALL_SIZE >= cpu.y &&
          ball.y <= cpu.y + PLAYER_HEIGHT) {
        ball_vector_x = -ball_vector_x; /* Cpu only affects the X vector.  */
        ball_speed++;
        ball.x = SCREEN_WIDTH - BALL_SIZE - PLAYER_WIDTH;
      }
    }

    if ((ball.x <= PLAYER_WIDTH) &&
         (ball.x > 0)) { /* Inside user's X area (smooth). */
#ifdef DEBUG
      fprintf(stderr, "debug: ball inside user's X area (smooth)\n");
#endif
      if (ball.y + BALL_SIZE >= user.y &&
          ball.y <= user.y + PLAYER_HEIGHT) {
        ball_vector_x = -ball_vector_x;
        if ((user_moving == MOVING_DOWN || user_moving == MOVING_DOWN_INT) &&
             ball_vector_y < 0)
          ball_vector_y = -ball_vector_y;
        if ((user_moving == MOVING_UP || user_moving == MOVING_UP_INT) &&
             ball_vector_y > 0)
          ball_vector_y = -ball_vector_y;
        ball_speed++;
        ball.x = PLAYER_WIDTH;
      }
    }

    /* Update screen, and delay: */
    SDL_FillRect(screen, &background, 0x000000);
    SDL_FillRect(screen, &user, 0xffffff);
    SDL_FillRect(screen, &cpu, 0xffffff);
    SDL_FillRect(screen, &ball, 0xffffff);
    SDL_Flip(screen);
    SDL_Delay(GAME_SPEED);
  }
  
  return 0;
}

