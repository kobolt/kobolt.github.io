#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <error.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <limits.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>



#define PACKET_SIZE 512
#define HEADER_SIZE 4
#define DATA_SIZE (PACKET_SIZE - HEADER_SIZE)
#define MAX_ENTRIES 128 /* Limited by 7-bits in protocol .*/

#define NO_FILE '-'



typedef struct msg_header_s {
  unsigned int type  :1; /* 0 = Request, 1 = Acknowledge. */
  unsigned int entry :7;
  unsigned int part  :24; /* NOTE: Part indexing starts at 1. */
} msg_header_t;

/* Indexed from 1 for the file entries, so entry 0 will be a dummy entry,
   and this makes the whole thing easer to program. */
typedef struct entry_s {
  uint32_t parts;  /* Actually, only 24-bits supported by protocol. */
  char *filename;  /* Full path in local list, just filename in remote list. */
  FILE *fh;        /* File handle. */
  uint8_t *gotten; /* Parts gotten. (Only used in remote list.) */
  uint32_t total_gotten; /* Counter of parts gotten. (Only in remote list.) */
  int32_t last_gotten;  /* Last part gotten (Only in remote list.) */
} entry_t;

/* File handle is always open in the local list. In the remote list, it
   is opened on demand when the get command is sent to request the file,
   and then closed when downloading is complete. */

/* List packages starts with 4 bytes of an unsigned integer representing the
   total parts for that entry, then the filename until the package ends. */



static int msg_socket;
static int entry_in_transfer;
static int verbose_mode;
static uint32_t current_ip;
static uint16_t current_port;

static entry_t local_list[MAX_ENTRIES];
static entry_t remote_list[MAX_ENTRIES];



static inline int part_is_gotten(int entry, int part)
{
  if (entry == 0) { /* List. */
    if (remote_list[part].filename == NULL)
      return 0;
    else
      return 1;
  } else { /* File. */
    return (remote_list[entry].gotten[part / 8] >> (part % 8)) & 0x1;
  }
}



static inline void set_part_gotten(int entry, int part)
{
  if (part_is_gotten(entry, part))
    return; /* Do not update "total" counter. */
  remote_list[entry].gotten[part / 8] |= (0x1 << (part % 8));
  remote_list[entry].total_gotten++;
  remote_list[entry].last_gotten = part;
}



static int init_parts_gotten(int entry)
{
  int i;
  if ((remote_list[entry].gotten = (uint8_t *)malloc(sizeof(uint8_t) *
      ((remote_list[entry].parts / 8) + 1))) == NULL) {
    return -1;
  }
  for (i = 0; i <= (remote_list[entry].parts / 8); i++)
    remote_list[entry].gotten[i] = 0x00;
  return 0;
}



static int gotten_parts(int entry)
{
  int i, count = 0;

  if (entry == 0) { /* List. */
    for (i = 1; i < MAX_ENTRIES; i++) {
      if (remote_list[i].filename != NULL)
        count++;
    }
    return count;
  } else { /* File. */
    return remote_list[entry].total_gotten;
  }
}



static int total_parts(int entry)
{
  if (entry == 0) { /* List. */
    return MAX_ENTRIES - 1;
  } else { /* File. */
    return remote_list[entry].parts;
  }
}



static int next_part(int entry)
{
  int i;

  if (entry == 0) { /* List. */
    for (i = 1; i < MAX_ENTRIES; i++) {
      if (remote_list[i].filename == NULL)
        return i;
    }
    return 1; /* Not sure, just try part 1. */

  } else { /* File. */

    for (i = remote_list[entry].last_gotten + 1;
         i < remote_list[entry].parts; i++) {
      if (! part_is_gotten(entry, i))
        return i;
    }
    for (i = 0; i < remote_list[entry].parts; i++) {
      if (! part_is_gotten(entry, i))
        return i;
    }
    return 0; /* Not sure, just try part 0. */

  }
}



static void send_packet(uint8_t *data, size_t size, uint32_t ip, uint16_t port)
{
  int sent;
  struct sockaddr_in si;

  memset(&si, 0, sizeof(struct sockaddr_in));
  si.sin_family = AF_INET;
  si.sin_addr.s_addr = ip;
  si.sin_port = htons(port);

  sent = sendto(msg_socket, data, size, 0,
   (struct sockaddr *)&si, sizeof(struct sockaddr_in));

  if (sent == -1)
    error(0, errno, "sendto()");
}



static void send_file_part(int entry, unsigned int part,
                           uint32_t ip, uint16_t port)
{
  size_t bytes_read;
  uint8_t data[PACKET_SIZE];
  msg_header_t *header;

  if (entry <= 0 || entry >= MAX_ENTRIES) {
    if (verbose_mode)
      error(0, 0, "%s(): Entry out of range: 0x%x", __func__, entry);
    return;
  }

  if (local_list[entry].fh == NULL) {
    if (verbose_mode)
      error(0, 0, "%s(): File does not exist", __func__);
    return;
  }

  if (fseek(local_list[entry].fh, (part * DATA_SIZE), SEEK_SET) == -1) {
    if (verbose_mode)
      error(0, 0, "%s(): Part out of range: 0x%x", __func__, part);
    return;
  }

  header = (msg_header_t *)&data[0];
  header->type = 1;
  header->entry = entry;
  header->part = part;

  clearerr(local_list[entry].fh);
  bytes_read = 0;
  while (1) {
    bytes_read += fread(&data[4], 1, (DATA_SIZE - bytes_read),
      local_list[entry].fh);
    if (bytes_read >= DATA_SIZE)
      break;
    if (feof(local_list[entry].fh))
      break;
  }

  send_packet(data, bytes_read + 4, ip, port);
}



static void send_list_part(int part, uint32_t ip, uint16_t port)
{
  uint8_t data[PACKET_SIZE];
  msg_header_t *header;
  uint32_t *parts;

  /* For the list, the "part" will actually be the list entry requested. */
  if (part <= 0 || part >= MAX_ENTRIES) {
    if (verbose_mode)
      error(0, 0, "%s(): Part (entry) out of range: 0x%x", __func__, part);
    return;
  }

  header = (msg_header_t *)&data[0];
  header->type = 1;
  header->entry = 0;
  header->part = part;

  parts = (uint32_t *)&data[4];
  *parts = local_list[part].parts;

  if (local_list[part].filename != NULL) {
    strncpy((char *)&data[8], local_list[part].filename,
            strlen(local_list[part].filename) + 1);
    send_packet(data, 8 + strlen(local_list[part].filename) + 1, ip, port);
  } else {
    data[8] = NO_FILE;
    data[9] = '\0';
    send_packet(data, 10, ip, port);
  }
}



static void request_part(int entry, int part, uint32_t ip, uint16_t port)
{
  uint8_t data[4];
  msg_header_t *header;

  header = (msg_header_t *)&data[0];
  header->type = 0;
  header->entry = entry;
  header->part = part;

  send_packet(data, 4, ip, port);
}



static void handle_socket_message(int signo, siginfo_t *siginfo, void *context)
{
  int received, written;
  socklen_t size;
  struct sockaddr_in si;
  uint8_t data[PACKET_SIZE];
  msg_header_t *header;

  /* Just loop until no more messages available,
     to avoid queueing on the socket in case of lost interrupts. */
  while (1) {
    size = sizeof(struct sockaddr_in);
    received = recvfrom(msg_socket, data, PACKET_SIZE, 0,
      (struct sockaddr *)&si, &size);

    if (received == 0) {
      printf("Remote host has shutdown.\n");
      return;
    } else if (received == -1) {
      if (errno != EAGAIN)
        error(0, errno, "recvfrom()");
      return;
    }

    if (received < 4) {
      if (verbose_mode)
        error(0, 0, "%s(): Package less than 4 bytes", __func__);
      return;
    }

    header = (msg_header_t *)&data[0];

    if (header->type == 0) { /* Request. (Act as server.) */

#ifdef DEBUG
      if (verbose_mode) error(0, 0,
        "%s(): Got request, entry: 0x%x, part: 0x%x",
        __func__, header->entry, header->part);
#endif

      /* Reply to the same ip and port, to avoid having to save them. */
      if (header->entry == 0) /* List request. */
        send_list_part(header->part,
                       si.sin_addr.s_addr, ntohs(si.sin_port));
      else /* File request. */
        send_file_part(header->entry, header->part, 
                       si.sin_addr.s_addr, ntohs(si.sin_port));

    } else { /* Acknowledge. (Act as client.) */ 

#ifdef DEBUG
      if (verbose_mode) error(0, 0,
        "%s(): Got acknowledge, entry: 0x%x, part: 0x%x",
        __func__, header->entry, header->part);
#endif

      if (entry_in_transfer == -1) {
        if (verbose_mode)
          error(0, 0, "%s(): Got acknowledge when not in transfer: 0x%x",
            __func__, header->entry);
        return;
      }

      if (header->entry != entry_in_transfer) {
        if (verbose_mode)
          error(0, 0, "%s(): Got acknowledge for wrong entry: 0x%x != 0x%x",
            __func__, header->entry, entry_in_transfer);
        return;
      }

      if (part_is_gotten(header->entry, header->part)) {
        if (verbose_mode)
          error(0, 0, "%s(): Part already gotten: 0x%x",
            __func__, header->part);
        return;
      }

      if (header->entry == 0) { /* List acknowledge. */
        if (header->part <= 0 || header->part >= MAX_ENTRIES) {
          if (verbose_mode)
            error(0, 0, "%s(): Part (entry) out of range: 0x%x",
              __func__, header->part);
          return;
        }

        remote_list[header->part].parts = *(uint32_t *)&data[4];
        remote_list[header->part].filename =
          (char *)malloc(sizeof(char) * (received - 7));
        strncpy(remote_list[header->part].filename, (char *)&data[8],
          received - 8);

      } else { /* File acknowledge. */
        if (header->entry <= 0 || header->entry >= MAX_ENTRIES) {
          if (verbose_mode)
            error(0, 0, "%s(): Entry out of range: 0x%x",
              __func__, header->entry);
          return;
        }
        
        if (header->part < 0 || 
            header->part >= remote_list[header->entry].parts) {
          if (verbose_mode)
            error(0, 0, "%s(): Part out of range: 0x%x",
              __func__, header->part);
          return;
        }

        if (remote_list[header->entry].fh != NULL) {
          if (fseek(remote_list[header->entry].fh,
            (header->part * DATA_SIZE), SEEK_SET) == -1)
            error(1, errno, "fseek()");
          written = 0;
          while (written < (received - 4)) {
            written += fwrite(&data[4], 1, (received - 4 - written),
              remote_list[header->entry].fh);
          }
          set_part_gotten(header->entry, header->part);
        }
      }

      /* Request new parts here. (Should be more effective.) */
      if (gotten_parts(entry_in_transfer) < total_parts(entry_in_transfer)) {
        request_part(entry_in_transfer, next_part(entry_in_transfer),
          si.sin_addr.s_addr, ntohs(si.sin_port));
      }
    }
  }
}



static void destroy_socket(void)
{
  close(msg_socket);
}



static void destroy_remote_list(void)
{
  int i;

  for (i = 1; i < MAX_ENTRIES; i++) {
    if (remote_list[i].filename != NULL)
      free(remote_list[i].filename);
    if (remote_list[i].fh != NULL)
      fclose(remote_list[i].fh);
    if (remote_list[i].gotten != NULL)
      free(remote_list[i].gotten);
  }
}



static void destroy_local_list(void)
{
  int i;

  for (i = 1; i < MAX_ENTRIES; i++) {
    if (local_list[i].filename != NULL)
      free(local_list[i].filename);
    if (local_list[i].fh != NULL)
      fclose(local_list[i].fh);
  }

  destroy_remote_list(); /* This has no atexit() handler, so cleanup here. */
}



static void init_signal(void)
{
  struct sigaction sa;
  sigset_t ss;

  if (sigfillset(&ss) == -1)
    error(1, 0, "sigfillset() failed.");

  sa.sa_handler = NULL;
  sa.sa_sigaction = handle_socket_message;
  sa.sa_mask = ss;
  sa.sa_flags = SA_SIGINFO;
  sa.sa_restorer = NULL;

  if (sigaction(SIGIO, &sa, NULL) == -1)
    error(1, 0, "sigaction() failed.");
}



static void init_socket(uint16_t port)
{
  struct sockaddr_in si;

  if ((msg_socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
    error(1, errno, "socket()");
  
  atexit(destroy_socket);

  if (fcntl(msg_socket, F_SETOWN, getpid()) == -1)
    error(1, errno, "fcntl()");
  if (fcntl(msg_socket, F_SETFL, O_ASYNC | O_NONBLOCK) == -1)
    error(1, errno, "fcntl()");

  memset(&si, 0, sizeof(struct sockaddr_in));
  si.sin_family = AF_INET;
  si.sin_addr.s_addr = INADDR_ANY;
  si.sin_port = htons(port);

  if (bind(msg_socket, (struct sockaddr *)&si,
      sizeof(struct sockaddr_in)) == -1)
    error(1, errno, "bind()");
}



static void init_local_list(void)
{
  int i;

  for (i = 0; i < MAX_ENTRIES; i++) {
    local_list[i].parts        = 0;
    local_list[i].filename     = NULL;
    local_list[i].fh           = NULL;
    local_list[i].gotten       = NULL;
    local_list[i].total_gotten = 0;
    local_list[i].last_gotten  = -1;
  }

  atexit(destroy_local_list);
}



static void init_remote_list(void)
{
  int i;

  for (i = 0; i < MAX_ENTRIES; i++) {
    remote_list[i].parts        = 0;
    remote_list[i].filename     = NULL;
    remote_list[i].fh           = NULL;
    remote_list[i].gotten       = NULL;
    remote_list[i].total_gotten = 0;
    remote_list[i].last_gotten  = -1;
  }
}



static void share_command(char *filename)
{
  int i, free_entry = -1;
  struct stat st;

  if (filename == NULL)
    return;

  if (strchr(filename, '/') != NULL) {
    printf("Not supported, please change directory to where the file is.\n");
    return; 
  }

  for (i = 1; i < MAX_ENTRIES; i++) {
    if (local_list[i].filename == NULL) {
      free_entry = i;
      break;
    }
  }

  if (free_entry == -1) {
    printf("Local list is full.\n");
    return; 
  }

  if ((local_list[free_entry].fh = fopen(filename, "r")) == NULL) {
    printf("Unable to open filehandle. (Does file exist?)\n");
    return;
  }

  if (stat(filename, &st) == -1) {
    error(0, errno, "stat()");
    fclose(local_list[free_entry].fh);
    local_list[free_entry].fh = NULL;
    return;
  }
  local_list[free_entry].parts = (st.st_size / DATA_SIZE) + 1;

  local_list[free_entry].filename = (char *)malloc(sizeof(char) *
    (strlen(filename) + 1));
  strncpy(local_list[free_entry].filename, filename, strlen(filename) + 1);
}



static void host_command(char *hostname, uint32_t *ip)
{
  struct hostent *he;
  
  if (hostname == NULL)
    return;

  he = gethostbyname(hostname);
  if (he == NULL) {
    printf("Unable to set new host.\n");
    return; 
  }

  memcpy(ip, he->h_addr_list[0], sizeof(uint32_t));
  printf("Host set to: %s\n", inet_ntoa(*(struct in_addr *)(ip)));
}



static void list_command(uint32_t ip, uint32_t port)
{
  uint8_t data[4];
  msg_header_t *header;

  init_remote_list();

  entry_in_transfer = 0; /* Locks the user interface. */

  header = (msg_header_t *)&data[0];
  header->type = 0;
  header->entry = 0;
  header->part = next_part(0);
  send_packet(data, 4, ip, port);
}



static void get_command(char *entry, uint32_t ip, uint32_t port)
{
  uint8_t data[4];
  msg_header_t *header;
  int entry_numeric;

  if (entry == NULL)
    return;

  entry_numeric = atoi(entry);
  if (entry_numeric <= 0 || entry_numeric >= MAX_ENTRIES) {
    printf("Entry out of range.\n");
    return;
  }

  if (remote_list[entry_numeric].filename[0] == NO_FILE) {
    printf("Entry does not exist on remote host.\n");
    return;
  }

  if (remote_list[entry_numeric].fh == NULL) {
    if ((remote_list[entry_numeric].fh =
         fopen(remote_list[entry_numeric].filename, "wx")) == NULL) {
      /* 'x' is a GNU specific fopen() flag. */
      printf("Unable to open filehandle. (Does file already exist?)\n");
      return;
    }

    if (init_parts_gotten(entry_numeric) == -1) {
      printf("Unable to allocate memory.\n");
      fclose(remote_list[entry_numeric].fh);
      remote_list[entry_numeric].fh = NULL;
      return;
    }
  } /* Else: Open already, try to resume downloading. */

  entry_in_transfer = entry_numeric; /* Locks the user interface. */

  header = (msg_header_t *)&data[0];
  header->type = 0;
  header->entry = entry_numeric;
  header->part = next_part(entry_numeric);
  send_packet(data, 4, ip, port);
}



static void chdir_command(char *directory)
{
  if (directory == NULL)
    return;

  if (chdir(directory) == -1)
    printf("Unable to change directory.\n");
}



static void print_command(void)
{
  int i;
  char dir[PATH_MAX];

  getcwd(dir, PATH_MAX);
  printf("Current Directory: %s\n", dir);

  printf("\nLocal List:\n");
  for (i = 1; i < MAX_ENTRIES; i++) {
    if (local_list[i].filename == NULL)
      break;
    printf("%3d: %8u: %s\n", i, local_list[i].parts, local_list[i].filename);
  }

  printf("\nRemote List:\n");
  for (i = 1; i < MAX_ENTRIES; i++) {
    if (remote_list[i].filename == NULL)
      break;
    if (remote_list[i].filename[0] == NO_FILE)
      continue;
    printf("%3d: %8u: %s\n", i, remote_list[i].parts, remote_list[i].filename);
  }
  printf("\n");

}



static char *find_arg(char *line)
{
  int in_space = 0;
  while (*line != '\0') {
    if (in_space) {
      if (*line != ' ')
        return line;
    } else {
      if (*line == ' ')
        in_space = 1;
    }
    line++;
  }
  return NULL; /* Argument not found. */
}



static void display_help(void)
{
  fprintf(stderr, "\nOptions:\n"
    "  -h        Display this help and exit.\n"
    "  -v        Verbose mode.\n"
    "  -p PORT   Use PORT to communicate.\n"
    "  -m FILE   Run macro FILE with commands during to startup.\n"
    "  -H HOST   Connect to initial HOST.\n\n");
}



static void display_commands(FILE *fh)
{
  fprintf(fh, "\nCommands:\n"
    "  help         Display this help.\n"
    "  quit         Quit the application.\n"
    "  host HOST    Connect to HOST.\n"
    "  print        Display local and remote file lists.\n"
    "  list         Retrieve file list from remote host.\n"
    "  get ENTRY    Get file by ENTRY from remote host.\n"
    "  share FILE   Share FILE with all clients.\n"
    "  chdir DIR    Change directory to DIR.\n\n");
}



static void evaluate_line(char *line)
{
  if (strncmp(line, "quit", 4) == 0) {
    exit(0);

  } else if (strncmp(line, "share", 5) == 0) {
    share_command(find_arg(line));

  } else if (strncmp(line, "host", 4) == 0) {
    host_command(find_arg(line), &current_ip);

  } else if (strncmp(line, "list", 4) == 0) {
    if (current_ip == 0)
      printf("Current host/IP not set. (Use host command.)\n");
    else
      list_command(current_ip, current_port);

  } else if (strncmp(line, "get", 3) == 0) {
    if (current_ip == 0)
      printf("Current host/IP not set. (Use host command.)\n");
    else {
      /* Check that remote list has been retrieved first. */
      if (gotten_parts(0) == total_parts(0))
        get_command(find_arg(line), current_ip, current_port);
      else
        printf("Remote list not retrieved yet. (Use list command.)\n");
    }

  } else if (strncmp(line, "chdir", 5) == 0) {
    chdir_command(find_arg(line));

  } else if (strncmp(line, "print", 5) == 0) {
    print_command();

  } else if (strncmp(line, "help", 4) == 0) {
    display_commands(stdout);

  } else {
    if (strlen(line) > 0)
      printf("Unknown command. (Use help command for a list.)\n");
  }
}



static void run_macro_file(char *file)
{
  FILE *fh;
  char line[PATH_MAX];

  fh = fopen(file, "r");
  if (fh == NULL) {
    printf("Unable to open macro file.\n");
    return;
  }

  while (fgets(line, PATH_MAX, fh) != NULL) {
    line[strlen(line) - 1] = '\0'; /* Strip newline. */
    evaluate_line(line);
  }

  fclose(fh);
}



int main(int argc, char *argv[])
{
  int c, i;
  char *macro, line[PATH_MAX];
  uint32_t last_gotten;

  macro = NULL;
  current_port = current_ip = verbose_mode = 0;
  while ((c = getopt(argc, argv, "hvp:m:H:")) != -1) {
    switch (c) {
    case 'h':
      display_help();
      display_commands(stderr);
      return 0;

    case 'v':
      verbose_mode = 1;
      break;

    case 'p':
      current_port = atoi(optarg);
      break;
      
    case 'm':
      macro = optarg;
      break;

    case 'H':
      host_command(optarg, &current_ip);
      break;

    case '?':
    default:
      display_help();
      return 1;
    }
  }

  if (current_port == 0) {
    printf("Port number must be set. (With -p option.)\n");
    display_help();
    return 1;
  }

  init_local_list();
  if (macro != NULL)
    run_macro_file(macro);
  init_signal();
  init_socket(current_port);

  entry_in_transfer = -1;
  while (1) {
continue_waiting:

    /* Lock user interface when a transfer occurs. */
    if (entry_in_transfer >= 0) {
      /* Display progress in parts and percent. */
      printf("\r%d/%d (%3d%%)", gotten_parts(entry_in_transfer),
      total_parts(entry_in_transfer), 
      (int)((gotten_parts(entry_in_transfer) /
      (double)total_parts(entry_in_transfer)) * 100));

      /* Check if all parts have been gotten, if so bail out. */
      if (gotten_parts(entry_in_transfer) == total_parts(entry_in_transfer)) {
        if (entry_in_transfer > 0) {
          fclose(remote_list[entry_in_transfer].fh);
          remote_list[entry_in_transfer].fh = NULL;
        }
        entry_in_transfer = -1;
        printf("\n");
        continue;
      }
        
      /* First timeout check, did packets get lost? */
      last_gotten = gotten_parts(entry_in_transfer);
      for (i = 0; i < 100; i++) {
        usleep(10000);
        if (last_gotten < gotten_parts(entry_in_transfer))
          goto continue_waiting;
      }

      /* Packets may have gotten lost, request more just in case. */
      request_part(entry_in_transfer, next_part(entry_in_transfer),
        current_ip, current_port);

      /* Second timeout check, is remote host dead? */
      for (i = 0; i < 3000; i++) {
        usleep(10000);
        if (last_gotten < gotten_parts(entry_in_transfer))
          goto continue_waiting;
      }

      /* Too much time has elapsed without activity, abort the transfer. */
      entry_in_transfer = -1;
      printf("\nTimed out.\n");
    }

    printf("> ");
got_signal_read_again:
    if (fgets(line, PATH_MAX, stdin) == NULL) {
      if (feof(stdin))
        return 0;
      else
        goto got_signal_read_again;
    }

    line[strlen(line) - 1] = '\0'; /* Strip newline. */
    evaluate_line(line);
  }

  return 0;
}

