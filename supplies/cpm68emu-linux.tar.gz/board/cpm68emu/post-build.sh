#!/bin/sh
set -e

# Extract binary part of Linux ELF file:
"$HOST_DIR/bin/m68k-linux-objcopy" -O binary "$BINARIES_DIR/vmlinux" "$BINARIES_DIR/vmlinux.bin" 

# Convert binary file to S-Record:
srec_cat "$BINARIES_DIR/vmlinux.bin" -binary -offset 0x400 -o "$BINARIES_DIR/vmlinux.srec" -motorola

