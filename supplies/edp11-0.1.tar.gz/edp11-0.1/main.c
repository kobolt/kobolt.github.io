#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "dl11.h"
#include "kd11.h"
#include "kd11_trace.h"
#include "ky11.h"
#include "la36.h"
#include "m9312.h"
#include "mem.h"
#include "rl11.h"
#include "rx11.h"
#include "unibus.h"
#include "vt52.h"

#define POLL_INTERVAL_DEFAULT 2000

static bool debugger_break = false;
static char panic_msg[80];

#ifdef BREAKPOINT
int32_t breakpoint_pc = -1;
#endif /* BREAKPOINT */



static void debugger_help(void)
{
  fprintf(stdout, "Commands:\n");
  fprintf(stdout, "  q                - Quit\n");
  fprintf(stdout, "  h                - Help\n");
  fprintf(stdout, "  c                - Continue\n");
  fprintf(stdout, "  s                - Step\n");
#ifdef BREAKPOINT
  fprintf(stdout, "  b <addr>         - Breakpoint\n");
#endif /* BREAKPOINT */
  fprintf(stdout, "  r                - Dump CPU Registers\n");
  fprintf(stdout, "  t [extended]     - Dump CPU Trace\n");
  fprintf(stdout, "  d <addr> [end]   - Dump Memory\n");
  fprintf(stdout, "  g <addr>         - Set PC to address and execute.\n");
  fprintf(stdout, "  e [value]        - Display or set console switches.\n");
  fprintf(stdout, "  u <addr> [value] - Read from or write to unibus.\n");
}



bool debugger(void)
{
  char input[128];
  char *argv[3];
  int argc;
  int value1;
  int value2;

  fprintf(stdout, "\n");
  while (1) {
    fprintf(stdout, "\r%06o> ", kd11_reg_get(KD11_REG_PC));

    if (fgets(input, sizeof(input), stdin) == NULL) {
      if (feof(stdin)) {
        exit(EXIT_SUCCESS);
      }
      continue;
    }

    if ((strlen(input) > 0) && (input[strlen(input) - 1] == '\n')) {
      input[strlen(input) - 1] = '\0'; /* Strip newline. */
    }

    argv[0] = strtok(input, " ");
    if (argv[0] == NULL) {
      continue;
    }

    for (argc = 1; argc < 3; argc++) {
      argv[argc] = strtok(NULL, " ");
      if (argv[argc] == NULL) {
        break;
      }
    }

    if (strncmp(argv[0], "q", 1) == 0) {
      exit(EXIT_SUCCESS);

    } else if (strncmp(argv[0], "?", 1) == 0) {
      debugger_help();

    } else if (strncmp(argv[0], "h", 1) == 0) {
      debugger_help();

    } else if (strncmp(argv[0], "c", 1) == 0) {
      return false;

    } else if (strncmp(argv[0], "s", 1) == 0) {
      return true;

#ifdef BREAKPOINT
    } else if (strncmp(argv[0], "b", 1) == 0) {
      if (argc >= 2) {
        if (sscanf(argv[1], "%o", &value1) == 1) {
          breakpoint_pc = (value1 & 0xFFFE);
          fprintf(stdout, "Breakpoint at %06o set.\n", breakpoint_pc);
        } else {
          fprintf(stdout, "Invalid argument!\n");
        }
      } else {
        if (breakpoint_pc < 0) {
          fprintf(stdout, "Missing argument!\n");
        } else {
          fprintf(stdout, "Breakpoint at %06o removed.\n", breakpoint_pc);
        }
        breakpoint_pc = -1;
      }
#endif /* BREAKPOINT */

    } else if (strncmp(argv[0], "r", 1) == 0) {
      fprintf(stdout, "R0: %06o\n", kd11_reg_get(KD11_REG_0));
      fprintf(stdout, "R1: %06o\n", kd11_reg_get(KD11_REG_1));
      fprintf(stdout, "R2: %06o\n", kd11_reg_get(KD11_REG_2));
      fprintf(stdout, "R3: %06o\n", kd11_reg_get(KD11_REG_3));
      fprintf(stdout, "R4: %06o\n", kd11_reg_get(KD11_REG_4));
      fprintf(stdout, "R5: %06o\n", kd11_reg_get(KD11_REG_5));
      fprintf(stdout, "SP: %06o\n", kd11_reg_get(KD11_REG_SP));
      fprintf(stdout, "PC: %06o\n", kd11_reg_get(KD11_REG_PC));
      fprintf(stdout, "PSW: %06o\n", unibus_read_direct(KD11_ADDRESS_PSW));

    } else if (strncmp(argv[0], "t", 1) == 0) {
      if (argc >= 2) {
        kd11_trace_dump(stdout, true);
      } else {
        kd11_trace_dump(stdout, false);
      }

    } else if (strncmp(argv[0], "d", 1) == 0) {
      if (argc >= 3) {
        sscanf(argv[1], "%o", &value1);
        sscanf(argv[2], "%o", &value2);
        mem_dump_octal(stdout, value1, value2);
      } else if (argc >= 2) {
        sscanf(argv[1], "%o", &value1);
        value2 = value1 + 0xFF;
        mem_dump_octal(stdout, value1, value2);
      } else {
        fprintf(stdout, "Missing argument!\n");
      }

    } else if (strncmp(argv[0], "g", 1) == 0) {
      if (argc >= 2) {
        sscanf(argv[1], "%o", &value1);
        kd11_reg_set(KD11_REG_PC, value1);
        return false;
      } else {
        fprintf(stdout, "Missing argument!\n");
      }

    } else if (strncmp(argv[0], "e", 1) == 0) {
      if (argc >= 2) {
        sscanf(argv[1], "%o", &value1);
        ky11_switch_set(value1);
      }
      value2 = ky11_switch_get();
      fprintf(stdout, "Switches: %c%c%c %c%c%c %c%c%c %c%c%c %c%c%c %c%c%c\n",
        ((value2 >> 17) & 1) ? '1' : '0',
        ((value2 >> 16) & 1) ? '1' : '0',
        ((value2 >> 15) & 1) ? '1' : '0',
        ((value2 >> 14) & 1) ? '1' : '0',
        ((value2 >> 13) & 1) ? '1' : '0',
        ((value2 >> 12) & 1) ? '1' : '0',
        ((value2 >> 11) & 1) ? '1' : '0',
        ((value2 >> 10) & 1) ? '1' : '0',
        ((value2 >>  9) & 1) ? '1' : '0',
        ((value2 >>  8) & 1) ? '1' : '0',
        ((value2 >>  7) & 1) ? '1' : '0',
        ((value2 >>  6) & 1) ? '1' : '0',
        ((value2 >>  5) & 1) ? '1' : '0',
        ((value2 >>  4) & 1) ? '1' : '0',
        ((value2 >>  3) & 1) ? '1' : '0',
        ((value2 >>  2) & 1) ? '1' : '0',
        ((value2 >>  1) & 1) ? '1' : '0',
        ( value2        & 1) ? '1' : '0');

    } else if (strncmp(argv[0], "u", 1) == 0) {
      if (argc >= 3) {
        sscanf(argv[1], "%o", &value1);
        sscanf(argv[2], "%o", &value2);
        unibus_write_direct((uint32_t)value1, (uint16_t)value2);
      } else if (argc >= 2) {
        sscanf(argv[1], "%o", &value1);
        value2 = unibus_read_direct((uint32_t)value1);
        fprintf(stdout, "%06o (0x%04x)\n", value2, value2);
      } else {
        fprintf(stdout, "Missing argument!\n");
      }

    } else {
      fprintf(stdout, "Unknown command: '%c' (use 'h' for help.)\n",
        argv[0][0]);
    }
  }
}



void panic(const char *format, ...)
{
  va_list args;

  va_start(args, format);
  vsnprintf(panic_msg, sizeof(panic_msg), format, args);
  va_end(args);

  debugger_break = true;
}



static void sig_handler(int sig)
{
  switch (sig) {
  case SIGINT:
    debugger_break = true;
    return;
  }
}



static void display_help(const char *progname)
{
  fprintf(stdout, "Usage: %s <options>\n", progname);
  fprintf(stdout, "Options:\n"
    "  -h        Display this help.\n"
    "  -d        Enter debugger on start.\n"
    "  -l OPT    Use LA36 console with OPT options instead of VT52 console.\n"
    "  -p NUM    Poll interval of NUM instructions instead of %d.\n"
    "  -a FILE   Load paper tape FILE using 'Absolute Loader'.\n"
    "  -b FILE   Load 2nd paper tape FILE using 'Absolute Loader'.\n"
    "  -r FILE   Load RL02 disk image FILE into RL11 controller unit 0.\n"
    "  -f FILE   Load RX01 floppy image FILE into RX11 controller unit 0.\n"
    "  -x FILE   Load Intel hex format FILE into M9312 low ROM.\n"
    "  -y FILE   Load Intel hex format FILE into M9312 high ROM.\n"
    "\n",
    POLL_INTERVAL_DEFAULT);
  fprintf(stdout, "LA36 options mask:\n"
    "  0x%X   No timeout on polling, maximize host CPU usage.\n"
    "  0x%X   Exit if the ASCII bell character appears.\n"
    "  0x%X   Automatically convert input LF to CR.\n"
    "  0x%X   Automatically convert input characters to uppercase.\n"
    "\n",
    LA36_OPTION_NO_TIMEOUT,
    LA36_OPTION_EXIT_ON_BELL,
    LA36_OPTION_AUTO_LF_TO_CR,
    LA36_OPTION_AUTO_UPPERCASE);
}



int main(int argc, char *argv[])
{
  int c;
  uint32_t poll_interval = POLL_INTERVAL_DEFAULT;
  uint32_t poll_countdown = 0;
  uint16_t address = 0;
  int la36_option = -1;
  char *absolute_loader_file = NULL;
  char *absolute_loader_2nd_file = NULL;
  char *rl11_image_file = NULL;
  char *rx11_image_file = NULL;
  char *m9312_low_rom_file = NULL;
  char *m9312_high_rom_file = NULL;

  while ((c = getopt(argc, argv, "hdl:p:a:b:r:f:x:y:")) != -1) {
    switch (c) {
    case 'h':
      display_help(argv[0]);
      return EXIT_SUCCESS;

    case 'd':
      debugger_break = true;
      break;

    case 'l':
      la36_option = atoi(optarg);
      break;

    case 'p':
      poll_interval = atoi(optarg);
      break;

    case 'a':
      absolute_loader_file = optarg;
      break;

    case 'b':
      absolute_loader_2nd_file = optarg;
      break;

    case 'r':
      rl11_image_file = optarg;
      break;

    case 'f':
      rx11_image_file = optarg;
      break;

    case 'x':
      m9312_low_rom_file = optarg;
      break;

    case 'y':
      m9312_high_rom_file = optarg;
      break;

    case '?':
    default:
      display_help(argv[0]);
      return EXIT_FAILURE;
    }
  }

  unibus_init();
  dl11_init();
  ky11_init();
  kd11_init();
  kd11_trace_init();
  mem_init();
  m9312_init();
  rl11_init();
  rx11_init();

  if (m9312_low_rom_file != NULL) {
    if (m9312_load_low_rom(m9312_low_rom_file) != 0) {
      return EXIT_FAILURE;
    }
  }

  if (m9312_high_rom_file != NULL) {
    if (m9312_load_high_rom(m9312_high_rom_file) != 0) {
      return EXIT_FAILURE;
    }
    /* Attempt automatic booting. */
    kd11_reg_set(KD11_REG_PC, unibus_read_direct(0773024) + 4);
    unibus_write_direct(KD11_ADDRESS_PSW, unibus_read_direct(0773026));
  }

  if (rl11_image_file != NULL) {
    if (rl11_load_disk(0, rl11_image_file) != 0) {
      return EXIT_FAILURE;
    }
  }

  if (rx11_image_file != NULL) {
    if (rx11_load_floppy(0, rx11_image_file) != 0) {
      return EXIT_FAILURE;
    }
  }

  if (absolute_loader_file != NULL) {
    if (mem_absolute_loader(absolute_loader_file, &address) != 0) {
      return EXIT_FAILURE;
    }
    if (absolute_loader_2nd_file != NULL) {
      if (mem_absolute_loader(absolute_loader_2nd_file, NULL) != 0) {
        return EXIT_FAILURE;
      }
    }
    if (address % 2 == 1) {
      /* Try to boot from address 0200 which is used by most diagnostics. */
      kd11_reg_set(KD11_REG_PC, 0200);
    } else {
      kd11_reg_set(KD11_REG_PC, address);
    }
  }

  panic_msg[0] = '\0';
  signal(SIGINT, sig_handler);

  if (la36_option >= 0) {
    la36_init(la36_option);
  } else {
    vt52_init();
  }

  while (1) {
    if (debugger_break) {
      dl11_pause();
      if (panic_msg[0] != '\0') {
        fprintf(stdout, "%s", panic_msg);
        panic_msg[0] = '\0';
      }
      debugger_break = debugger();
      if (! debugger_break) {
        dl11_resume();
      }
    }

    kd11_execute();

    if (poll_interval > 0) {
      if (poll_countdown > 0) {
        poll_countdown--;
      } else {
        /* Polling here is needed for programs that rely on interrupts. */
        dl11_poll();
        poll_countdown = poll_interval;
      }
    }

#ifdef BREAKPOINT
    if ((int32_t)kd11_reg_get(KD11_REG_PC) == breakpoint_pc) {
      panic("Breakpoint\n");
    }
#endif /* BREAKPOINT */
  }

  return EXIT_SUCCESS;
}



