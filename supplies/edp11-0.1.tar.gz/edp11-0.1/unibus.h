#ifndef _UNIBUS_H
#define _UNIBUS_H

#include <stdbool.h>
#include <stdint.h>

typedef uint16_t (*unibus_read_hook_t)(uint32_t);
typedef void (*unibus_write_hook_t)(uint32_t, uint16_t);
typedef void (*unibus_reset_hook_t)(void);

uint8_t unibus_read_8(uint16_t address);
uint16_t unibus_read_16(uint16_t address);
void unibus_write_8(uint16_t address, uint8_t value);
void unibus_write_16(uint16_t address, uint16_t value);

uint16_t unibus_read_direct(uint32_t unibus_address);
void unibus_write_direct(uint32_t unibus_address, uint16_t value);

void unibus_read_hook_register(uint32_t unibus_address,
  unibus_read_hook_t hook);
void unibus_write_hook_register(uint32_t unibus_address,
  unibus_write_hook_t hook);
void unibus_reset_hook_register(unibus_reset_hook_t hook);

void unibus_reset(void);
void unibus_init(void);
bool unibus_error_occured(void);
void unibus_error_reset(void);

void unibus_irq_set(uint16_t vector, uint8_t level);
uint16_t unibus_irq_get(uint8_t cpu_level);

#endif /* _UNIBUS_H */
