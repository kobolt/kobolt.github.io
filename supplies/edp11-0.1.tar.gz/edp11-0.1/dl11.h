#ifndef _DL11_H
#define _DL11_H

#include <stdbool.h>
#include <stdint.h>

#define DL11_ADDRESS_CONSOLE_RCSR 0777560
#define DL11_ADDRESS_CONSOLE_RBUF 0777562
#define DL11_ADDRESS_CONSOLE_XCSR 0777564
#define DL11_ADDRESS_CONSOLE_XBUF 0777566

typedef void (*dl11_send_hook_t)(uint8_t);
typedef uint8_t (*dl11_recv_hook_t)(void);
typedef bool (*dl11_poll_hook_t)(void);
typedef void (*dl11_pause_hook_t)(void);
typedef void (*dl11_resume_hook_t)(void);

void dl11_hook_register(dl11_send_hook_t send_hook,
  dl11_recv_hook_t recv_hook, dl11_poll_hook_t poll_hook,
  dl11_pause_hook_t pause_hook, dl11_resume_hook_t resume_hook);

void dl11_poll(void);
void dl11_pause(void);
void dl11_resume(void);
void dl11_init(void);

#endif /* _DL11_H */
