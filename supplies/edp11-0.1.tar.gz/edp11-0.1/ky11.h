#ifndef _KY11_H
#define _KY11_H

#include <stdint.h>

#define KY11_ADDRESS_SWITCH_REGISTER 0777570

uint32_t ky11_switch_get(void);
void ky11_switch_set(uint32_t value);
void ky11_init(void);

#endif /* _KY11_H */
