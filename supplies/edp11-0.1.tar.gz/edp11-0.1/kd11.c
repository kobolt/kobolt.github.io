#include "kd11.h"
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

#include "kd11_trace.h"
#include "panic.h"
#include "unibus.h"

#define KD11_VECTOR_BUS_ERR  0000004
#define KD11_VECTOR_RESERVED 0000010
#define KD11_VECTOR_BPT      0000014
#define KD11_VECTOR_IOT      0000020
#define KD11_VECTOR_EMT      0000030
#define KD11_VECTOR_TRAP     0000034
#define KD11_VECTOR_FP_ERR   0000244

#define KD11_STACK_LIMIT_DEFAULT 0400

#define kd11_ir15     (kd11_ir >> 15)
#define kd11_ir14_12 ((kd11_ir >> 12) & 7)
#define kd11_ir11_09 ((kd11_ir >>  9) & 7)
#define kd11_ir08    ((kd11_ir >>  8) & 1)
#define kd11_ir07_06 ((kd11_ir >>  6) & 3)
#define kd11_ir05_03 ((kd11_ir >>  3) & 7)
#define kd11_ir02_00 ( kd11_ir        & 7)

#define kd11_src_mode ((kd11_ir >> 9) & 7)
#define kd11_src_reg  ((kd11_ir >> 6) & 7)
#define kd11_dst_mode ((kd11_ir >> 3) & 7)
#define kd11_dst_reg   (kd11_ir       & 7)

#define kd11_psw_set(bit)  (kd11_psw |=  (1 << bit))
#define kd11_psw_clr(bit)  (kd11_psw &= ~(1 << bit))
#define kd11_psw_get(bit) ((kd11_psw >> bit) & 1)
#define kd11_psw_level    ((kd11_psw >> 5) & 7)

typedef struct kd11_float_s {
  bool sign;
  int16_t exponent;
  uint32_t mantissa;
} kd11_float_t;



static kd11_state_t kd11_state;
static uint16_t kd11_pc; /* Program Counter */
static uint16_t kd11_sp; /* Stack Pointer */
static uint16_t kd11_reg[6]; /* General Registers */
static uint16_t kd11_ir; /* Instruction Register */
static uint16_t kd11_bar; /* Bus Address Register */
static uint16_t kd11_src; /* Decoded Source */
static uint16_t kd11_dst; /* Decoded Destination */
static uint16_t kd11_psw; /* Processor Status Word */
static uint16_t kd11_slr; /* Stack Limit Register */

static bool kd11_stack_overflow = false;
static bool kd11_stack_overflow_red = false;
static bool kd11_t_flag_delay = false;
static void kd11_trap(uint16_t vector);




uint16_t kd11_reg_get(int reg)
{
  if (reg == KD11_REG_PC) {
    return kd11_pc;
  } else if (reg == KD11_REG_SP) {
    return kd11_sp;
  } else {
    return kd11_reg[reg];
  }
}



void kd11_reg_set(int reg, uint16_t value)
{
  if (reg == KD11_REG_PC) {
    kd11_pc = value;
  } else if (reg == KD11_REG_SP) {
    kd11_sp = value;
  } else {
    kd11_reg[reg] = value;
  }
}



static void kd11_stack_push(uint16_t value)
{
  uint16_t address;
  address = kd11_reg_get(KD11_REG_SP) - 2;
  kd11_reg_set(KD11_REG_SP, kd11_reg_get(KD11_REG_SP) - 2);
  unibus_write_16(address, value);
}



static uint16_t kd11_stack_pop(void)
{
  uint16_t address;
  address = kd11_reg_get(KD11_REG_SP);
  kd11_reg_set(KD11_REG_SP, kd11_reg_get(KD11_REG_SP) + 2);
  return unibus_read_16(address);
}



static void kd11_stack_limit_check(uint16_t address)
{
  uint16_t limit;
  limit = KD11_STACK_LIMIT_DEFAULT + kd11_slr;
  if (address < limit) {
    kd11_stack_overflow = true;
    if (address < (limit - 040)) { /* Red Zone */
      kd11_stack_overflow_red = true;
      kd11_reg_set(KD11_REG_SP, 4); /* Causes SP set to 0 afterwards. */
    }
  }
}



static inline void kd11_flag_zero(uint16_t value)
{
  if (value == 0) {
    kd11_psw_set(KD11_PSW_Z);
  } else {
    kd11_psw_clr(KD11_PSW_Z);
  }
}




static inline void kd11_flag_neg_16(uint16_t value)
{
  if (value >> 15) {
    kd11_psw_set(KD11_PSW_N);
  } else {
    kd11_psw_clr(KD11_PSW_N);
  }
}



static inline void kd11_flag_neg_8(uint8_t value)
{
  if (value >> 7) {
    kd11_psw_set(KD11_PSW_N);
  } else {
    kd11_psw_clr(KD11_PSW_N);
  }
}



static bool kd11_byte_instruction(void)
{
  if (kd11_ir15 == 0) {
    return false; /* All byte instructions have the most significant bit set. */
  }
  if (kd11_ir14_12 == 6 || kd11_ir14_12 == 7) {
    return false; /* SUB and floating point instructions not included. */
  }
  if (kd11_ir14_12 == 0) {
    if (kd11_ir11_09 < 5) {
      return false; /* PC and PS change instructions not included. */
    }
  }
  return true;
}



static void kd11_unhandled_instruction(void)
{
  kd11_trace_mnemonic("???");
  kd11_trace_trap_info("[%d:%d:%d:%d:%d:%d:%d]",
    kd11_ir15, kd11_ir14_12, kd11_ir11_09,
    kd11_ir08, kd11_ir07_06, kd11_ir05_03, kd11_ir02_00);

  kd11_trap(KD11_VECTOR_RESERVED);
}



static inline uint16_t kd11_fetch(void)
{
  uint16_t value;
  value = unibus_read_16(kd11_pc);
  kd11_pc += 2;
  kd11_trace_mc(value);
  return value;
}



static uint16_t kd11_operand_read(uint8_t mode, uint8_t reg)
{
  if (reg == KD11_REG_PC) {
    switch (mode) {
    case KD11_MODE_REG:
      return kd11_pc;

    case KD11_MODE_REG_DEF:
      kd11_bar = kd11_pc;
      break;

    case KD11_MODE_PC_IMM:
      kd11_bar = kd11_pc;
      (void)kd11_fetch();
      break;

    case KD11_MODE_PC_ABS:
      kd11_bar = kd11_fetch();
      break;

    case KD11_MODE_AUTO_DEC:
      kd11_pc -= 2;
      kd11_bar = kd11_pc;
      break;

    case KD11_MODE_AUTO_DEC_DEF:
      kd11_pc -= 2;
      kd11_bar = kd11_pc;
      kd11_bar = unibus_read_16(kd11_bar);
      break;

    case KD11_MODE_PC_REL:
      kd11_bar = kd11_fetch();
      kd11_bar += kd11_pc;
      break;

    case KD11_MODE_PC_REL_DEF:
      kd11_bar = kd11_fetch();
      kd11_bar += kd11_pc;
      kd11_bar = unibus_read_16(kd11_bar);
      break;
    }

  } else {
    switch (mode) {
    case KD11_MODE_REG:
      return kd11_reg_get(reg);

    case KD11_MODE_REG_DEF:
      kd11_bar = kd11_reg_get(reg);
      break;

    case KD11_MODE_AUTO_INC:
      kd11_bar = kd11_reg_get(reg);
      if (kd11_byte_instruction() && (reg != KD11_REG_SP)) {
        kd11_reg_set(reg, kd11_reg_get(reg) + 1);
      } else {
        kd11_reg_set(reg, kd11_reg_get(reg) + 2);
      }
      break;

    case KD11_MODE_AUTO_INC_DEF:
      kd11_bar = kd11_reg_get(reg);
      kd11_reg_set(reg, kd11_reg_get(reg) + 2);
      kd11_bar = unibus_read_16(kd11_bar);
      break;

    case KD11_MODE_AUTO_DEC:
      if (kd11_byte_instruction() && (reg != KD11_REG_SP)) {
        kd11_bar = kd11_reg_get(reg) - 1;
        kd11_reg_set(reg, kd11_reg_get(reg) - 1);
      } else {
        kd11_bar = kd11_reg_get(reg) - 2;
        kd11_reg_set(reg, kd11_reg_get(reg) - 2);
      }
      break;

    case KD11_MODE_AUTO_DEC_DEF:
      kd11_bar = kd11_reg_get(reg) - 2;
      kd11_reg_set(reg, kd11_reg_get(reg) - 2);
      kd11_bar = unibus_read_16(kd11_bar);
      break;

    case KD11_MODE_INDEX:
      kd11_bar = kd11_fetch();
      kd11_bar += kd11_reg_get(reg);
      break;

    case KD11_MODE_INDEX_DEF:
      kd11_bar = kd11_fetch();
      kd11_bar = unibus_read_16(kd11_reg_get(reg) + kd11_bar);
      break;
    }
  }

  if (kd11_byte_instruction()) {
    return unibus_read_8(kd11_bar);
  } else {
    return unibus_read_16(kd11_bar);
  }
}



static void kd11_operand_write(uint16_t value)
{
  if (kd11_dst_mode == KD11_MODE_REG) {
    if (kd11_byte_instruction()) {
      kd11_reg_set(kd11_dst_reg, kd11_reg_get(kd11_dst_reg) & ~0xFF);
      kd11_reg_set(kd11_dst_reg, kd11_reg_get(kd11_dst_reg) | (value & 0xFF));
    } else {
      kd11_reg_set(kd11_dst_reg, value);
    }
  } else {
    if (kd11_dst_reg == KD11_REG_SP) {
      kd11_stack_limit_check(kd11_bar);
      if (kd11_stack_overflow_red) {
        return; /* Do not write! */
      }
    }
    if (kd11_byte_instruction()) {
      unibus_write_8(kd11_bar, value);
    } else {
      unibus_write_16(kd11_bar, value);
    }
  }
}



static void kd11_double_operand(void)
{
  uint16_t result;
  uint8_t result_8;

  switch (kd11_ir >> 12) {
  case 1:
    kd11_trace_mnemonic("MOV");
    kd11_flag_neg_16(kd11_src);
    kd11_flag_zero(kd11_src);
    kd11_psw_clr(KD11_PSW_V);
    kd11_operand_write(kd11_src);
    break;

  case 2:
    kd11_trace_mnemonic("CMP");
    result = kd11_src - kd11_dst;
    kd11_flag_neg_16(result);
    kd11_flag_zero(result);
    if ((((kd11_src >> 15) & 1) == !((kd11_dst >> 15) & 1)) &&
        (((kd11_src >> 15) & 1) ^   ((result   >> 15) & 1))) {
      kd11_psw_set(KD11_PSW_V);
    } else {
      kd11_psw_clr(KD11_PSW_V);
    }
    if (((uint32_t)(kd11_src - kd11_dst) & 0x10000) > 0) {
      kd11_psw_set(KD11_PSW_C);
    } else {
      kd11_psw_clr(KD11_PSW_C);
    }
    break;

  case 3:
    kd11_trace_mnemonic("BIT");
    result = kd11_src & kd11_dst;
    kd11_flag_neg_16(result);
    kd11_flag_zero(result);
    kd11_psw_clr(KD11_PSW_V);
    break;

  case 4:
    kd11_trace_mnemonic("BIC");
    result = ~kd11_src & kd11_dst;
    kd11_flag_neg_16(result);
    kd11_flag_zero(result);
    kd11_psw_clr(KD11_PSW_V);
    kd11_operand_write(result);
    break;

  case 5:
    kd11_trace_mnemonic("BIS");
    result = kd11_src | kd11_dst;
    kd11_flag_neg_16(result);
    kd11_flag_zero(result);
    kd11_psw_clr(KD11_PSW_V);
    kd11_operand_write(result);
    break;

  case 6:
    kd11_trace_mnemonic("ADD");
    result = kd11_src + kd11_dst;
    kd11_flag_neg_16(result);
    kd11_flag_zero(result);
    if ((((kd11_src >> 15) & 1) == ((kd11_dst >> 15) & 1)) &&
        (((kd11_src >> 15) & 1) ^  ((result   >> 15) & 1))) {
      kd11_psw_set(KD11_PSW_V);
    } else {
      kd11_psw_clr(KD11_PSW_V);
    }
    if (((uint32_t)(kd11_src + kd11_dst) & 0x10000) > 0) {
      kd11_psw_set(KD11_PSW_C);
    } else {
      kd11_psw_clr(KD11_PSW_C);
    }
    kd11_operand_write(result);
    break;

  case 9:
    kd11_trace_mnemonic("MOVB");
    kd11_flag_neg_8(kd11_src);
    kd11_flag_zero(kd11_src);
    kd11_psw_clr(KD11_PSW_V);
    if (kd11_dst_mode == KD11_MODE_REG) {
      /* Perform sign extension. */
      if (kd11_psw_get(KD11_PSW_N)) {
        kd11_reg_set(kd11_dst_reg, 0xFFFF);
      } else {
        kd11_reg_set(kd11_dst_reg, 0x0000);
      }
    }
    kd11_operand_write(kd11_src);
    break;

  case 10:
    kd11_trace_mnemonic("CMPB");
    result_8 = kd11_src - kd11_dst;
    kd11_flag_neg_8(result_8);
    kd11_flag_zero(result_8);
    if ((((kd11_src >> 7) & 1) == !((kd11_dst >> 7) & 1)) &&
        (((kd11_src >> 7) & 1) ^   ((result_8 >> 7) & 1))) {
      kd11_psw_set(KD11_PSW_V);
    } else {
      kd11_psw_clr(KD11_PSW_V);
    }
    if (((uint16_t)((kd11_src & 0xFF) - (kd11_dst & 0xFF)) & 0x100) > 0) {
      kd11_psw_set(KD11_PSW_C);
    } else {
      kd11_psw_clr(KD11_PSW_C);
    }
    break;

  case 11:
    kd11_trace_mnemonic("BITB");
    result_8 = kd11_src & kd11_dst;
    kd11_flag_neg_8(result_8);
    kd11_flag_zero(result_8);
    kd11_psw_clr(KD11_PSW_V);
    break;

  case 12:
    kd11_trace_mnemonic("BICB");
    result_8 = ~kd11_src & kd11_dst;
    kd11_flag_neg_8(result_8);
    kd11_flag_zero(result_8);
    kd11_psw_clr(KD11_PSW_V);
    kd11_operand_write(result_8);
    break;

  case 13:
    kd11_trace_mnemonic("BISB");
    result_8 = kd11_src | kd11_dst;
    kd11_flag_neg_8(result_8);
    kd11_flag_zero(result_8);
    kd11_psw_clr(KD11_PSW_V);
    kd11_operand_write(result_8);
    break;

  case 14:
    kd11_trace_mnemonic("SUB");
    result = kd11_dst - kd11_src;
    kd11_flag_neg_16(result);
    kd11_flag_zero(result);
    if ((((kd11_dst >> 15) & 1) == !((kd11_src >> 15) & 1)) &&
        (((kd11_dst >> 15) & 1) ^   ((result   >> 15) & 1))) {
      kd11_psw_set(KD11_PSW_V);
    } else {
      kd11_psw_clr(KD11_PSW_V);
    }
    if (((uint32_t)(kd11_dst - kd11_src) & 0x10000) > 0) {
      kd11_psw_set(KD11_PSW_C);
    } else {
      kd11_psw_clr(KD11_PSW_C);
    }
    kd11_operand_write(result);
    break;

  default:
    kd11_unhandled_instruction();
    break;
  }
}



static void kd11_single_operand(void)
{
  uint16_t result;
  uint8_t result_8;
  bool bit;

  switch (kd11_ir >> 6) {
  case 3:
    kd11_trace_mnemonic("SWAB");
    result = kd11_dst;
    result >>= 8;
    result |= (kd11_dst << 8);
    kd11_flag_neg_8(result & 0xFF);
    kd11_flag_zero(result & 0xFF);
    kd11_psw_clr(KD11_PSW_V);
    kd11_psw_clr(KD11_PSW_C);
    kd11_operand_write(result);
    break;

  case 40:
    kd11_trace_mnemonic("CLR");
    kd11_psw_clr(KD11_PSW_N);
    kd11_psw_set(KD11_PSW_Z);
    kd11_psw_clr(KD11_PSW_V);
    kd11_psw_clr(KD11_PSW_C);
    kd11_operand_write(0);
    break;

  case 41:
    kd11_trace_mnemonic("COM");
    result = kd11_dst;
    result = ~result;
    kd11_flag_neg_16(result);
    kd11_flag_zero(result);
    kd11_psw_clr(KD11_PSW_V);
    kd11_psw_set(KD11_PSW_C);
    kd11_operand_write(result);
    break;

  case 42:
    kd11_trace_mnemonic("INC");
    result = kd11_dst;
    result++;
    kd11_flag_neg_16(result);
    kd11_flag_zero(result);
    if (kd11_dst == 0x7FFF) {
      kd11_psw_set(KD11_PSW_V);
    } else {
      kd11_psw_clr(KD11_PSW_V);
    }
    kd11_operand_write(result);
    break;

  case 43:
    kd11_trace_mnemonic("DEC");
    result = kd11_dst;
    result--;
    kd11_flag_neg_16(result);
    kd11_flag_zero(result);
    if (kd11_dst == 0x8000) {
      kd11_psw_set(KD11_PSW_V);
    } else {
      kd11_psw_clr(KD11_PSW_V);
    }
    kd11_operand_write(result);
    break;

  case 44:
    kd11_trace_mnemonic("NEG");
    result = kd11_dst;
    result = -result;
    kd11_flag_neg_16(result);
    kd11_flag_zero(result);
    if (result == 0x8000) {
      kd11_psw_set(KD11_PSW_V);
    } else {
      kd11_psw_clr(KD11_PSW_V);
    }
    if (result == 0) {
      kd11_psw_clr(KD11_PSW_C);
    } else {
      kd11_psw_set(KD11_PSW_C);
    }
    kd11_operand_write(result);
    break;

  case 45:
    kd11_trace_mnemonic("ADC");
    result = kd11_dst;
    result += kd11_psw_get(KD11_PSW_C);
    kd11_flag_neg_16(result);
    kd11_flag_zero(result);
    if (kd11_dst == 0x7FFF && kd11_psw_get(KD11_PSW_C) == 1) {
      kd11_psw_set(KD11_PSW_V);
    } else {
      kd11_psw_clr(KD11_PSW_V);
    }
    if (kd11_dst == 0xFFFF && kd11_psw_get(KD11_PSW_C) == 1) {
      kd11_psw_set(KD11_PSW_C);
    } else {
      kd11_psw_clr(KD11_PSW_C);
    }
    kd11_operand_write(result);
    break;

  case 46:
    kd11_trace_mnemonic("SBC");
    result = kd11_dst;
    result -= kd11_psw_get(KD11_PSW_C);
    kd11_flag_neg_16(result);
    kd11_flag_zero(result);
    if (kd11_dst == 0x8000) {
      kd11_psw_set(KD11_PSW_V);
    } else {
      kd11_psw_clr(KD11_PSW_V);
    }
    if (kd11_dst == 0 && kd11_psw_get(KD11_PSW_C) == 1) {
      kd11_psw_set(KD11_PSW_C);
    } else {
      kd11_psw_clr(KD11_PSW_C);
    }
    kd11_operand_write(result);
    break;

  case 47:
    kd11_trace_mnemonic("TST");
    result = kd11_dst;
    kd11_flag_neg_16(result);
    kd11_flag_zero(result);
    kd11_psw_clr(KD11_PSW_V);
    kd11_psw_clr(KD11_PSW_C);
    break;

  case 48:
    kd11_trace_mnemonic("ROR");
    result = kd11_dst;
    bit = kd11_psw_get(KD11_PSW_C);
    if (result & 1) {
      kd11_psw_set(KD11_PSW_C);
    } else {
      kd11_psw_clr(KD11_PSW_C);
    }
    result >>= 1;
    result |= (bit << 15);
    kd11_flag_neg_16(result);
    kd11_flag_zero(result);
    if (kd11_psw_get(KD11_PSW_N) ^ kd11_psw_get(KD11_PSW_C)) {
      kd11_psw_set(KD11_PSW_V);
    } else {
      kd11_psw_clr(KD11_PSW_V);
    }
    kd11_operand_write(result);
    break;

  case 49:
    kd11_trace_mnemonic("ROL");
    result = kd11_dst;
    bit = kd11_psw_get(KD11_PSW_C);
    if (result >> 15) {
      kd11_psw_set(KD11_PSW_C);
    } else {
      kd11_psw_clr(KD11_PSW_C);
    }
    result <<= 1;
    result |= bit;
    kd11_flag_neg_16(result);
    kd11_flag_zero(result);
    if (kd11_psw_get(KD11_PSW_N) ^ kd11_psw_get(KD11_PSW_C)) {
      kd11_psw_set(KD11_PSW_V);
    } else {
      kd11_psw_clr(KD11_PSW_V);
    }
    kd11_operand_write(result);
    break;

  case 50:
    kd11_trace_mnemonic("ASR");
    result = kd11_dst;
    if (result & 1) {
      kd11_psw_set(KD11_PSW_C);
    } else {
      kd11_psw_clr(KD11_PSW_C);
    }
    result >>= 1;
    result |= (kd11_dst & 0x8000);
    kd11_flag_neg_16(result);
    kd11_flag_zero(result);
    if (kd11_psw_get(KD11_PSW_N) ^ kd11_psw_get(KD11_PSW_C)) {
      kd11_psw_set(KD11_PSW_V);
    } else {
      kd11_psw_clr(KD11_PSW_V);
    }
    kd11_operand_write(result);
    break;

  case 51:
    kd11_trace_mnemonic("ASL");
    result = kd11_dst;
    if (result >> 15) {
      kd11_psw_set(KD11_PSW_C);
    } else {
      kd11_psw_clr(KD11_PSW_C);
    }
    result <<= 1;
    kd11_flag_neg_16(result);
    kd11_flag_zero(result);
    if (kd11_psw_get(KD11_PSW_N) ^ kd11_psw_get(KD11_PSW_C)) {
      kd11_psw_set(KD11_PSW_V);
    } else {
      kd11_psw_clr(KD11_PSW_V);
    }
    kd11_operand_write(result);
    break;

  case 52:
    kd11_trace_mnemonic("MARK");
    kd11_trace_operand_1(KD11_MODE_VALUE, kd11_ir & 0x3F);
    kd11_reg_set(KD11_REG_SP, kd11_pc + ((kd11_ir & 0x3F) * 2));
    kd11_pc = kd11_reg_get(KD11_REG_5);
    kd11_reg_set(KD11_REG_5, kd11_stack_pop());
    break;

  case 55:
    kd11_trace_mnemonic("SXT");
    if (kd11_psw_get(KD11_PSW_N)) {
      result = 0xFFFF; /* -1 */
    } else {
      result = 0;
    }
    kd11_flag_zero(result);
    kd11_psw_clr(KD11_PSW_V);
    kd11_operand_write(result);
    break;

  case 552:
    kd11_trace_mnemonic("CLRB");
    kd11_psw_clr(KD11_PSW_N);
    kd11_psw_set(KD11_PSW_Z);
    kd11_psw_clr(KD11_PSW_V);
    kd11_psw_clr(KD11_PSW_C);
    kd11_operand_write(0);
    break;

  case 553:
    kd11_trace_mnemonic("COMB");
    result_8 = kd11_dst;
    result_8 = ~result_8;
    kd11_flag_neg_8(result_8);
    kd11_flag_zero(result_8);
    kd11_psw_clr(KD11_PSW_V);
    kd11_psw_set(KD11_PSW_C);
    kd11_operand_write(result_8);
    break;

  case 554:
    kd11_trace_mnemonic("INCB");
    result_8 = kd11_dst;
    result_8++;
    kd11_flag_neg_8(result_8);
    kd11_flag_zero(result_8);
    if (kd11_dst == 0x7F) {
      kd11_psw_set(KD11_PSW_V);
    } else {
      kd11_psw_clr(KD11_PSW_V);
    }
    kd11_operand_write(result_8);
    break;

  case 555:
    kd11_trace_mnemonic("DECB");
    result_8 = kd11_dst;
    result_8--;
    kd11_flag_neg_8(result_8);
    kd11_flag_zero(result_8);
    if (kd11_dst == 0x80) {
      kd11_psw_set(KD11_PSW_V);
    } else {
      kd11_psw_clr(KD11_PSW_V);
    }
    kd11_operand_write(result_8);
    break;

  case 556:
    kd11_trace_mnemonic("NEGB");
    result_8 = kd11_dst;
    result_8 = -result_8;
    kd11_flag_neg_8(result_8);
    kd11_flag_zero(result_8);
    if (result_8 == 0x80) {
      kd11_psw_set(KD11_PSW_V);
    } else {
      kd11_psw_clr(KD11_PSW_V);
    }
    if (result_8 == 0) {
      kd11_psw_clr(KD11_PSW_C);
    } else {
      kd11_psw_set(KD11_PSW_C);
    }
    kd11_operand_write(result_8);
    break;

  case 557:
    kd11_trace_mnemonic("ADCB");
    result_8 = kd11_dst;
    result_8 += kd11_psw_get(KD11_PSW_C);
    kd11_flag_neg_8(result_8);
    kd11_flag_zero(result_8);
    if (kd11_dst == 0x7F && kd11_psw_get(KD11_PSW_C) == 1) {
      kd11_psw_set(KD11_PSW_V);
    } else {
      kd11_psw_clr(KD11_PSW_V);
    }
    if (kd11_dst == 0x80 && kd11_psw_get(KD11_PSW_C) == 1) {
      kd11_psw_set(KD11_PSW_C);
    } else {
      kd11_psw_clr(KD11_PSW_C);
    }
    kd11_operand_write(result_8);
    break;

  case 558:
    kd11_trace_mnemonic("SBCB");
    result_8 = kd11_dst;
    result_8 -= kd11_psw_get(KD11_PSW_C);
    kd11_flag_neg_8(result_8);
    kd11_flag_zero(result_8);
    if (kd11_dst == 0x80) {
      kd11_psw_set(KD11_PSW_V);
    } else {
      kd11_psw_clr(KD11_PSW_V);
    }
    if (kd11_dst == 0 && kd11_psw_get(KD11_PSW_C) == 1) {
      kd11_psw_set(KD11_PSW_C);
    } else {
      kd11_psw_clr(KD11_PSW_C);
    }
    kd11_operand_write(result_8);
    break;

  case 559:
    kd11_trace_mnemonic("TSTB");
    result_8 = kd11_dst;
    kd11_flag_neg_8(result_8);
    kd11_flag_zero(result_8);
    kd11_psw_clr(KD11_PSW_V);
    kd11_psw_clr(KD11_PSW_C);
    break;

  case 560:
    kd11_trace_mnemonic("RORB");
    result_8 = kd11_dst;
    bit = kd11_psw_get(KD11_PSW_C);
    if (result_8 & 1) {
      kd11_psw_set(KD11_PSW_C);
    } else {
      kd11_psw_clr(KD11_PSW_C);
    }
    result_8 >>= 1;
    result_8 |= (bit << 7);
    kd11_flag_neg_8(result_8);
    kd11_flag_zero(result_8);
    if (kd11_psw_get(KD11_PSW_N) ^ kd11_psw_get(KD11_PSW_C)) {
      kd11_psw_set(KD11_PSW_V);
    } else {
      kd11_psw_clr(KD11_PSW_V);
    }
    kd11_operand_write(result_8);
    break;

  case 561:
    kd11_trace_mnemonic("ROLB");
    result_8 = kd11_dst;
    bit = kd11_psw_get(KD11_PSW_C);
    if (result_8 >> 7) {
      kd11_psw_set(KD11_PSW_C);
    } else {
      kd11_psw_clr(KD11_PSW_C);
    }
    result_8 <<= 1;
    result_8 |= bit;
    kd11_flag_neg_8(result_8);
    kd11_flag_zero(result_8);
    if (kd11_psw_get(KD11_PSW_N) ^ kd11_psw_get(KD11_PSW_C)) {
      kd11_psw_set(KD11_PSW_V);
    } else {
      kd11_psw_clr(KD11_PSW_V);
    }
    kd11_operand_write(result_8);
    break;

  case 562:
    kd11_trace_mnemonic("ASRB");
    result_8 = kd11_dst;
    if (result_8 & 1) {
      kd11_psw_set(KD11_PSW_C);
    } else {
      kd11_psw_clr(KD11_PSW_C);
    }
    result_8 >>= 1;
    result_8 |= (kd11_dst & 0x80);
    kd11_flag_neg_8(result_8);
    kd11_flag_zero(result_8);
    if (kd11_psw_get(KD11_PSW_N) ^ kd11_psw_get(KD11_PSW_C)) {
      kd11_psw_set(KD11_PSW_V);
    } else {
      kd11_psw_clr(KD11_PSW_V);
    }
    kd11_operand_write(result_8);
    break;

  case 563:
    kd11_trace_mnemonic("ASLB");
    result_8 = kd11_dst;
    if (result_8 >> 7) {
      kd11_psw_set(KD11_PSW_C);
    } else {
      kd11_psw_clr(KD11_PSW_C);
    }
    result_8 <<= 1;
    kd11_flag_neg_8(result_8);
    kd11_flag_zero(result_8);
    if (kd11_psw_get(KD11_PSW_N) ^ kd11_psw_get(KD11_PSW_C)) {
      kd11_psw_set(KD11_PSW_V);
    } else {
      kd11_psw_clr(KD11_PSW_V);
    }
    kd11_operand_write(result_8);
    break;

  default:
    kd11_unhandled_instruction();
    break;
  }
}



static void kd11_fadd(kd11_float_t *a, kd11_float_t *b, bool *zero)
{
  int16_t exp_diff;
  kd11_float_t temp;

  /* Swap around so A always has higher value than B. */
  if ((b->exponent > a->exponent) ||
     ((b->exponent == a->exponent) && (b->mantissa > a->mantissa))) {
    temp = *a;
    *a = *b;
    *b = temp;
  }

  /* Return zero if highest exponent is zero. */
  if (a->exponent == 0) {
    *zero = true;
    return;
  }

  /* Do nothing if lowest exponent is zero. */
  if (b->exponent == 0) {
    return;
  }

  /* Do nothing if the exponent difference is too big. */
  exp_diff = a->exponent - b->exponent;
  if (exp_diff > 030) {
    return;
  }

  /* Align binary points. */
  b->mantissa >>= exp_diff;

  if (a->sign != b->sign) {
    /* Signs differ, do a subtraction. */
    a->mantissa -= b->mantissa;

    /* Return zero if mantissa become zero. */
    if (a->mantissa == 0) {
      *zero = true;
      return;
    }

    /* Normalize, hidden bit should be 1, but ignore extra bits at the end. */
    while (((a->mantissa >> 25) & 1) == 0) {
      a->mantissa <<= 1;
      a->exponent--;
    }

  } else {
    /* Signs equal, do an addition. */
    a->mantissa += b->mantissa;

    /* Check if carry occurred, above the hidden bit. */
    if ((a->mantissa >> 26) & 1) {
      a->mantissa >>= 1;
      a->exponent++;
    }
  }
}



static void kd11_fmul(kd11_float_t *a, kd11_float_t *b, bool *zero)
{
  int i;
  uint32_t result;

  /* Return zero if any exponent is zero. */
  if (a->exponent == 0 || b->exponent == 0) {
    *zero = true;
    return;
  }

  /* Add exponents and handle sign bit. */
  a->exponent += (b->exponent - 0200); /* Bias */
  a->sign ^= b->sign;

  /* Multiplication loop. */
  result = 0;
  for (i = 0; i < 030; i++) {
    if ((a->mantissa >> (i + 2)) & 1) {
      result += b->mantissa;
    }
    result >>= 1;
  }
  a->mantissa = result;

  /* Normalize. */
  if (((a->mantissa >> 25) & 1) == 0) {
    a->mantissa <<= 1;
    a->exponent--;
  }
}



static void kd11_fdiv(kd11_float_t *a, kd11_float_t *b,
  bool *zero, bool *div_by_zero)
{
  int i;
  uint32_t result;

  /* Divisor is zero = Divide by zero. */
  if (b->exponent == 0) {
    *div_by_zero = true;
    return;
  }

  /* Dividend is zero = Return zero. */
  if (a->exponent == 0) {
    *zero = true;
    return;
  }

  /* Subtract exponents and handle sign bit. */
  a->exponent -= b->exponent;
  a->exponent += (0200 + 1); /* Bias */
  a->sign ^= b->sign;

  /* Division loop. */
  result = 0;
  for (i = 26; i > 0; i--) {
    if (a->mantissa == 0) {
      result <<= i;
      break;
    }
    result <<= 1;
    if (a->mantissa >= b->mantissa) {
      a->mantissa -= b->mantissa;
      result |= 1;
    }
    a->mantissa <<= 1;
  }
  a->mantissa = result;

  /* Normalize. */
  if (((a->mantissa >> 25) & 1) == 0) {
    a->mantissa <<= 1;
    a->exponent--;
  }
}



static void kd11_float_unpack(kd11_float_t *arg, uint16_t high, uint16_t low)
{
  arg->sign = high >> 15;
  arg->exponent = (high >> 7) & 0xFF;
  arg->mantissa = (high & 0x7F) << 16;
  arg->mantissa |= low;

  /* Set hidden bit and shift space for extra bits at the low end. */
  arg->mantissa |= 0x800000;
  arg->mantissa <<= 2;
}



static void kd11_float_pack(kd11_float_t *arg, uint16_t *high, uint16_t *low)
{
  *high  =  arg->sign << 15;
  *high |= (arg->exponent & 0xFF) << 7;

  /* Filter out hidden bit and extra bits. */
  *high |= (((arg->mantissa >> 2) & 0x7FFFFF) >> 16) & 0x7F;
  *low   =  ((arg->mantissa >> 2) & 0x7FFFFF) & 0xFFFF;
}



static void kd11_fis_instruction(void)
{
  uint8_t reg;
  kd11_float_t a;
  kd11_float_t b;
  uint16_t high;
  uint16_t low;
  bool zero;
  bool overflow;
  bool underflow;
  bool div_by_zero;

  reg = kd11_ir & 7;
  kd11_trace_operand_1(KD11_MODE_REG, reg);

  /* Get arguments from the stack. */
  high = unibus_read_16(kd11_reg_get(reg));
  low  = unibus_read_16(kd11_reg_get(reg) + 2);
  kd11_float_unpack(&b, high, low);
  high = unibus_read_16(kd11_reg_get(reg) + 4);
  low  = unibus_read_16(kd11_reg_get(reg) + 6);
  kd11_float_unpack(&a, high, low);

  zero = false;
  overflow = false;
  underflow = false;
  div_by_zero = false;

  /* Determine instruction. */
  switch ((kd11_ir >> 3) & 3) {
  case 0:
    kd11_trace_mnemonic("FADD");
    kd11_fadd(&a, &b, &zero);
    break;

  case 1:
    kd11_trace_mnemonic("FSUB");
    b.sign ^= 1; /* Like add, but just flip the sign bit. */
    kd11_fadd(&a, &b, &zero);
    break;

  case 2:
    kd11_trace_mnemonic("FMUL");
    kd11_fmul(&a, &b, &zero);
    break;

  case 3:
    kd11_trace_mnemonic("FDIV");
    kd11_fdiv(&a, &b, &zero, &div_by_zero);
    break;
  }

  /* Abort if read error occurred earlier. */
  if (unibus_error_occured()) {
    return;
  }

  if (zero) {
    /* Zero out result. */
    a.sign = 0;
    a.exponent = 0;
    a.mantissa = 0;

  } else {
    /* Rounding of result. */
    a.mantissa += 2;

    /* Check if carry occurred after rounding. */
    if ((a.mantissa >> 26) & 1) {
      a.mantissa >>= 1;
      a.exponent++;
    }

    /* Check for overflow. */
    if (a.exponent > 0xFF) {
      overflow = true;
    }

    /* Check for underflow. */
    if (a.exponent <= 0) {
      underflow = true;
    }
  }

  /* Set condition flags and trap in case of error. */
  if (overflow || underflow || div_by_zero) {
    if (underflow || div_by_zero) {
      kd11_psw_set(KD11_PSW_N);
    } else {
      kd11_psw_clr(KD11_PSW_N);
    }
    if (div_by_zero) {
      kd11_psw_set(KD11_PSW_C);
    } else {
      kd11_psw_clr(KD11_PSW_C);
    }
    kd11_psw_clr(KD11_PSW_Z);
    kd11_psw_set(KD11_PSW_V);
    kd11_trap(KD11_VECTOR_FP_ERR);
    return;
  }

  /* Check for stack overflow. */
  if (reg == KD11_REG_SP) {
    kd11_stack_limit_check(kd11_reg_get(reg));
    if (kd11_stack_overflow_red) {
      return;
    }
  }

  /* Set condition flags after successful operation. */
  if (a.sign) {
    kd11_psw_set(KD11_PSW_N);
  } else {
    kd11_psw_clr(KD11_PSW_N);
  }
  if (a.exponent == 0) {
    kd11_psw_set(KD11_PSW_Z);
  } else {
    kd11_psw_clr(KD11_PSW_Z);
  }
  kd11_psw_clr(KD11_PSW_C);
  kd11_psw_clr(KD11_PSW_V);

  /* Save result back to stack and adjust stack pointer. */
  kd11_float_pack(&a, &high, &low);
  unibus_write_16(kd11_reg_get(reg) + 4, high);
  unibus_write_16(kd11_reg_get(reg) + 6, low);
  kd11_reg_set(reg, kd11_reg_get(reg) + 4);
}



static void kd11_reg_and_operand(void)
{
  uint8_t reg;
  uint8_t offset;
  uint16_t result;
  uint32_t result_32;
  bool prev_n;

  reg = (kd11_ir >> 6) & 7;

  switch (kd11_ir >> 9) {
  case 56:
    kd11_trace_mnemonic("MUL");
    kd11_trace_operand_1(kd11_dst_mode, kd11_dst_reg);
    kd11_trace_operand_2(KD11_MODE_REG, reg);
    result_32 = (int16_t)kd11_reg_get(reg) * (int16_t)kd11_dst;
    kd11_flag_neg_16(result_32 >> 16);
    if (result_32 == 0) {
      kd11_psw_set(KD11_PSW_Z);
    } else {
      kd11_psw_clr(KD11_PSW_Z);
    }
    kd11_psw_clr(KD11_PSW_V);
    if ((int32_t)result_32 < -32768 || (int32_t)result_32 > 32767) {
      kd11_psw_set(KD11_PSW_C);
    } else {
      kd11_psw_clr(KD11_PSW_C);
    }
    kd11_reg_set(reg, result_32 >> 16);
    kd11_reg_set(reg | 1, result_32 & 0xFFFF);
    break;

  case 57:
    kd11_trace_mnemonic("DIV");
    kd11_trace_operand_1(kd11_dst_mode, kd11_dst_reg);
    kd11_trace_operand_2(KD11_MODE_REG, reg);
    result_32 = (int32_t)((kd11_reg_get(reg) << 16) | kd11_reg_get(reg | 1));
    if (kd11_dst == 0) {
      kd11_psw_set(KD11_PSW_C);
      kd11_psw_set(KD11_PSW_V);
    } else {
      kd11_psw_clr(KD11_PSW_C);
      kd11_reg_set(reg, (int32_t)result_32 / (int16_t)kd11_dst);
      kd11_reg_set(reg | 1, (int32_t)result_32 % (int16_t)kd11_dst);
      if (((int32_t)result_32 / (int16_t)kd11_dst) > 32767) {
        kd11_psw_set(KD11_PSW_V);
      } else {
        kd11_psw_clr(KD11_PSW_V);
      }
      kd11_flag_neg_16(kd11_reg_get(reg));
      kd11_flag_zero(kd11_reg_get(reg));
    }
    break;

  case 58:
    kd11_trace_mnemonic("ASH");
    kd11_trace_operand_1(kd11_dst_mode, kd11_dst_reg);
    kd11_trace_operand_2(KD11_MODE_REG, reg);
    result = kd11_reg_get(reg);
    prev_n = result >> 15;
    kd11_psw_clr(KD11_PSW_V);
    if (kd11_dst & 0x20) { /* Negative = Right Shift */
      offset = 32 - (kd11_dst & 0x1F);
      while (offset > 0) {
        if (result & 1) {
          kd11_psw_set(KD11_PSW_C);
        } else {
          kd11_psw_clr(KD11_PSW_C);
        }
        result >>= 1;
        result |= (prev_n << 15);
        offset--;
      }
    } else { /* Positive = Left Shift */
      offset = (kd11_dst & 0x1F);
      while (offset > 0) {
        if (result >> 15) {
          kd11_psw_set(KD11_PSW_C);
        } else {
          kd11_psw_clr(KD11_PSW_C);
        }
        result <<= 1;
        if ((result >> 15) ^ prev_n) {
          kd11_psw_set(KD11_PSW_V);
        }
        offset--;
      }
    }
    kd11_flag_neg_16(result);
    kd11_flag_zero(result);
    kd11_reg_set(reg, result);
    break;

  case 59:
    kd11_trace_mnemonic("ASHC");
    kd11_trace_operand_1(kd11_dst_mode, kd11_dst_reg);
    kd11_trace_operand_2(KD11_MODE_REG, reg);
    result_32 = (int32_t)((kd11_reg_get(reg) << 16) | kd11_reg_get(reg | 1));
    prev_n = result_32 >> 31;
    kd11_psw_clr(KD11_PSW_V);
    if (kd11_dst & 0x20) { /* Negative = Right Shift */
      offset = 32 - (kd11_dst & 0x1F);
      while (offset > 0) {
        if (result_32 & 1) {
          kd11_psw_set(KD11_PSW_C);
        } else {
          kd11_psw_clr(KD11_PSW_C);
        }
        result_32 >>= 1;
        result_32 |= (prev_n << 31);
        offset--;
      }
    } else { /* Positive = Left Shift */
      offset = (kd11_dst & 0x1F);
      while (offset > 0) {
        if (result_32 >> 31) {
          kd11_psw_set(KD11_PSW_C);
        } else {
          kd11_psw_clr(KD11_PSW_C);
        }
        result_32 <<= 1;
        if ((result_32 >> 31) ^ prev_n) {
          kd11_psw_set(KD11_PSW_V);
        }
        offset--;
      }
    }
    kd11_flag_neg_16(result_32 >> 16);
    if (result_32 == 0) {
      kd11_psw_set(KD11_PSW_Z);
    } else {
      kd11_psw_clr(KD11_PSW_Z);
    }
    kd11_reg_set(reg, result_32 >> 16);
    kd11_reg_set(reg | 1, result_32 & 0xFFFF);
    break;

  case 60:
    kd11_trace_mnemonic("XOR");
    kd11_trace_operand_1(KD11_MODE_REG, reg);
    result = kd11_dst;
    result ^= kd11_reg_get(reg);
    kd11_flag_neg_16(result);
    kd11_flag_zero(result);
    kd11_psw_clr(KD11_PSW_V);
    kd11_operand_write(result);
    if (kd11_psw_get(KD11_PSW_T) == 1) {
      kd11_psw_clr(KD11_PSW_T); /* To pass MAINDEC-11-DCKBC-B-PB test. */
    }
    break;

  case 61:
    if (((kd11_ir >> 5) & 0xF) == 0) {
      kd11_fis_instruction();
    } else {
      kd11_unhandled_instruction();
    }
    break;

  case 63:
    kd11_trace_mnemonic("SOB");
    kd11_trace_operand_1(KD11_MODE_REG, reg);
    offset = kd11_ir & 0x3F;
    kd11_trace_offset(-offset); /* Negative offset. */
    result = kd11_reg_get(reg);
    result--;
    kd11_reg_set(reg, result);
    if (result != 0) {
      kd11_pc -= (offset * 2);
    }
    break;

  default:
    kd11_unhandled_instruction();
    break;
  }
}



static void kd11_jmp(void)
{
  kd11_trace_mnemonic("JMP");

  if (kd11_dst_mode == KD11_MODE_REG) {
    kd11_trap(KD11_VECTOR_BUS_ERR);
  } else {
    kd11_pc = kd11_bar;
  }
}



static void kd11_jsr(void)
{
  uint16_t value;

  kd11_trace_mnemonic("JSR");
  kd11_trace_operand_1(KD11_MODE_REG, kd11_src_reg);

  if (kd11_dst_mode == KD11_MODE_REG) {
    kd11_trap(KD11_VECTOR_BUS_ERR);
  } else {
    value = kd11_reg_get(kd11_src_reg);
    if (kd11_src_reg == KD11_REG_SP) {
      value -= 2; /* Compensate for special case with SP. */
    }
    kd11_stack_push(value);
    kd11_reg_set(kd11_src_reg, kd11_pc);
    kd11_pc = kd11_bar;
  }
}



static void kd11_rti(void)
{
  kd11_trace_mnemonic("RTI");

  kd11_pc = kd11_stack_pop();
  kd11_psw = kd11_stack_pop();

  kd11_t_flag_delay = true;
}



static void kd11_rtt(void)
{
  kd11_trace_mnemonic("RTT");

  kd11_pc = kd11_stack_pop();
  kd11_psw = kd11_stack_pop();

  kd11_t_flag_delay = false;
}



static void kd11_rts(void)
{
  kd11_trace_mnemonic("RTS");
  kd11_trace_operand_1(KD11_MODE_REG, kd11_ir02_00);

  kd11_pc = kd11_reg_get(kd11_ir02_00);
  kd11_reg_set(kd11_ir02_00, kd11_stack_pop());
}



static void kd11_trap(uint16_t vector)
{
  kd11_trace_trap(vector);

  kd11_stack_push(kd11_psw);
  kd11_psw = unibus_read_16(vector + 2);
  kd11_stack_push(kd11_pc);
  kd11_pc = unibus_read_16(vector);
}



static void kd11_fetch_instruction(void)
{
  kd11_ir = kd11_fetch();

  /* Decode instruction type, which determines next state: */
  switch (kd11_ir14_12) {
  case 0:
    switch (kd11_ir11_09) {
    case 0:
      if ((kd11_ir15 == 0) && (kd11_ir08 == 0)) {
        if (kd11_ir07_06 == 1) {
          kd11_state = KD11_STATE_DESTINATION; /* JMP */
        } else if (kd11_ir07_06 == 3) {
          kd11_state = KD11_STATE_DESTINATION; /* SWAB */
        } else {
          kd11_state = KD11_STATE_EXECUTE; /* PC and PS Change */
        }
      } else {
        kd11_state = KD11_STATE_EXECUTE; /* PC and PS Change */
      }
      break;

    case 1:
    case 2:
    case 3:
      kd11_state = KD11_STATE_EXECUTE; /* PC and PS Change */
      break;

    case 4:
      if (kd11_ir15 == 0) {
        kd11_state = KD11_STATE_DESTINATION; /* JSR */
      } else {
        kd11_state = KD11_STATE_EXECUTE; /* PC and PS Change */
      }
      break;

    case 5:
    case 6:
    case 7:
      if ((kd11_ir11_09 == 6) && (kd11_ir08 == 1) && (kd11_ir07_06 == 0)) {
        kd11_state = KD11_STATE_EXECUTE; /* MARK */
      } else {
        kd11_state = KD11_STATE_DESTINATION; /* Single Operand */
      }
      break;
    }
    break;

  case 1:
  case 2:
  case 3:
  case 4:
  case 5:
  case 6:
    kd11_state = KD11_STATE_SOURCE; /* Double Operand */
    break;

  case 7:
    if (kd11_ir11_09 >= 5) {
      kd11_state = KD11_STATE_EXECUTE; /* FIS Instructions + SOB */
    } else {
      kd11_state = KD11_STATE_DESTINATION; /* Register and Operand */
    }
    break;
  }
}



static void kd11_execute_instruction(void)
{
  int8_t offset;

  /* Instruction decoding follows "Figure 1-10" as seen in the 
     "KD11-C Processor Manual (PDP-11/70)" on page II-1-34. */

  switch (kd11_ir15) {
  case 0:
    switch (kd11_ir14_12) {
    case 0:
      switch (kd11_ir11_09) {
      case 0:
        switch (kd11_ir08) {
        case 0:
          switch (kd11_ir07_06) {
          case 0:
            switch (kd11_ir05_03) {
            case 0:
              switch (kd11_ir02_00) {
              case 0:
                kd11_trace_mnemonic("HALT");
                panic("HALT\n");
                break;

              case 1:
                kd11_trace_mnemonic("WAIT");
                panic("WAIT not implemented!\n");
                break;

              case 2:
                kd11_rti();
                break;

              case 3:
                kd11_trace_mnemonic("BPT");
                kd11_trap(KD11_VECTOR_BPT);
                break;

              case 4:
                kd11_trace_mnemonic("IOT");
                kd11_trap(KD11_VECTOR_IOT);
                break;

              case 5:
                kd11_trace_mnemonic("RESET");
                unibus_reset();
                kd11_slr = 0;
                break;

              case 6:
                kd11_rtt();
                break;

              case 7:
                kd11_unhandled_instruction();
                break;
              }
              break;

            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
              kd11_unhandled_instruction();
              break;
            }
            break;

          case 1:
            kd11_jmp();
            break;

          case 2:
            switch (kd11_ir05_03) {
            case 0:
              kd11_rts();
              break;

            case 1:
            case 2:
            case 3:
              kd11_unhandled_instruction();
              break;

            case 4:
              switch (kd11_ir02_00) {
              case 0:
                kd11_trace_mnemonic("NOP");
                break;

              case 1:
                kd11_trace_mnemonic("CLC");
                kd11_psw_clr(KD11_PSW_C);
                break;

              case 2:
                kd11_trace_mnemonic("CLV");
                kd11_psw_clr(KD11_PSW_V);
                break;

              case 3:
                kd11_trace_mnemonic("C43");
                kd11_psw_clr(KD11_PSW_C);
                kd11_psw_clr(KD11_PSW_V);
                break;

              case 4:
                kd11_trace_mnemonic("CLZ");
                kd11_psw_clr(KD11_PSW_Z);
                break;

              case 5:
                kd11_trace_mnemonic("C45");
                kd11_psw_clr(KD11_PSW_C);
                kd11_psw_clr(KD11_PSW_Z);
                break;

              case 6:
                kd11_trace_mnemonic("C46");
                kd11_psw_clr(KD11_PSW_V);
                kd11_psw_clr(KD11_PSW_Z);
                break;

              case 7:
                kd11_trace_mnemonic("C47");
                kd11_psw_clr(KD11_PSW_C);
                kd11_psw_clr(KD11_PSW_V);
                kd11_psw_clr(KD11_PSW_Z);
                break;
              }
              break;

            case 5:
              switch (kd11_ir02_00) {
              case 0:
                kd11_trace_mnemonic("CLN");
                kd11_psw_clr(KD11_PSW_N);
                break;

              case 1:
                kd11_trace_mnemonic("C51");
                kd11_psw_clr(KD11_PSW_C);
                kd11_psw_clr(KD11_PSW_N);
                break;

              case 2:
                kd11_trace_mnemonic("C52");
                kd11_psw_clr(KD11_PSW_V);
                kd11_psw_clr(KD11_PSW_N);
                break;

              case 3:
                kd11_trace_mnemonic("C53");
                kd11_psw_clr(KD11_PSW_C);
                kd11_psw_clr(KD11_PSW_V);
                kd11_psw_clr(KD11_PSW_N);
                break;

              case 4:
                kd11_trace_mnemonic("C54");
                kd11_psw_clr(KD11_PSW_Z);
                kd11_psw_clr(KD11_PSW_N);
                break;

              case 5:
                kd11_trace_mnemonic("C55");
                kd11_psw_clr(KD11_PSW_C);
                kd11_psw_clr(KD11_PSW_Z);
                kd11_psw_clr(KD11_PSW_N);
                break;

              case 6:
                kd11_trace_mnemonic("C56");
                kd11_psw_clr(KD11_PSW_V);
                kd11_psw_clr(KD11_PSW_Z);
                kd11_psw_clr(KD11_PSW_N);
                break;

              case 7:
                kd11_trace_mnemonic("CCC");
                kd11_psw_clr(KD11_PSW_C);
                kd11_psw_clr(KD11_PSW_V);
                kd11_psw_clr(KD11_PSW_Z);
                kd11_psw_clr(KD11_PSW_N);
                break;
              }
              break;

            case 6:
              switch (kd11_ir02_00) {
              case 0:
                kd11_trace_mnemonic("NOP");
                break;

              case 1:
                kd11_trace_mnemonic("SEC");
                kd11_psw_set(KD11_PSW_C);
                break;

              case 2:
                kd11_trace_mnemonic("SEV");
                kd11_psw_set(KD11_PSW_V);
                break;

              case 3:
                kd11_trace_mnemonic("S63");
                kd11_psw_set(KD11_PSW_C);
                kd11_psw_set(KD11_PSW_V);
                break;

              case 4:
                kd11_trace_mnemonic("SEZ");
                kd11_psw_set(KD11_PSW_Z);
                break;

              case 5:
                kd11_trace_mnemonic("S65");
                kd11_psw_set(KD11_PSW_C);
                kd11_psw_set(KD11_PSW_Z);
                break;

              case 6:
                kd11_trace_mnemonic("S66");
                kd11_psw_set(KD11_PSW_V);
                kd11_psw_set(KD11_PSW_Z);
                break;

              case 7:
                kd11_trace_mnemonic("S67");
                kd11_psw_set(KD11_PSW_C);
                kd11_psw_set(KD11_PSW_V);
                kd11_psw_set(KD11_PSW_Z);
                break;
              }
              break;

            case 7:
              switch (kd11_ir02_00) {
              case 0:
                kd11_trace_mnemonic("SEN");
                kd11_psw_set(KD11_PSW_N);
                break;

              case 1:
                kd11_trace_mnemonic("S71");
                kd11_psw_set(KD11_PSW_C);
                kd11_psw_set(KD11_PSW_N);
                break;

              case 2:
                kd11_trace_mnemonic("S72");
                kd11_psw_set(KD11_PSW_V);
                kd11_psw_set(KD11_PSW_N);
                break;

              case 3:
                kd11_trace_mnemonic("S73");
                kd11_psw_set(KD11_PSW_C);
                kd11_psw_set(KD11_PSW_V);
                kd11_psw_set(KD11_PSW_N);
                break;

              case 4:
                kd11_trace_mnemonic("S74");
                kd11_psw_set(KD11_PSW_Z);
                kd11_psw_set(KD11_PSW_N);
                break;

              case 5:
                kd11_trace_mnemonic("S75");
                kd11_psw_set(KD11_PSW_C);
                kd11_psw_set(KD11_PSW_Z);
                kd11_psw_set(KD11_PSW_N);
                break;

              case 6:
                kd11_trace_mnemonic("S76");
                kd11_psw_set(KD11_PSW_V);
                kd11_psw_set(KD11_PSW_Z);
                kd11_psw_set(KD11_PSW_N);
                break;

              case 7:
                kd11_trace_mnemonic("SCC");
                kd11_psw_set(KD11_PSW_C);
                kd11_psw_set(KD11_PSW_V);
                kd11_psw_set(KD11_PSW_Z);
                kd11_psw_set(KD11_PSW_N);
                break;
              }
              break;
            }
            break;

          case 3:
            kd11_single_operand();
            break;
          }
          break;

        case 1:
          kd11_trace_mnemonic("BR");
          offset = (kd11_ir & 0xFF);
          kd11_trace_offset(offset);
          kd11_pc += (offset * 2);
          break;
        }
        break;

      case 1:
        switch (kd11_ir08) {
        case 0:
          kd11_trace_mnemonic("BNE");
          offset = (kd11_ir & 0xFF);
          kd11_trace_offset(offset);
          if (kd11_psw_get(KD11_PSW_Z) == 0) {
            kd11_pc += (offset * 2);
          }
          break;

        case 1:
          kd11_trace_mnemonic("BEQ");
          offset = (kd11_ir & 0xFF);
          kd11_trace_offset(offset);
          if (kd11_psw_get(KD11_PSW_Z) == 1) {
            kd11_pc += (offset * 2);
          }
          break;
        }
        break;

      case 2:
        switch (kd11_ir08) {
        case 0:
          kd11_trace_mnemonic("BGE");
          offset = (kd11_ir & 0xFF);
          kd11_trace_offset(offset);
          if ((kd11_psw_get(KD11_PSW_N) ^ kd11_psw_get(KD11_PSW_V)) == 0) {
            kd11_pc += (offset * 2);
          }
          break;

        case 1:
          kd11_trace_mnemonic("BLT");
          offset = (kd11_ir & 0xFF);
          kd11_trace_offset(offset);
          if ((kd11_psw_get(KD11_PSW_N) ^ kd11_psw_get(KD11_PSW_V)) == 1) {
            kd11_pc += (offset * 2);
          }
          break;
        }
        break;

      case 3:
        switch (kd11_ir08) {
        case 0:
          kd11_trace_mnemonic("BGT");
          offset = (kd11_ir & 0xFF);
          kd11_trace_offset(offset);
          if ((kd11_psw_get(KD11_PSW_Z) ||
             ((kd11_psw_get(KD11_PSW_N) ^ kd11_psw_get(KD11_PSW_V)))) == 0) {
            kd11_pc += (offset * 2);
          }
          break;

        case 1:
          kd11_trace_mnemonic("BLE");
          offset = (kd11_ir & 0xFF);
          kd11_trace_offset(offset);
          if ((kd11_psw_get(KD11_PSW_Z) ||
             ((kd11_psw_get(KD11_PSW_N) ^ kd11_psw_get(KD11_PSW_V)))) == 1) {
            kd11_pc += (offset * 2);
          }
          break;
        }
        break;

      case 4:
        kd11_jsr();
        break;

      case 5:
      case 6:
        kd11_single_operand();
        break;

      case 7:
        kd11_unhandled_instruction();
        break;
      }
      break;

    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
      kd11_double_operand();
      break;

    case 7:
      kd11_reg_and_operand();
      break;
    }
    break;

  case 1:
    switch (kd11_ir14_12) {
    case 0:
      switch (kd11_ir11_09) {
      case 0:
        switch (kd11_ir08) {
        case 0:
          kd11_trace_mnemonic("BPL");
          offset = (kd11_ir & 0xFF);
          kd11_trace_offset(offset);
          if (kd11_psw_get(KD11_PSW_N) == 0) {
            kd11_pc += (offset * 2);
          }
          break;

        case 1:
          kd11_trace_mnemonic("BMI");
          offset = (kd11_ir & 0xFF);
          kd11_trace_offset(offset);
          if (kd11_psw_get(KD11_PSW_N) == 1) {
            kd11_pc += (offset * 2);
          }
          break;
        }
        break;

      case 1:
        switch (kd11_ir08) {
        case 0:
          kd11_trace_mnemonic("BHI");
          offset = (kd11_ir & 0xFF);
          kd11_trace_offset(offset);
          if ((kd11_psw_get(KD11_PSW_C) == 0) &&
              (kd11_psw_get(KD11_PSW_Z) == 0)) {
            kd11_pc += (offset * 2);
          }
          break;

        case 1:
          kd11_trace_mnemonic("BLOS");
          offset = (kd11_ir & 0xFF);
          kd11_trace_offset(offset);
          if ((kd11_psw_get(KD11_PSW_C) ||
               kd11_psw_get(KD11_PSW_Z)) == 1) {
            kd11_pc += (offset * 2);
          }
          break;
        }
        break;

      case 2:
        switch (kd11_ir08) {
        case 0:
          kd11_trace_mnemonic("BVC");
          offset = (kd11_ir & 0xFF);
          kd11_trace_offset(offset);
          if (kd11_psw_get(KD11_PSW_V) == 0) {
            kd11_pc += (offset * 2);
          }
          break;

        case 1:
          kd11_trace_mnemonic("BVS");
          offset = (kd11_ir & 0xFF);
          kd11_trace_offset(offset);
          if (kd11_psw_get(KD11_PSW_V) == 1) {
            kd11_pc += (offset * 2);
          }
          break;
        }
        break;

      case 3:
        switch (kd11_ir08) {
        case 0:
          kd11_trace_mnemonic("BHIS"); /* BCC */
          offset = (kd11_ir & 0xFF);
          kd11_trace_offset(offset);
          if (kd11_psw_get(KD11_PSW_C) == 0) {
            kd11_pc += (offset * 2);
          }
          break;

        case 1:
          kd11_trace_mnemonic("BLO"); /* BCS */
          offset = (kd11_ir & 0xFF);
          kd11_trace_offset(offset);
          if (kd11_psw_get(KD11_PSW_C) == 1) {
            kd11_pc += (offset * 2);
          }
          break;
        }
        break;

      case 4:
        switch (kd11_ir08) {
        case 0:
          kd11_trace_mnemonic("EMT");
          kd11_trap(KD11_VECTOR_EMT);
          break;

        case 1:
          kd11_trace_mnemonic("TRAP");
          kd11_trap(KD11_VECTOR_TRAP);
          break;
        }
        break;

      case 5:
      case 6:
        kd11_single_operand();
        break;

      case 7:
        kd11_unhandled_instruction();
        break;
      }
      break;

    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
      kd11_double_operand();
      break;

    case 7:
      switch (kd11_ir11_09) {
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
        kd11_unhandled_instruction();
        break;
      }
      break;
    }
    break;
  }
}



static void kd11_service(void)
{
  uint16_t vector;

  if (unibus_error_occured()) {
    kd11_trap(KD11_VECTOR_BUS_ERR);
    unibus_error_reset();
  }

  vector = unibus_irq_get(kd11_psw_level);
  if (vector > 0) {
    kd11_trap(vector);
  }

  if (kd11_psw_get(KD11_PSW_T)) {
    if (kd11_t_flag_delay == false) {
      kd11_t_flag_delay = true;
    } else {
      kd11_trace_trap_info("PSW T Set");
      kd11_trap(KD11_VECTOR_BPT);
    }
  } else {
    kd11_t_flag_delay = false;
  }

  if (kd11_stack_overflow) {
    kd11_trap(KD11_VECTOR_BUS_ERR);
    kd11_trace_trap_info("Stack Overflow");
    kd11_stack_overflow = false;
    kd11_stack_overflow_red = false;
  }
}



void kd11_execute(void)
{
  while (kd11_state != KD11_STATE_DONE) {
    switch (kd11_state) {
    case KD11_STATE_FETCH:
      kd11_trace_start(kd11_pc, kd11_reg_get(KD11_REG_SP), kd11_psw);
      kd11_trace_reg(kd11_reg);
      kd11_fetch_instruction();
      break;

    case KD11_STATE_SOURCE:
      kd11_trace_operand_1(kd11_src_mode, kd11_src_reg);
      kd11_src = kd11_operand_read(kd11_src_mode, kd11_src_reg);
      if (unibus_error_occured()) {
        kd11_state = KD11_STATE_SERVICE;
      } else {
        kd11_state = KD11_STATE_DESTINATION;
      }
      break;

    case KD11_STATE_DESTINATION:
      kd11_trace_operand_2(kd11_dst_mode, kd11_dst_reg);
      kd11_dst = kd11_operand_read(kd11_dst_mode, kd11_dst_reg);
      if (unibus_error_occured()) {
        kd11_state = KD11_STATE_SERVICE;
      } else {
        kd11_state = KD11_STATE_EXECUTE;
      }
      break;

    case KD11_STATE_EXECUTE:
      kd11_execute_instruction();
      kd11_state = KD11_STATE_SERVICE;
      break;

    case KD11_STATE_SERVICE:
      kd11_service();
      kd11_trace_end();
      kd11_state = KD11_STATE_DONE;
      break;

    case KD11_STATE_DONE:
      break;
    }
  }

  kd11_state = KD11_STATE_FETCH;
}



static uint16_t kd11_slr_read(uint32_t unibus_address)
{
  (void)unibus_address;
  return kd11_slr;
}



static void kd11_slr_write(uint32_t unibus_address, uint16_t value)
{
  (void)unibus_address;
  kd11_slr = value & 0xFF00;
}



static uint16_t kd11_psw_read(uint32_t unibus_address)
{
  (void)unibus_address;
  return kd11_psw;
}



static void kd11_psw_write(uint32_t unibus_address, uint16_t value)
{
  (void)unibus_address;
  kd11_psw = value;
}



void kd11_init(void)
{
  int i;

  kd11_state = KD11_STATE_FETCH;
  kd11_pc = 0;
  kd11_ir = 0;
  kd11_bar = 0;
  kd11_src = 0;
  kd11_dst = 0;
  kd11_psw = 0;
  kd11_slr = 0;
 
  for (i = 0; i < 6; i++) {
    kd11_reg[i] = 0;
  }

  unibus_read_hook_register(KD11_ADDRESS_PSW, kd11_psw_read);
  unibus_read_hook_register(KD11_ADDRESS_SLR, kd11_slr_read);
  unibus_write_hook_register(KD11_ADDRESS_PSW, kd11_psw_write);
  unibus_write_hook_register(KD11_ADDRESS_SLR, kd11_slr_write);
}



