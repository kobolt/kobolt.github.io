#ifndef _KD11_H
#define _KD11_H

#include <stdint.h>

#define KD11_ADDRESS_SLR 0777774 /* Stack Limit Register */
#define KD11_ADDRESS_PSW 0777776 /* Processor Status Word */

/* Processor Status Word Bits: */
#define KD11_PSW_C 0 /* Carry */
#define KD11_PSW_V 1 /* Overflow */
#define KD11_PSW_Z 2 /* Zero */
#define KD11_PSW_N 3 /* Negative */
#define KD11_PSW_T 4 /* Trap */

/* Register Index: */
#define KD11_REG_0  0
#define KD11_REG_1  1
#define KD11_REG_2  2
#define KD11_REG_3  3
#define KD11_REG_4  4
#define KD11_REG_5  5
#define KD11_REG_SP 6
#define KD11_REG_PC 7

/* Addressing Modes: */
#define KD11_MODE_REG          0
#define KD11_MODE_REG_DEF      1
#define KD11_MODE_AUTO_INC     2
#define KD11_MODE_AUTO_INC_DEF 3
#define KD11_MODE_AUTO_DEC     4
#define KD11_MODE_AUTO_DEC_DEF 5
#define KD11_MODE_INDEX        6
#define KD11_MODE_INDEX_DEF    7
#define KD11_MODE_PC_IMM       2
#define KD11_MODE_PC_ABS       3
#define KD11_MODE_PC_REL       6
#define KD11_MODE_PC_REL_DEF   7
#define KD11_MODE_VALUE        0xFF /* Special mode used only in trace. */

typedef enum {
  KD11_STATE_FETCH,
  KD11_STATE_SOURCE,
  KD11_STATE_DESTINATION,
  KD11_STATE_EXECUTE,
  KD11_STATE_SERVICE,
  KD11_STATE_DONE,
} kd11_state_t;

void kd11_init(void);
void kd11_execute(void);
uint16_t kd11_reg_get(int reg);
void kd11_reg_set(int reg, uint16_t value);

#endif /* _KD11_H */
