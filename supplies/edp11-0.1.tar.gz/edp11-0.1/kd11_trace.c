#include "kd11_trace.h"
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>

#include "kd11.h"

#define KD11_TRACE_BUFFER_SIZE 4096

#define KD11_TRACE_MC_MAX 3
#define KD11_TRACE_MNEMONIC_MAX 8
#define KD11_TRACE_TRAP_INFO_MAX 32
#define KD11_TRACE_PRINT_MAX 40

typedef struct kd11_trace_s {
  uint16_t reg[6];
  bool reg_used;
  uint16_t pc;
  uint16_t sp;
  uint16_t psw;
  uint16_t mc[KD11_TRACE_MC_MAX];
  int mc_n;
  char mnemonic[KD11_TRACE_MNEMONIC_MAX];
  uint8_t operand_mode[2];
  uint8_t operand_reg[2];
  bool operand_used[2];
  int8_t offset;
  bool offset_used;
  uint16_t vector;
  bool vector_used;
  char trap_info[KD11_TRACE_TRAP_INFO_MAX];
} kd11_trace_t;



static kd11_trace_t trace_buffer[KD11_TRACE_BUFFER_SIZE];
static int trace_buffer_n = 0;



void kd11_trace_start(uint16_t pc, uint16_t sp, uint16_t psw)
{
  memset(&trace_buffer[trace_buffer_n], 0, sizeof(kd11_trace_t));
  trace_buffer[trace_buffer_n].pc = pc;
  trace_buffer[trace_buffer_n].sp = sp;
  trace_buffer[trace_buffer_n].psw = psw;
}



void kd11_trace_reg(uint16_t reg[])
{
  int i;

  for (i = 0; i < 6; i++) {
    trace_buffer[trace_buffer_n].reg[i] = reg[i];
  }
  trace_buffer[trace_buffer_n].reg_used = true;
}



void kd11_trace_mc(uint16_t mc)
{
  if (trace_buffer[trace_buffer_n].mc_n >= KD11_TRACE_MC_MAX) {
    trace_buffer[trace_buffer_n].mc_n = 0;
  }
  trace_buffer[trace_buffer_n].mc[trace_buffer[trace_buffer_n].mc_n] = mc;
  trace_buffer[trace_buffer_n].mc_n++;
}



void kd11_trace_mnemonic(const char *s)
{
  strncpy(trace_buffer[trace_buffer_n].mnemonic, s,
    KD11_TRACE_MNEMONIC_MAX);
}



void kd11_trace_operand_1(uint8_t mode, uint8_t reg)
{
  trace_buffer[trace_buffer_n].operand_mode[0] = mode;
  trace_buffer[trace_buffer_n].operand_reg[0] = reg;
  trace_buffer[trace_buffer_n].operand_used[0] = true;
}



void kd11_trace_operand_2(uint8_t mode, uint8_t reg)
{
  trace_buffer[trace_buffer_n].operand_mode[1] = mode;
  trace_buffer[trace_buffer_n].operand_reg[1] = reg;
  trace_buffer[trace_buffer_n].operand_used[1] = true;
}



void kd11_trace_offset(int8_t offset)
{
  trace_buffer[trace_buffer_n].offset = offset;
  trace_buffer[trace_buffer_n].offset_used = true;
}



void kd11_trace_trap(uint16_t vector)
{
  trace_buffer[trace_buffer_n].vector = vector;
  trace_buffer[trace_buffer_n].vector_used = true;
}



void kd11_trace_trap_info(const char *format, ...)
{
  va_list args;

  if (trace_buffer[trace_buffer_n].trap_info[0] != '\0') {
    return; /* Do not overwrite. */
  }

  va_start(args, format);
  vsnprintf(trace_buffer[trace_buffer_n].trap_info,
    KD11_TRACE_TRAP_INFO_MAX, format, args);
  va_end(args);
}



void kd11_trace_end(void)
{
  trace_buffer_n++;
  if (trace_buffer_n >= KD11_TRACE_BUFFER_SIZE) {
    trace_buffer_n = 0;
  }
}



static size_t kd11_trace_mode(char *buffer, size_t size, size_t n,
  uint8_t mode, uint8_t reg, uint16_t follow, uint16_t next_pc)
{
  char r1;
  char r2;

  if (reg == KD11_REG_PC) {
    r1 = 'P';
    r2 = 'C';
  } else if (reg == KD11_REG_SP) {
    r1 = 'S';
    r2 = 'P';
  } else {
    r1 = 'R';
    r2 = '0' + reg;
  }

  if (reg == KD11_REG_PC) {
    switch (mode) {
    case KD11_MODE_PC_IMM:
      return snprintf(&buffer[n], size - n, "#%o", follow);
    case KD11_MODE_PC_ABS:
      return snprintf(&buffer[n], size - n, "@#%o", follow);
    case KD11_MODE_PC_REL:
      return snprintf(&buffer[n], size - n, "%06o",
        (uint16_t)(next_pc + follow));
    case KD11_MODE_PC_REL_DEF:
      return snprintf(&buffer[n], size - n, "@%06o",
        (uint16_t)(next_pc + follow));
    default:
      break;
    }
  }

  switch (mode) {
  case KD11_MODE_REG:
    return snprintf(&buffer[n], size - n, "%c%c", r1, r2);
  case KD11_MODE_REG_DEF:
    return snprintf(&buffer[n], size - n, "(%c%c)", r1, r2);
  case KD11_MODE_AUTO_INC:
    return snprintf(&buffer[n], size - n, "(%c%c)+", r1, r2);
  case KD11_MODE_AUTO_INC_DEF:
    return snprintf(&buffer[n], size - n, "@(%c%c)+", r1, r2);
  case KD11_MODE_AUTO_DEC:
    return snprintf(&buffer[n], size - n, "-(%c%c)", r1, r2);
  case KD11_MODE_AUTO_DEC_DEF:
    return snprintf(&buffer[n], size - n, "@-(%c%c)", r1, r2);
  case KD11_MODE_INDEX:
    return snprintf(&buffer[n], size - n, "%o(%c%c)", follow, r1, r2);
  case KD11_MODE_INDEX_DEF:
    return snprintf(&buffer[n], size - n, "@%o(%c%c)", follow, r1, r2);
  case KD11_MODE_VALUE: /* This mode does not exist, used only for trace. */
    return snprintf(&buffer[n], size - n, "%d", reg);
  }

  return 0;
}



static void kd11_trace_print(FILE *fh, kd11_trace_t *trace, bool extended)
{
  int i;
  size_t n;
  char buffer[KD11_TRACE_PRINT_MAX];
  uint16_t next_pc;

  next_pc = trace->pc + (trace->mc_n * 2);

  fprintf(fh, "%06o: ", trace->pc);

  for (i = 0; i < trace->mc_n; i++) {
    fprintf(fh, "%06o ", trace->mc[i]);
  }
  for (; i < KD11_TRACE_MC_MAX; i++) {
    fprintf(fh, "       ");
  }
  fprintf(fh, " ");

  n = 0;
  if (trace->mnemonic[0] != '\0') {
    n += snprintf(&buffer[n], KD11_TRACE_PRINT_MAX - n, "%-4s", trace->mnemonic);
  } else {
    n += snprintf(&buffer[n], KD11_TRACE_PRINT_MAX - n, "--- ");
  }

  if (trace->operand_used[0]) {
    n += snprintf(&buffer[n], KD11_TRACE_PRINT_MAX - n, " ");
    if (trace->mc_n == 3) {
      n += kd11_trace_mode(buffer, KD11_TRACE_PRINT_MAX, n,
        trace->operand_mode[0], trace->operand_reg[0],
        trace->mc[1], next_pc - 2);
    } else {
      n += kd11_trace_mode(buffer, KD11_TRACE_PRINT_MAX, n,
        trace->operand_mode[0], trace->operand_reg[0],
        trace->mc[1], next_pc);
    }
  }
  if (trace->offset_used) {
    if (trace->operand_used[0]) {
      n += snprintf(&buffer[n], KD11_TRACE_PRINT_MAX - n, ",");
    } else {
      n += snprintf(&buffer[n], KD11_TRACE_PRINT_MAX - n, " ");
    }
    n += snprintf(&buffer[n], KD11_TRACE_PRINT_MAX - n, "%06o",
      (uint16_t)(next_pc + (trace->offset * 2)));
  }
  if (trace->operand_used[1]) {
    if (trace->operand_used[0]) {
      n += snprintf(&buffer[n], KD11_TRACE_PRINT_MAX - n, ",");
    } else {
      n += snprintf(&buffer[n], KD11_TRACE_PRINT_MAX - n, " ");
    }
    if (trace->mc_n == 3) {
      n += kd11_trace_mode(buffer, KD11_TRACE_PRINT_MAX, n,
        trace->operand_mode[1], trace->operand_reg[1], trace->mc[2], next_pc);
    } else {
      n += kd11_trace_mode(buffer, KD11_TRACE_PRINT_MAX, n,
        trace->operand_mode[1], trace->operand_reg[1], trace->mc[1], next_pc);
    }
  }
  fprintf(fh, "%s", buffer);
  for (i = n; i < 28; i++) {
    fprintf(fh, " ");
  }

  fprintf(fh, "SP=%06o ", trace->sp);

  fprintf(fh, "PS=");
  fprintf(fh, "%d", ((trace->psw >> 5) & 7));
  fprintf(fh, "%c", ((trace->psw >> KD11_PSW_T) & 1) ? 'T' : '-');
  fprintf(fh, "%c", ((trace->psw >> KD11_PSW_N) & 1) ? 'N' : '-');
  fprintf(fh, "%c", ((trace->psw >> KD11_PSW_Z) & 1) ? 'Z' : '-');
  fprintf(fh, "%c", ((trace->psw >> KD11_PSW_V) & 1) ? 'V' : '-');
  fprintf(fh, "%c", ((trace->psw >> KD11_PSW_C) & 1) ? 'C' : '-');

  if (extended) {
    if (trace->reg_used) {
      fprintf(fh, " R0=%06o", trace->reg[0]);
      fprintf(fh, " R1=%06o", trace->reg[1]);
      fprintf(fh, " R2=%06o", trace->reg[2]);
      fprintf(fh, " R3=%06o", trace->reg[3]);
      fprintf(fh, " R4=%06o", trace->reg[4]);
      fprintf(fh, " R5=%06o", trace->reg[5]);
    }
  }

  fprintf(fh, "\n");

  if (trace->vector_used) {
    fprintf(fh, "%06o: Trap!", trace->vector);
    if (trace->trap_info[0] != '\0') {
      fprintf(fh, " %s", trace->trap_info);
    }
    fprintf(fh, "\n");
  }
}



void kd11_trace_init(void)
{
  int i;

  for (i = 0; i < KD11_TRACE_BUFFER_SIZE; i++) {
    memset(&trace_buffer[i], 0, sizeof(kd11_trace_t));
  }
  trace_buffer_n = 0;
}



void kd11_trace_dump(FILE *fh, bool extended)
{
  int i;

  for (i = trace_buffer_n; i < KD11_TRACE_BUFFER_SIZE; i++) {
    if (trace_buffer[i].mc_n > 0) {
      kd11_trace_print(fh, &trace_buffer[i], extended);
    }
  }
  for (i = 0; i < trace_buffer_n; i++) {
    if (trace_buffer[i].mc_n > 0) {
      kd11_trace_print(fh, &trace_buffer[i], extended);
    }
  }
}



