#ifndef _LA36_H
#define _LA36_H

#include <stdbool.h>
#include <stdint.h>

#define LA36_OPTION_NO_TIMEOUT     0x1
#define LA36_OPTION_EXIT_ON_BELL   0x2
#define LA36_OPTION_AUTO_LF_TO_CR  0x4
#define LA36_OPTION_AUTO_UPPERCASE 0x8

void la36_send(uint8_t byte);
uint8_t la36_recv(void);
bool la36_poll(void);
void la36_pause(void);
void la36_resume(void);
void la36_init(uint32_t option);

#endif /* _LA36_H */
