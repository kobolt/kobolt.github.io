#include "ky11.h"
#include <stdint.h>

#include "unibus.h"

uint32_t ky11_switch_register;



static uint16_t ky11_switch_read(uint32_t unibus_address)
{
  (void)unibus_address;
  return ky11_switch_register & 0xFFFF;
}



static void ky11_switch_write(uint32_t unibus_address, uint16_t value)
{
  (void)unibus_address;
  (void)value;
  /* Physical switches cannot be writte to over unibus. */
}



uint32_t ky11_switch_get(void)
{
  return ky11_switch_register;
}



void ky11_switch_set(uint32_t value)
{
  ky11_switch_register = value;
}



void ky11_init(void)
{
  ky11_switch_register = 0;

  unibus_read_hook_register(KY11_ADDRESS_SWITCH_REGISTER, ky11_switch_read);
  unibus_write_hook_register(KY11_ADDRESS_SWITCH_REGISTER, ky11_switch_write);
}



