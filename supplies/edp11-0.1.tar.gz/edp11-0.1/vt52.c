#include "vt52.h"
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef UNICODE
#define NCURSES_WIDECHAR 1
#include <ncursesw/ncurses.h>
#include <locale.h>
#else
#include <curses.h>
#endif

#include "dl11.h"

#define VT52_TIMEOUT_DEFAULT 1
#define VT52_MAX_Y 24
#define VT52_MAX_X 80

#ifdef UNICODE
static wchar_t vt52_shifted_to_unicode[63] = { /* KOI-7 N1 */
  0x044E, 0x0430, 0x0431, 0x0446, 0x0434, 0x0435, 0x0444, 0x0433,
  0x0445, 0x0438, 0x0439, 0x043A, 0x043B, 0x043C, 0x043D, 0x043E,
  0x043F, 0x044F, 0x0440, 0x0441, 0x0442, 0x0443, 0x0436, 0x0432,
  0x044C, 0x044B, 0x0437, 0x0448, 0x044D, 0x0449, 0x0447, 0x044A,
  0x042E, 0x0410, 0x0411, 0x0426, 0x0414, 0x0415, 0x0424, 0x0413,
  0x0425, 0x0418, 0x0419, 0x041A, 0x041B, 0x041C, 0x041D, 0x041E,
  0x041F, 0x042F, 0x0420, 0x0421, 0x0422, 0x0423, 0x0416, 0x0412,
  0x042C, 0x042B, 0x0417, 0x0428, 0x042D, 0x0429, 0x0427,
};

static wchar_t vt52_graphics_to_unicode[33] = {
  0x0020,  /* 0x5E - Blank */
  0x0020,  /* 0x5F - Blank */
  0x0020,  /* 0x60 - Reserved */
  0x2588,  /* 0x61 - Solid Rectangle */
  0x215F,  /* 0x62 - Fraction Numerator 1 */
  0x00B3,  /* 0x63 - Fraction Numerator 3 (NOTE: Missing the slash.) */
  0x2075,  /* 0x64 - Fraction Numerator 5 (NOTE: Missing the slash.) */
  0x2077,  /* 0x65 - Fraction Numerator 7 (NOTE: Missing the slash.) */
  0x00B0,  /* 0x66 - Degrees */
  0x00B1,  /* 0x67 - Plus or Minus */
  0x2192,  /* 0x68 - Right Arrow */
  0x2026,  /* 0x69 - Ellipsis */
  0x00F7,  /* 0x6A - Divide By */
  0x2193,  /* 0x6B - Down Arrow */
  0x2594,  /* 0x6C - Bar at Scan 0 */
  0x1FB76, /* 0x6D - Bar at Scan 1 */
  0x1FB77, /* 0x6E - Bar at Scan 2 */
  0x1FB78, /* 0x6F - Bar at Scan 3 */
  0x1FB79, /* 0x70 - Bar at Scan 4 */
  0x1FB7A, /* 0x71 - Bar at Scan 5 */
  0x1FB7B, /* 0x72 - Bar at Scan 6 */
  0x2581,  /* 0x73 - Bar at Scan 7 */
  0x2080,  /* 0x74 - Subscript 0 */
  0x2081,  /* 0x75 - Subscript 1 */
  0x2082,  /* 0x76 - Subscript 2 */
  0x2083,  /* 0x77 - Subscript 3 */
  0x2084,  /* 0x78 - Subscript 4 */
  0x2085,  /* 0x79 - Subscript 5 */
  0x2086,  /* 0x7A - Subscript 6 */
  0x2087,  /* 0x7B - Subscript 7 */
  0x2088,  /* 0x7C - Subscript 8 */
  0x2089,  /* 0x7D - Subscript 9 */
  0x00B6,  /* 0x7E - Paragraph */
};
#endif /* UNICODE */

static uint8_t vt52_reply[3];
static int vt52_reply_index;
static int vt52_reply_delay;

static bool vt52_graphics_mode;
static bool vt52_hold_screen_mode;
static bool vt52_alt_keypad_mode;
static bool vt52_shifted;



void vt52_send(uint8_t byte)
{
  static bool escape = false;
  static int escape_dca = 0;
  static int y = 0; /* Keep local control of Y and X coordinates! */
  static int x = 0;
  int temp_y;
  int temp_x;
#ifdef UNICODE
  cchar_t cchar;
#endif /* UNICODE */

  byte &= 0x7F; /* 7-bit ASCII only. */

  if (escape_dca == 2) { /* Direct cursor addressing line. */
    y = byte - 040;
    if (y >= VT52_MAX_Y) {
      y = (VT52_MAX_Y - 1);
    }
    escape_dca--;

  } else if (escape_dca == 1) { /* Direct cursor addressing column. */
    x = byte - 040;
    if (x >= VT52_MAX_X) {
      x = (VT52_MAX_X - 1);
    }
    escape_dca--;

  } else if (escape == true) { /* Escape codes. */
    switch (byte) {
    case 'A': /* Cursor Up */
      if (y > 0) {
        y--;
      }
      break;

    case 'B': /* Cursor Down */
      if (y < (VT52_MAX_Y - 1)) {
        y++;
      }
      break;

    case 'C': /* Cursor Right */
      if (x < (VT52_MAX_X - 1)) {
        x++;
      }
      break;

    case 'D': /* Cursor Left */
      if (x > 0) {
        x--;
      }
      break;

    case 'F': /* Enter Graphics Mode */
      vt52_graphics_mode = true;
      break;

    case 'G': /* Exit Graphics Mode */
      vt52_graphics_mode = false;
      break;

    case 'H': /* Cursor Home */
      y = 0;
      x = 0;
      break;

    case 'I': /* Reverse Line Feed */
      if (y > 0) {
        y--;
      } else {
        scrollok(stdscr, TRUE);
        scrl(-1);
        scrollok(stdscr, FALSE);
        for (temp_x = 0; temp_x < VT52_MAX_X; temp_x++) {
          /* Clear last line, which might have been scrolled. */
          mvaddch(VT52_MAX_Y, temp_x, ' ');
        }
      }
      break;

    case 'J': /* Erase to End-of-Screen */
      temp_y = y;
      temp_x = x;
      while (temp_x < VT52_MAX_X && temp_y < VT52_MAX_Y) {
        mvaddch(temp_y, temp_x, ' ');
        temp_x++;
        if (temp_x >= VT52_MAX_X) {
          temp_x = 0;
          temp_y++;
        }
      }
      break;

    case 'K': /* Erase to End-of-Line */
      temp_x = x;
      while (temp_x < VT52_MAX_X) {
        mvaddch(y, temp_x, ' ');
        temp_x++;
      }
      break;

    case 'Y': /* Direct Cursor Addressing */
      escape_dca = 2;
      break;

    case 'Z': /* Identify Terminal Type */
      vt52_reply[0] = 'K'; /* VT52 */
      vt52_reply[1] = '/';
      vt52_reply[2] = 0x1B;
      vt52_reply_index = 3;
      vt52_reply_delay = 5;
      break;

    case '[': /* Enter Hold-Screen Mode */
      vt52_hold_screen_mode = true;
      break;

    case '\\': /* Exit Hold-Screen-Mode */
      vt52_hold_screen_mode = false;
      break;

    case '=': /* Enter Alternate-Keypad Mode */
      vt52_alt_keypad_mode = true;
      break;

    case '>': /* Exit Alternate-Keypad Mode */
      vt52_alt_keypad_mode = false;
      break;

    default:
      break;
    }
    escape = false;

  } else if (byte >= 0x20 && byte <= 0x7F) { /* Printable ASCII characters. */
    if (vt52_graphics_mode && byte >= 0x5E && byte <= 0x7E) {
#ifdef UNICODE
      setcchar(&cchar, &vt52_graphics_to_unicode[byte - 0x5E], 0, 0, NULL);
      mvadd_wch(y, x, &cchar);
#else /* !UNICODE */
      if (byte == 0x5E || byte == 0x5F) { /* Blank */
        mvaddch(y, x, ' ');
      } else if (byte == 0x61) { /* Solid Block */
        attron(A_REVERSE);
        mvaddch(y, x, ' ');
        attroff(A_REVERSE);
      } else { /* Unsupported graphics character. */
        mvaddch(y, x, '.'); /* Just print a dot... */
      }
#endif /* UNICODE */
    } else {
      if (byte == 0x7F) { /* Display DEL as a solid block. */
        attron(A_REVERSE);
        mvaddch(y, x, ' ');
        attroff(A_REVERSE);
      } else {
#ifdef UNICODE
        if (vt52_shifted && byte >= 0x40 && byte <= 0x7E) {
          setcchar(&cchar, &vt52_shifted_to_unicode[byte - 0x40], 0, 0, NULL);
          mvadd_wch(y, x, &cchar);
        } else
#endif /* UNICODE */
        {
          mvaddch(y, x, byte);
        }
      }
    }
    x++;
    if (x >= VT52_MAX_X) {
      x = (VT52_MAX_X - 1);
    }

  } else { /* ASCII control codes. */
    switch (byte) {
    case 0x00: /* NUL */
      break; /* Ignore */

    case 0x07: /* BEL */
      flash();
      break;

    case 0x08: /* BS */
      if (x > 0) {
        x--;
      }
      break;

    case 0x09: /* HT */
      while ((x % 8) != 0) {
        x++;
      }
      if (x >= VT52_MAX_X) {
        x = (VT52_MAX_X - 1);
      }
      break;

    case 0x0A: /* LF */
      y++;
      if (y >= VT52_MAX_Y) {
        /* NOTE: Hold-Screen Mode does nothing. */
        scrollok(stdscr, TRUE);
        scrl(1);
        scrollok(stdscr, FALSE);
        y--;
      }
      break;

    case 0x0D: /* CR */
      x = 0;
      break;

    case 0x0E: /* SO */
      vt52_shifted = true;
      break;

    case 0x0F: /* SI */
      vt52_shifted = false;
      break;

    case 0x1B: /* ESC */
      if (escape == false) {
        escape = true;
      } else {
        escape = false;
      }
      break;

    case 0x7F: /* DEL */
      break; /* Ignore */

    default:
      break;
    }
  }

  move(y, x);
  refresh();
}



uint8_t vt52_recv(void)
{
  int ch;

  if (vt52_reply_index > 0) {
    vt52_reply_index--;
    return vt52_reply[vt52_reply_index];
  }

  ch = getch();

  /* NOTE: Alternate-Keypad Mode not supported. */

  switch(ch) {
  case KEY_UP:
    vt52_reply[0] = 'A';
    vt52_reply_index = 1;
    return 0x1B; /* ESC */

  case KEY_DOWN:
    vt52_reply[0] = 'B';
    vt52_reply_index = 1;
    return 0x1B; /* ESC */

  case KEY_RIGHT:
    vt52_reply[0] = 'C';
    vt52_reply_index = 1;
    return 0x1B; /* ESC */

  case KEY_LEFT:
    vt52_reply[0] = 'D';
    vt52_reply_index = 1;
    return 0x1B; /* ESC */

  case KEY_F(1):
    vt52_reply[0] = 'P';
    vt52_reply_index = 1;
    return 0x1B; /* ESC */

  case KEY_F(2):
    vt52_reply[0] = 'Q';
    vt52_reply_index = 1;
    return 0x1B; /* ESC */

  case KEY_F(3):
    vt52_reply[0] = 'R';
    vt52_reply_index = 1;
    return 0x1B; /* ESC */

  case KEY_BACKSPACE:
    return 0x08; /* BS */

  case KEY_F(4):
  case KEY_ENTER:
    return 0x0D; /* CR */

  case KEY_DC:
    return 0x7F; /* DEL */

  default:
    break;
  }

  if (ch >= 0 && ch <= 0xFF) {
    return (uint8_t)ch;
  } else {
    return 0;
  }
}



bool vt52_poll(void)
{
  int ch;

  if (vt52_reply_index > 0) {
    if (vt52_reply_delay > 0) {
      vt52_reply_delay--;
      return false;
    }
    return true;
  }

  ch = getch();

  if (ch == ERR) {
    return false;
  } else {
    ungetch(ch);
    return true;
  }
}



void vt52_pause(void)
{
  endwin();
  timeout(-1);
}



void vt52_resume(void)
{
  timeout(VT52_TIMEOUT_DEFAULT);
  refresh();
}



static void vt52_exit(void)
{
  endwin();
}



void vt52_init()
{
  vt52_reply_index = 0;
  vt52_reply_delay = 0;

  vt52_graphics_mode    = false;
  vt52_hold_screen_mode = false;
  vt52_alt_keypad_mode  = false;
  vt52_shifted          = false;

  initscr();
#ifdef UNICODE
  setlocale(LC_ALL, "en_US.UTF-8");
#endif /* UNICODE */
  atexit(vt52_exit);
  noecho();
  keypad(stdscr, TRUE);
  timeout(VT52_TIMEOUT_DEFAULT);

  dl11_hook_register(vt52_send, vt52_recv, vt52_poll, vt52_pause, vt52_resume);
}



