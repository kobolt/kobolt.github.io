#ifndef _M9312_H
#define _M9312_H

#define M9312_ADDRESS_LOW  0765000
#define M9312_ADDRESS_HIGH 0773000

void m9312_init(void);
int m9312_load_low_rom(const char *filename);
int m9312_load_high_rom(const char *filename);

#endif /* _M9312_H */
