#include "rx11.h"
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

#include "unibus.h"

#define RX11_VECTOR_DONE  0000264
#define RX11_IRQ_PRIORITY 5

#define RX11_TRACKS      77
#define RX11_SECTORS     26
#define RX11_SECTOR_SIZE 128 /* RX01 Floppy */
#define RX11_IMAGE_SIZE (RX11_TRACKS * RX11_SECTORS * RX11_SECTOR_SIZE)
#define RX11_DRIVE_UNITS 2

#define RX11_DONE_COUNTDOWN 50

#define RX11_FUNCTION_CODE_FILL_BUFFER     0
#define RX11_FUNCTION_CODE_EMPTY_BUFFER    1
#define RX11_FUNCTION_CODE_WRITE_SECTOR    2
#define RX11_FUNCTION_CODE_READ_SECTOR     3
#define RX11_FUNCTION_CODE_READ_STATUS     5
#define RX11_FUNCTION_CODE_WRITE_DD_SECTOR 6
#define RX11_FUNCTION_CODE_READ_ERROR_REG  7

#define RX11_ERROR_CODE_TRACK_EXCEEDED   00040
#define RX11_ERROR_CODE_SECTOR_NOT_FOUND 00070

#define RX11_RXCS_GO   0
#define RX11_RXCS_F0   1
#define RX11_RXCS_F1   2
#define RX11_RXCS_F2   3
#define RX11_RXCS_UNIT 4
#define RX11_RXCS_DONE 5
#define RX11_RXCS_IE   6
#define RX11_RXCS_TR   7
#define RX11_RXCS_INIT 14
#define RX11_RXCS_ERR  15

#define RX11_RXES_CRC 0
#define RX11_RXES_PAR 1
#define RX11_RXES_ID  2
#define RX11_RXES_DD  6
#define RX11_RXES_RDY 7

#define rx11_rxcs_set(bit)  (rx11_rxcs |=  (1 << bit))
#define rx11_rxcs_clr(bit)  (rx11_rxcs &= ~(1 << bit))
#define rx11_rxcs_get(bit) ((rx11_rxcs >> bit) & 1)

#define rx11_rxes_set(bit)  (rx11_rxes |=  (1 << bit))
#define rx11_rxes_clr(bit)  (rx11_rxes &= ~(1 << bit))

typedef enum {
  RX11_STATE_IDLE,
  RX11_STATE_FILL_BUFFER,
  RX11_STATE_EMPTY_BUFFER,
  RX11_STATE_WRITE_SECTOR_RXSA,
  RX11_STATE_WRITE_SECTOR_RXTA,
  RX11_STATE_READ_SECTOR_RXSA,
  RX11_STATE_READ_SECTOR_RXTA,
  RX11_STATE_READ_STATUS,
  RX11_STATE_WRITE_DD_SECTOR_RXSA,
  RX11_STATE_WRITE_DD_SECTOR_RXTA,
  RX11_STATE_READ_ERROR_REG,
} rx11_state_t;

static rx11_state_t rx11_state;
static int rx11_done_countdown;

static uint16_t rx11_rxcs;
static uint16_t rx11_rxta;
static uint16_t rx11_rxsa;
static uint16_t rx11_rxes;
static uint16_t rx11_error_code;

static uint8_t rx11_buffer_index;
static uint8_t rx11_buffer[RX11_SECTOR_SIZE];
static uint8_t rx11_image[RX11_DRIVE_UNITS][RX11_IMAGE_SIZE];
static bool rx11_dd_written; /* To pass MAINDEC-11-DZRXB-E-PB test. */



static void rx11_image_to_buffer(int drive_unit)
{
  int i;
  uint32_t image_index;

  if (rx11_rxsa == 0 || rx11_rxsa > RX11_SECTORS) {
    /* Illegal sector given. */
    rx11_error_code = RX11_ERROR_CODE_SECTOR_NOT_FOUND;
    rx11_rxcs_set(RX11_RXCS_ERR);
    return;
  }

  image_index  = (rx11_rxta * RX11_SECTORS * RX11_SECTOR_SIZE);
  image_index += ((rx11_rxsa - 1) * RX11_SECTOR_SIZE);

  for (i = 0; i < RX11_SECTOR_SIZE; i++) {
    if (image_index >= RX11_IMAGE_SIZE) {
      /* Track out of range. */
      rx11_error_code = RX11_ERROR_CODE_TRACK_EXCEEDED;
      rx11_rxcs_set(RX11_RXCS_ERR);
      return;
    }
    rx11_buffer[i] = rx11_image[drive_unit][image_index];
    image_index++;
  }
}



static void rx11_buffer_to_image(int drive_unit)
{
  int i;
  uint32_t image_index;

  if (rx11_rxsa == 0 || rx11_rxsa > RX11_SECTORS) {
    /* Illegal sector given. */
    rx11_error_code = RX11_ERROR_CODE_SECTOR_NOT_FOUND;
    rx11_rxcs_set(RX11_RXCS_ERR);
    return;
  }

  image_index  = (rx11_rxta * RX11_SECTORS * RX11_SECTOR_SIZE);
  image_index += ((rx11_rxsa - 1) * RX11_SECTOR_SIZE);

  for (i = 0; i < RX11_SECTOR_SIZE; i++) {
    if (image_index >= RX11_IMAGE_SIZE) {
      /* Track out of range. */
      rx11_error_code = RX11_ERROR_CODE_TRACK_EXCEEDED;
      rx11_rxcs_set(RX11_RXCS_ERR);
      return;
    }
    rx11_image[drive_unit][image_index] = rx11_buffer[i];
    image_index++;
  }
}



static void rx11_function(void)
{
  switch ((rx11_rxcs >> RX11_RXCS_F0) & 7) {
  case RX11_FUNCTION_CODE_FILL_BUFFER:
    rx11_rxcs_clr(RX11_RXCS_DONE);
    rx11_rxcs_set(RX11_RXCS_TR);
    rx11_buffer_index = 0;
    rx11_state = RX11_STATE_FILL_BUFFER;
    break;

  case RX11_FUNCTION_CODE_EMPTY_BUFFER:
    rx11_rxcs_clr(RX11_RXCS_DONE);
    rx11_rxcs_set(RX11_RXCS_TR);
    rx11_buffer_index = 0;
    rx11_state = RX11_STATE_EMPTY_BUFFER;
    break;

  case RX11_FUNCTION_CODE_WRITE_SECTOR:
    rx11_rxcs_clr(RX11_RXCS_DONE);
    rx11_rxcs_set(RX11_RXCS_TR);
    rx11_state = RX11_STATE_WRITE_SECTOR_RXSA;
    break;

  case RX11_FUNCTION_CODE_READ_SECTOR:
    rx11_rxcs_clr(RX11_RXCS_DONE);
    rx11_rxcs_set(RX11_RXCS_TR);
    rx11_state = RX11_STATE_READ_SECTOR_RXSA;
    break;

  case RX11_FUNCTION_CODE_READ_STATUS:
    rx11_done_countdown = RX11_DONE_COUNTDOWN;
    rx11_rxcs_clr(RX11_RXCS_DONE);
    rx11_state = RX11_STATE_READ_STATUS;
    break;

  case RX11_FUNCTION_CODE_WRITE_DD_SECTOR:
    rx11_rxcs_clr(RX11_RXCS_DONE);
    rx11_rxcs_set(RX11_RXCS_TR);
    rx11_state = RX11_STATE_WRITE_DD_SECTOR_RXSA;
    break;

  case RX11_FUNCTION_CODE_READ_ERROR_REG:
    rx11_done_countdown = RX11_DONE_COUNTDOWN;
    rx11_rxcs_clr(RX11_RXCS_DONE);
    rx11_rxcs_clr(RX11_RXCS_ERR);
    rx11_state = RX11_STATE_READ_ERROR_REG;
    break;
  }
}



static void rx11_done(void)
{
  rx11_rxcs_set(RX11_RXCS_DONE);
  if (rx11_rxcs_get(RX11_RXCS_IE)) {
    unibus_irq_set(RX11_VECTOR_DONE, RX11_IRQ_PRIORITY);
  } else {
    unibus_irq_set(0, RX11_IRQ_PRIORITY);
  }
}



static void rx11_rxdb_write(uint16_t value)
{
  switch (rx11_state) {
  case RX11_STATE_FILL_BUFFER:
    rx11_buffer[rx11_buffer_index] = value & 0xFF;
    rx11_buffer_index++;
    if (rx11_buffer_index >= RX11_SECTOR_SIZE) {
      rx11_buffer_index = 0;
      rx11_rxcs_clr(RX11_RXCS_TR);
      rx11_done();
      rx11_state = RX11_STATE_IDLE;
    }
    break;

  case RX11_STATE_READ_SECTOR_RXSA:
    rx11_rxsa = value & 0x1F;
    rx11_state = RX11_STATE_READ_SECTOR_RXTA;
    break;

  case RX11_STATE_READ_SECTOR_RXTA:
    rx11_rxta = value & 0x7F;
    rx11_image_to_buffer(rx11_rxcs_get(RX11_RXCS_UNIT));
    if (rx11_dd_written) {
      rx11_rxes_set(RX11_RXES_DD);
    }
    rx11_rxcs_clr(RX11_RXCS_TR);
    rx11_done_countdown = RX11_DONE_COUNTDOWN;
    rx11_state = RX11_STATE_IDLE;
    break;

  case RX11_STATE_WRITE_SECTOR_RXSA:
    rx11_rxsa = value & 0x1F;
    rx11_state = RX11_STATE_WRITE_SECTOR_RXTA;
    break;

  case RX11_STATE_WRITE_SECTOR_RXTA:
    rx11_rxta = value & 0x7F;
    rx11_buffer_to_image(rx11_rxcs_get(RX11_RXCS_UNIT));
    rx11_dd_written = false;
    rx11_rxcs_clr(RX11_RXCS_TR);
    rx11_done_countdown = RX11_DONE_COUNTDOWN;
    rx11_state = RX11_STATE_IDLE;
    break;

  case RX11_STATE_WRITE_DD_SECTOR_RXSA:
    rx11_rxsa = value & 0x1F;
    rx11_state = RX11_STATE_WRITE_DD_SECTOR_RXTA;
    break;

  case RX11_STATE_WRITE_DD_SECTOR_RXTA:
    rx11_rxta = value & 0x7F;
    rx11_buffer_to_image(rx11_rxcs_get(RX11_RXCS_UNIT));
    rx11_dd_written = true;
    rx11_rxes_set(RX11_RXES_DD);
    rx11_rxcs_clr(RX11_RXCS_TR);
    rx11_done_countdown = RX11_DONE_COUNTDOWN;
    rx11_state = RX11_STATE_IDLE;
    break;

  default:
    break;
  }
}



static uint16_t rx11_rxdb_read(void)
{
  uint16_t value;

  switch (rx11_state) {
  case RX11_STATE_EMPTY_BUFFER:
    value = rx11_buffer[rx11_buffer_index];
    rx11_buffer_index++;
    if (rx11_buffer_index >= RX11_SECTOR_SIZE) {
      rx11_buffer_index = 0;
      rx11_rxcs_clr(RX11_RXCS_TR);
      rx11_done();
      rx11_state = RX11_STATE_IDLE;
    }
    return value;

  case RX11_STATE_READ_STATUS:
    rx11_rxes_set(RX11_RXES_RDY);
    rx11_state = RX11_STATE_IDLE;
    return rx11_rxes;

  case RX11_STATE_IDLE:
    return rx11_rxes;

  case RX11_STATE_READ_ERROR_REG:
    rx11_state = RX11_STATE_IDLE;
    return rx11_error_code;

  default:
    return 0;
  }
}



static void rx11_write(uint32_t unibus_address, uint16_t value)
{
  switch (unibus_address) {
  case RX11_ADDRESS_RXCS:
    rx11_rxcs &= ~0x405F; /* Bits that can be written. */
    rx11_rxcs |= (value & 0x405F);
    rx11_rxes = 0; /* Clear RXES on RXCS write. */
    if (rx11_rxcs_get(RX11_RXCS_INIT)) {
      rx11_rxes = 0;
      rx11_done();
      rx11_rxes_set(RX11_RXES_ID);
      rx11_rxes_set(RX11_RXES_RDY);
      rx11_rxsa = 1;
      rx11_rxta = 1;
      rx11_image_to_buffer(0);
    } else if (rx11_rxcs_get(RX11_RXCS_GO)) {
      rx11_function();
    } else {
      if (rx11_state == RX11_STATE_IDLE) {
        /* Special case where GO was not written but IE was written. */
        if (rx11_rxcs_get(RX11_RXCS_IE)) {
          unibus_irq_set(RX11_VECTOR_DONE, RX11_IRQ_PRIORITY);
        }
      }
    }
    break;

  case RX11_ADDRESS_RXDB:
    rx11_rxdb_write(value);
    break;
  }
}



static uint16_t rx11_read(uint32_t unibus_address)
{
  /* Simulate that some operations take time. */
  if (rx11_done_countdown > 0) {
    rx11_done_countdown--;
    if (rx11_done_countdown == 0) {
      rx11_done();
    }
  }

  switch (unibus_address) {
  case RX11_ADDRESS_RXCS:
    return rx11_rxcs & 0x80E0; /* Bits that can be read. */

  case RX11_ADDRESS_RXDB:
    return rx11_rxdb_read();
  }

  return 0;
}



void rx11_init(void)
{
  int i;
  int j;

  rx11_done_countdown = 0;
  rx11_rxcs = 0;
  rx11_rxta = 0;
  rx11_rxsa = 0;
  rx11_rxes = 0;
  rx11_error_code = 0;
  rx11_buffer_index = 0;
  rx11_dd_written = false;

  for (i = 0; i < RX11_SECTOR_SIZE; i++) {
    rx11_buffer[i] = 0;
  }
  for (i = 0; i < RX11_DRIVE_UNITS; i++) {
    for (j = 0; j < RX11_IMAGE_SIZE; j++) {
      rx11_image[i][j] = 0;
    }
  }

  unibus_read_hook_register(RX11_ADDRESS_RXCS, rx11_read);
  unibus_read_hook_register(RX11_ADDRESS_RXDB, rx11_read);
  unibus_write_hook_register(RX11_ADDRESS_RXCS, rx11_write);
  unibus_write_hook_register(RX11_ADDRESS_RXDB, rx11_write);

  rx11_rxcs_set(RX11_RXCS_DONE);
  rx11_rxes_set(RX11_RXES_ID);
  rx11_rxes_set(RX11_RXES_RDY);
}



int rx11_load_floppy(int drive_unit, const char *filename)
{
  FILE *fh;
  int c;
  int n;

  if (drive_unit >= RX11_DRIVE_UNITS) {
    fprintf(stdout, "Drive unit out of range: %d\n", drive_unit);
    return -2;
  }

  fh = fopen(filename, "rb");
  if (fh == NULL) {
    fprintf(stdout, "Error opening file: '%s'\n", filename);
    return -1;
  }

  if (! (drive_unit == 0 || drive_unit == 1)) {
    return -2;
  }

  n = 0;
  while ((c = fgetc(fh)) != EOF) {
    rx11_image[drive_unit][n] = c;
    n++;
    if (n >= RX11_IMAGE_SIZE) {
      break;
    }
  }

  fclose(fh);
  return 0;
}



