# edp11
PDP-11 emulator experiment.

## Features
* Currently similar to a PDP-11/40.
* KD11 CPU with the EIS and FIS instruction sets, but no MMU support.
* VT52 (DECscope) video or simple LA36 (DECwriter) line-by-line console.
* Built-in native 'Absolute Loader' for loading paper tapes easily.
* RX11 floppy controller for loading RX01 floppy disk images.
* RL11 disk controller for loading RL02 hard disk images. 
* M9312 ROM card to support automatic booting.
* KY11 front panel console switches.
* DL11 serial interface. (Hooked up to the selected console.)
* Debugger with breakpoint and trace support.
* Polling of stdin with different methods to relax the host CPU.
* VT52 console displays graphics and KOI-7 characters if Unicode is enabled.
* 56K of RAM available.

## Notes
* To quit the emulator, use Ctrl+C to enter the debugger and then 'q' command.
* Some programs like CR (Carriage Return) and others like LF (Line Feed).
* Backspace behaviour is weird in programs. BS and DEL behaviour vary a lot.
* Use 'F4' in VT52 console to send a CR, since 'Return' typically sends a LF.
* Use 'Delete' in VT52 console to send DEL, since 'Backspace' sends a BS.
* If programs are running too fast, increase the poll rate through the argument.
* MFPI and MTPI instructions are missing and will trigger the 'Reserved' trap.
* RL11 controller behaves like a mix of old and new hardware implementation.

## Software
How to best run some different software.

### Links
* There is a collection of paper tapes at [iamvirtual.ca](https://iamvirtual.ca/collection/systems/mediadoc/mediadoc.html).
* M9312 ROM images can be found at [ak6dn.github.io](https://ak6dn.github.io/PDP-11/M9312/)
* XXDP on RL02 hard disk images can be found at [bitsavers.trailing-edge.com](https://bitsavers.trailing-edge.com/bits/DEC/pdp11/discimages/rl02/).
* RT-11 v4.0 on RX01 floppy disk images can also be found at [bitsavers.trailing-edge.com](https://bitsavers.trailing-edge.com/bits/DEC/pdp11/rt-11/)
* Collection of RT-11 games on RL02 hard disk image can be found at [pdp-11.ru](https://pdp-11.ru/mybk/hobot/ukdwk_archive/dwkwebcomplekt/rt11_symbol_games/)

### PDP-11 BASIC (Paper Tape)
```
./edp11 -a DEC-11-AJPB-PB.ptap -l 8
```

### XXDP v2.2 (RL02 Hard Disk Image)
```
./edp11 -y 23-751A9-0698.hex -r xxdp22.rl02 -l 4
```

### XXDP v2.5 (RL02 Hard Disk Image)
```
./edp11 -y 23-751A9-0698.hex -r xxdp25.rl02
```

### RT-11 v4.0 (RX01 Floppy Disk Image)
```
./edp11 -y 23-753A9-066D.hex -f "RT-11 v4.0 BIN RX01 1-7 (ORIGINAL DISK).img"
```

### Tetris (RT-11 Version)
```
./edp11 -y 23-753A9-066D.hex -f "RT-11 v4.0 BIN RX01 1-7 (ORIGINAL DISK).img" -r rt11_symbol_games.dsk -p 250
```
After RT-11 has booted:
```
RUN DL0:TETRIS
```

## Paper Tape Tests Passed
* MAINDEC-11-D0AA (Branch)
* MAINDEC-11-D0BA (Conditional Branch)
* MAINDEC-11-D0CA (Unary)
* MAINDEC-11-D0DA (Unary + Binary)
* MAINDEC-11-D0EA (Rotate Shift)
* MAINDEC-11-D0FA (Compare)
* MAINDEC-11-D0GA (Compare Not)
* MAINDEC-11-D0HA (Move)
* MAINDEC-11-D0IA (BIS, BIC, BIT)
* MAINDEC-11-D0JA (ADD)
* MAINDEC-11-D0KA (SUB)
* MAINDEC-11-D0LA (JMP)
* MAINDEC-11-D0MA (JSR, RTS, RTI)
* MAINDEC-11-D0OA (Combined Instruction)
* MAINDEC-11-DCKBA-A (SXT)
* MAINDEC-11-DCKBB-A (SOB)
* MAINDEC-11-DCKBC-B (XOR)
* MAINDEC-11-DCKBD-B (MARK)
* MAINDEC-11-DCKBF-A (Stack Limit)
* MAINDEC-11-DCKBI-B (ASH)
* MAINDEC-11-DCKBJ-A (ASHC)
* MAINDEC-11-DCKBK-A (MUL)
* MAINDEC-11-DCKBL-A (DIV)
* MAINDEC-11-DZRLA-A (RL11 Control 1)
* MAINDEC-11-DZRLB-A (RL11 Control 2)
* MAINDEC-11-DZRXA-E (RX11 Reliability)
* MAINDEC-11-DZRXB-E (RX11 Interface)
* MAINDEC-11-DZVTC-CI (VT52 Acceptance)

