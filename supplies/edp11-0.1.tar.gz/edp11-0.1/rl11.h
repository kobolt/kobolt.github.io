#ifndef _RL11_H
#define _RL11_H

#include <stdio.h>

#define RL11_ADDRESS_CSR 0774400
#define RL11_ADDRESS_BAR 0774402
#define RL11_ADDRESS_DAR 0774404
#define RL11_ADDRESS_MPR 0774406

void rl11_init(void);
int rl11_load_disk(int drive_unit, const char *filename);

#endif /* _RL11_H */
