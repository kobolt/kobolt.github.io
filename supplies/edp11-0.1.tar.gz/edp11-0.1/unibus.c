#include "unibus.h"
#include <stdbool.h>
#include <stdint.h>

#include "kd11_trace.h"

#define UNIBUS_ADDRESS_MAX 0x40000 /* 18-bit */
#define UNIBUS_IRQ_LEVELS 8 /* Only 4 to 7 used. */
#define UNIBUS_RESET_HOOK_MAX 5

static unibus_read_hook_t  unibus_read[UNIBUS_ADDRESS_MAX];
static unibus_write_hook_t unibus_write[UNIBUS_ADDRESS_MAX];
static unibus_reset_hook_t unibus_reset_hook[UNIBUS_RESET_HOOK_MAX];
static bool unibus_odd_address_error = false;
static bool unibus_timeout_error = false;
static uint16_t unibus_irq_vector[UNIBUS_IRQ_LEVELS];



static inline uint32_t unibus_address_translate(uint16_t address)
{
  if (address >= 0160000) {
    return address + 0600000; /* I/O (Page 7) */
  } else {
    return address; /* RAM */
  }
}



static uint16_t unibus_read_default(uint32_t unibus_address)
{
  (void)unibus_address;
  kd11_trace_trap_info("Read Timeout: %o", unibus_address);
  unibus_timeout_error = true;
  return 0;
}



static void unibus_write_default(uint32_t unibus_address, uint16_t value)
{
  (void)unibus_address;
  (void)value;
  kd11_trace_trap_info("Write Timeout: %o", unibus_address);
  unibus_timeout_error = true;
}



uint8_t unibus_read_8(uint16_t address)
{
  uint32_t unibus_address;

  unibus_address = unibus_address_translate(address);
  if (unibus_address % 2 == 0) {
    return (unibus_read[unibus_address])(unibus_address) % 0x100;
  } else {
    return (unibus_read[unibus_address-1])(unibus_address-1) / 0x100;
  }
}



uint16_t unibus_read_16(uint16_t address)
{
  uint32_t unibus_address;

  unibus_address = unibus_address_translate(address);
  if (unibus_address % 2 == 0) {
    return (unibus_read[unibus_address])(unibus_address);
  } else {
    kd11_trace_trap_info("Odd Read: %o", unibus_address);
    unibus_odd_address_error = true;
    return 0;
  }
}



void unibus_write_8(uint16_t address, uint8_t value)
{
  uint32_t unibus_address;
  uint16_t value_16;

  unibus_address = unibus_address_translate(address);
  if (unibus_address % 2 == 0) {
    value_16 = (unibus_read[unibus_address])(unibus_address);
    value_16 &= ~0xFF;
    value_16 |= value;
    (unibus_write[unibus_address])(unibus_address, value_16);
  } else {
    value_16 = (unibus_read[unibus_address-1])(unibus_address-1);
    value_16 &= ~0xFF00;
    value_16 |= (value << 8);
    (unibus_write[unibus_address-1])(unibus_address-1, value_16);
  }
}



void unibus_write_16(uint16_t address, uint16_t value)
{
  uint32_t unibus_address;

  unibus_address = unibus_address_translate(address);
  if (unibus_address % 2 == 0) {
    (unibus_write[unibus_address])(unibus_address, value);
  } else {
    kd11_trace_trap_info("Odd Write: %o", unibus_address);
    unibus_odd_address_error = true;
  }
}



uint16_t unibus_read_direct(uint32_t unibus_address)
{
  unibus_address &= (UNIBUS_ADDRESS_MAX - 1);
  if (unibus_address % 2 == 0) {
    return (unibus_read[unibus_address])(unibus_address);
  } else {
    return 0;
  }
}



void unibus_write_direct(uint32_t unibus_address, uint16_t value)
{
  unibus_address &= (UNIBUS_ADDRESS_MAX - 1);
  if (unibus_address % 2 == 0) {
    (unibus_write[unibus_address])(unibus_address, value);
  }
}



void unibus_read_hook_register(uint32_t unibus_address,
  unibus_read_hook_t hook)
{
  unibus_read[unibus_address] = hook;
}



void unibus_write_hook_register(uint32_t unibus_address,
  unibus_write_hook_t hook)
{
  unibus_write[unibus_address] = hook;
}



void unibus_reset_hook_register(unibus_reset_hook_t hook)
{
  int i;

  for (i = 0; i < UNIBUS_RESET_HOOK_MAX; i++) {
    if (unibus_reset_hook[i] == NULL) {
      unibus_reset_hook[i] = hook;
      break;
    }
  }
}



void unibus_reset(void)
{
  int i;

  unibus_error_reset();

  for (i = 0; i < UNIBUS_IRQ_LEVELS; i++) {
    unibus_irq_vector[i] = 0;
  }

  for (i = 0; i < UNIBUS_RESET_HOOK_MAX; i++) {
    if (unibus_reset_hook[i] != NULL) {
      (unibus_reset_hook[i])();
    }
  }
}



void unibus_init(void)
{
  int i;

  for (i = 0; i < UNIBUS_ADDRESS_MAX; i++) {
    unibus_read[i] = unibus_read_default;
    unibus_write[i] = unibus_write_default;
  }

  for (i = 0; i < UNIBUS_IRQ_LEVELS; i++) {
    unibus_irq_vector[i] = 0;
  }

  for (i = 0; i < UNIBUS_RESET_HOOK_MAX; i++) {
    unibus_reset_hook[i] = NULL;
  }

  unibus_reset();
}



bool unibus_error_occured(void)
{
  return unibus_odd_address_error || unibus_timeout_error;
}



void unibus_error_reset(void)
{
  unibus_odd_address_error = false;
  unibus_timeout_error = false;
}



void unibus_irq_set(uint16_t vector, uint8_t level)
{
   /* Levels BR4, BR5, BR6 and BR7 used. */
   unibus_irq_vector[level] = vector;
}



uint16_t unibus_irq_get(uint8_t cpu_level)
{
  int i;
  uint16_t vector;

  for (i = 7; i > cpu_level; i--) {
    vector = unibus_irq_vector[i];
    if (vector > 0) {
      unibus_irq_vector[i] = 0;
      return vector;
    }
  }

  return 0;
}



