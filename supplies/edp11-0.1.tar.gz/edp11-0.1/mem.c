#include "mem.h"
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "unibus.h"

#define MEM_RAM_MAX 57344 /* 64K - 8K */

/* Absolute Loader State */
typedef enum {
  AL_STATE_LEADER,
  AL_STATE_HEADER,
  AL_STATE_HEADER_COUNT_LOW,
  AL_STATE_HEADER_COUNT_HIGH,
  AL_STATE_HEADER_ADDR_LOW,
  AL_STATE_HEADER_ADDR_HIGH,
  AL_STATE_PROGRAM,
  AL_STATE_CHECKSUM,
  AL_STATE_FINISHED,
} al_state_t;

static uint8_t ram[MEM_RAM_MAX];



static uint16_t mem_read(uint32_t unibus_address)
{
  return ram[unibus_address] | (ram[unibus_address+1] << 8);
}



static void mem_write(uint32_t unibus_address, uint16_t value)
{
  ram[unibus_address]   = value % 0x100;
  ram[unibus_address+1] = value / 0x100;
}



void mem_init(void)
{
  int i;

  for (i = 0; i < MEM_RAM_MAX; i += 2) {
    ram[i] = 0x00;
    ram[i+1] = 0x00;
    unibus_read_hook_register(i, mem_read);
    unibus_write_hook_register(i, mem_write);
  }
}



int mem_absolute_loader(const char *filename, uint16_t *jump)
{
  FILE *fh;
  int c;
  uint16_t count;
  uint32_t address;
  uint8_t checksum;
  al_state_t state;

  fh = fopen(filename, "rb");
  if (fh == NULL) {
    fprintf(stdout, "Error opening file: '%s'\n", filename);
    return -1;
  }

  state = AL_STATE_LEADER;
  while ((c = fgetc(fh)) != EOF) {
    if (state == AL_STATE_FINISHED) {
      break;
    }

    switch (state) {
    case AL_STATE_LEADER:
      if (c == 0x01) {
        checksum = 1;
        state = AL_STATE_HEADER;
      }
      break;

    case AL_STATE_HEADER:
      if (c == 0x00) {
        state = AL_STATE_HEADER_COUNT_LOW;
      } else {
        state = AL_STATE_LEADER; /* Unexpected byte, go back. */
      }
      break;

    case AL_STATE_HEADER_COUNT_LOW:
      count = c;
      checksum += c;
      state = AL_STATE_HEADER_COUNT_HIGH;
      break;

    case AL_STATE_HEADER_COUNT_HIGH:
      count += (c << 8);
      count -= 6; /* Compensate for included header. */
      checksum += c;
      state = AL_STATE_HEADER_ADDR_LOW;
      break;

    case AL_STATE_HEADER_ADDR_LOW:
      address = c;
      checksum += c;
      state = AL_STATE_HEADER_ADDR_HIGH;
      break;

    case AL_STATE_HEADER_ADDR_HIGH:
      address += (c << 8);
      checksum += c;
      if (count == 0) {
        if (jump != NULL) {
          *jump = address;
        }
        state = AL_STATE_FINISHED;
      } else {
        state = AL_STATE_PROGRAM;
      }
      break;

    case AL_STATE_PROGRAM:
      if (count > 0) {
        ram[address] = c;
        address++;
        if (address >= MEM_RAM_MAX) {
          fprintf(stdout, "Memory overflow from file: '%s'\n", filename);
          return -2;
        }
        checksum += c;
        count--;
      }
      if (count == 0) {
        state = AL_STATE_CHECKSUM;
      }
      break;

    case AL_STATE_CHECKSUM:
      checksum += c;
      if (checksum != 0) {
        fprintf(stdout, "Checksum error in file: '%s'\n", filename);
        fclose(fh);
        return -3;
      }
      state = AL_STATE_LEADER;
      break;

    case AL_STATE_FINISHED:
      break;
    }
  }

  fclose(fh);
  return 0;
}



static void mem_dump_octal_16(FILE *fh, uint32_t start, uint32_t end)
{
  int i;
  uint32_t address;
  uint16_t value;

  fprintf(fh, "%08o: ", start & 0xFFFFFFF0);

  /* Octal */
  for (i = 0; i < 16; i += 2) {
    address = (start & 0xFFFFFFF0) + i;
    if ((address+1) >= MEM_RAM_MAX) {
      break;
    }
    value = ram[address] | (ram[address+1] << 8);
    if ((address >= start) && (address <= end)) {
      fprintf(fh, "%06o ", value);
    } else {
      fprintf(fh, "       ");
    }
    if (i == 6) {
      fprintf(fh, "  ");
    }
  }

  fprintf(fh, "\n");
}



void mem_dump_octal(FILE *fh, uint32_t start, uint32_t end)
{
  uint32_t i;

  if (end >= MEM_RAM_MAX) {
    end = MEM_RAM_MAX;
  }

  mem_dump_octal_16(fh, start, end);
  for (i = (start & 0xFFFFFFF0) + 16; i <= end; i += 16) {
    mem_dump_octal_16(fh, i, end);
  }
}



