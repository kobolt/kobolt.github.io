#ifndef _MEM_H
#define _MEM_H

#include <stdint.h>
#include <stdio.h>

void mem_init(void);
int mem_absolute_loader(const char *filename, uint16_t *jump);
void mem_dump_octal(FILE *fh, uint32_t start, uint32_t end);

#endif /* _MEM_H */
