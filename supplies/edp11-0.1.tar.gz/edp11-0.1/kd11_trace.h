#ifndef _KD11_TRACE_H
#define _KD11_TRACE_H

#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

void kd11_trace_start(uint16_t pc, uint16_t sp, uint16_t psw);
void kd11_trace_reg(uint16_t reg[]);
void kd11_trace_mc(uint16_t mc);
void kd11_trace_mnemonic(const char *s);
void kd11_trace_operand_1(uint8_t mode, uint8_t reg);
void kd11_trace_operand_2(uint8_t mode, uint8_t reg);
void kd11_trace_offset(int8_t offset);
void kd11_trace_trap(uint16_t vector);
void kd11_trace_trap_info(const char *format, ...);
void kd11_trace_end(void);
void kd11_trace_init(void);
void kd11_trace_dump(FILE *fh, bool extended);

#endif /* _KD11_TRACE_H */
