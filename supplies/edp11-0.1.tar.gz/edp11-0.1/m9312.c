#include "m9312.h"
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

#include "unibus.h"

#define M9312_ROM_MAX 512

static uint8_t low_rom[M9312_ROM_MAX];
static uint8_t high_rom[M9312_ROM_MAX];



static uint16_t m9312_low_read(uint32_t unibus_address)
{
  uint16_t address;
  address = unibus_address - M9312_ADDRESS_LOW;
  return low_rom[address] | (low_rom[address+1] << 8);
}



static uint16_t m9312_high_read(uint32_t unibus_address)
{
  uint16_t address;
  address = unibus_address - M9312_ADDRESS_HIGH;
  return high_rom[address] | (high_rom[address+1] << 8);
}



void m9312_init(void)
{
  int i;

  for (i = 0; i < M9312_ROM_MAX; i += 2) {
    low_rom[i]    = 0x00;
    low_rom[i+1]  = 0x00;
    high_rom[i]   = 0x00;
    high_rom[i+1] = 0x00;
    unibus_read_hook_register(M9312_ADDRESS_LOW  + i, m9312_low_read);
    unibus_read_hook_register(M9312_ADDRESS_HIGH + i, m9312_high_read);
  }
}



static int m9312_load_hex(const char *filename, uint8_t rom[])
{
  FILE *fh;
  char line[128];
  uint8_t byte_count;
  uint16_t address;
  uint8_t record_type;
  uint8_t data;
  bool bits[16];
  int n;
  size_t rom_offset;

  fh = fopen(filename, "r");
  if (fh == NULL) {
    fprintf(stdout, "Error opening file: '%s'\n", filename);
    return -1;
  }

  rom_offset = 0;
  while (fgets(line, sizeof(line), fh) != NULL) {
    if (sscanf(line, ":%02hhx%04hx%02hhx",
      &byte_count, &address, &record_type) != 3) {
      continue; /* Not a Intel HEX line. */
    }

    if (record_type != 0) {
      continue; /* Only check data records. */
    }

    /* NOTE: Checksum is not calculated nor checked. */

    n = 9;
    while (byte_count > 0) {
      if (rom_offset >= M9312_ROM_MAX) {
        break;
      }
      sscanf(&line[n], "%02hhx", &data);

      switch ((n - 9) % 8) { /* Different handling for each nibble. */
      case 0:
        bits[8] =  data       & 1;
        bits[1] = (data >> 1) & 1;
        bits[2] = (data >> 2) & 1;
        bits[3] = (data >> 3) & 1;
        break;

      case 2:
        bits[4] =  data       & 1;
        bits[5] = (data >> 1) & 1;
        bits[6] = (data >> 2) & 1;
        bits[7] = (data >> 3) & 1;
        break;

      case 4:
        bits[0]  =    data       & 1;
        bits[9]  =   (data >> 1) & 1;
        bits[10] = !((data >> 2) & 1);
        bits[11] = !((data >> 3) & 1);
        break;

      case 6:
        bits[12] = !(data       & 1);
        bits[13] =  (data >> 1) & 1;
        bits[14] =  (data >> 2) & 1;
        bits[15] =  (data >> 3) & 1;
        rom[rom_offset++] = bits[0]        | (bits[1]  << 1) |
                           (bits[2]  << 2) | (bits[3]  << 3) |
                           (bits[4]  << 4) | (bits[5]  << 5) |
                           (bits[6]  << 6) | (bits[7]  << 7);
        rom[rom_offset++] = bits[8]        | (bits[9]  << 1) |
                           (bits[10] << 2) | (bits[11] << 3) |
                           (bits[12] << 4) | (bits[13] << 5) |
                           (bits[14] << 6) | (bits[15] << 7);
        break;
      }

      n += 2;
      address++;
      byte_count--;
    }
  }

  fclose(fh);
  return 0;
}



int m9312_load_low_rom(const char *filename)
{
  return m9312_load_hex(filename, low_rom);
}



int m9312_load_high_rom(const char *filename)
{
  return m9312_load_hex(filename, high_rom);
}



