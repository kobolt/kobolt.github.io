#ifndef _VT52_H
#define _VT52_H

#include <stdbool.h>
#include <stdint.h>

void vt52_send(uint8_t byte);
uint8_t vt52_recv(void);
bool vt52_poll(void);
void vt52_pause(void);
void vt52_resume(void);
void vt52_init(void);

#endif /* _VT52_H */
