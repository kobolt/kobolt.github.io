#include "dl11.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "unibus.h"

#define DL11_VECTOR_CONSOLE_KEYBOARD 0000060
#define DL11_VECTOR_CONSOLE_PRINTER  0000064
#define DL11_IRQ_PRIORITY            4

#define DL11_RCSR_RDR_ENB      0
#define DL11_RCSR_RCVR_INT_ENB 6
#define DL11_RCSR_RCVR_DONE    7
#define DL11_RCSR_RCVR_ACT     11

#define DL11_XCSR_MAINT        2
#define DL11_XCSR_XMIT_INT_ENB 6
#define DL11_XCSR_XMIT_RDY     7

#define dl11_rcsr_set(bit)  (dl11_rcsr |=  (1 << bit))
#define dl11_rcsr_clr(bit)  (dl11_rcsr &= ~(1 << bit))
#define dl11_rcsr_get(bit) ((dl11_rcsr >> bit) & 1)

#define dl11_xcsr_set(bit)  (dl11_xcsr |=  (1 << bit))
#define dl11_xcsr_clr(bit)  (dl11_xcsr &= ~(1 << bit))
#define dl11_xcsr_get(bit) ((dl11_xcsr >> bit) & 1)

static dl11_send_hook_t dl11_send_hook;
static dl11_recv_hook_t dl11_recv_hook;
static dl11_poll_hook_t dl11_poll_hook;
static dl11_pause_hook_t dl11_pause_hook;
static dl11_resume_hook_t dl11_resume_hook;

static uint16_t dl11_rcsr = 0;
static uint16_t dl11_xcsr = 0;



static void dl11_write(uint32_t unibus_address, uint16_t value)
{
  switch (unibus_address) {
  case DL11_ADDRESS_CONSOLE_RCSR:
    dl11_rcsr &= ~0x41;
    dl11_rcsr |= (value & 0x41);
    if (dl11_rcsr_get(DL11_RCSR_RDR_ENB)) {
      dl11_rcsr_clr(DL11_RCSR_RCVR_DONE);
    }
    break;

  case DL11_ADDRESS_CONSOLE_XCSR:
    dl11_xcsr &= ~0x44;
    dl11_xcsr |= (value & 0x44);
    /* Send IRQ for transmission if it was enabled. */
    if (dl11_xcsr_get(DL11_XCSR_XMIT_INT_ENB)) {
      unibus_irq_set(DL11_VECTOR_CONSOLE_PRINTER, DL11_IRQ_PRIORITY);
    }
    break;

  case DL11_ADDRESS_CONSOLE_XBUF:
    if (dl11_send_hook != NULL) {
      (dl11_send_hook)(value & 0xFF);
    }
    /* Send IRQ after each transmission if enabled. */
    if (dl11_xcsr_get(DL11_XCSR_XMIT_INT_ENB)) {
      unibus_irq_set(DL11_VECTOR_CONSOLE_PRINTER, DL11_IRQ_PRIORITY);
    }
    break;
  }
}



static uint16_t dl11_read(uint32_t unibus_address)
{
  uint8_t byte;

  switch (unibus_address) {
  case DL11_ADDRESS_CONSOLE_RCSR:
    dl11_poll(); /* Additional poll to relax the host CPU for programs that
                    poll the RCSR register without using interrupts. */
    return dl11_rcsr & 0x8C0;

  case DL11_ADDRESS_CONSOLE_RBUF:
    if (dl11_recv_hook != NULL) {
      byte = (dl11_recv_hook)();
    } else {
      byte = 0;
    }
    dl11_rcsr_clr(DL11_RCSR_RCVR_DONE);
    return byte;

  case DL11_ADDRESS_CONSOLE_XCSR:
    return dl11_xcsr;
  }

  return 0;
}



void dl11_hook_register(dl11_send_hook_t send_hook,
  dl11_recv_hook_t recv_hook, dl11_poll_hook_t poll_hook,
  dl11_pause_hook_t pause_hook, dl11_resume_hook_t resume_hook)
{
  dl11_send_hook   = send_hook;
  dl11_recv_hook   = recv_hook;
  dl11_poll_hook   = poll_hook;
  dl11_pause_hook  = pause_hook;
  dl11_resume_hook = resume_hook;
}



void dl11_poll(void)
{
  if (dl11_poll_hook == NULL) {
    return;
  }

  if ((dl11_poll_hook)() == true) {
    dl11_rcsr_set(DL11_RCSR_RCVR_DONE);
    /* Send IRQ after each receive if enabled. */
    if (dl11_rcsr_get(DL11_RCSR_RCVR_INT_ENB)) {
      unibus_irq_set(DL11_VECTOR_CONSOLE_KEYBOARD, DL11_IRQ_PRIORITY);
    } else {
      unibus_irq_set(0, DL11_IRQ_PRIORITY);
    }
  }
}



void dl11_pause(void)
{
  if (dl11_pause_hook == NULL) {
    return;
  }

  (dl11_pause_hook)();
}



void dl11_resume(void)
{
  if (dl11_resume_hook == NULL) {
    return;
  }

  (dl11_resume_hook)();
}



void dl11_init(void)
{
  dl11_send_hook = NULL;
  dl11_recv_hook = NULL;
  dl11_poll_hook = NULL;
  dl11_pause_hook = NULL;
  dl11_resume_hook = NULL;

  unibus_read_hook_register(DL11_ADDRESS_CONSOLE_RCSR, dl11_read);
  unibus_read_hook_register(DL11_ADDRESS_CONSOLE_RBUF, dl11_read);
  unibus_read_hook_register(DL11_ADDRESS_CONSOLE_XCSR, dl11_read);
  unibus_read_hook_register(DL11_ADDRESS_CONSOLE_XBUF, dl11_read);
  unibus_write_hook_register(DL11_ADDRESS_CONSOLE_RCSR, dl11_write);
  unibus_write_hook_register(DL11_ADDRESS_CONSOLE_RBUF, dl11_write);
  unibus_write_hook_register(DL11_ADDRESS_CONSOLE_XCSR, dl11_write);
  unibus_write_hook_register(DL11_ADDRESS_CONSOLE_XBUF, dl11_write);

  /* Ready from the start to transmit. */
  dl11_xcsr_set(DL11_XCSR_XMIT_RDY);
}



