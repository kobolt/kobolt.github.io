#include "la36.h"
#include <ctype.h>
#include <errno.h>
#include <poll.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <termios.h>
#include <unistd.h>

#include "dl11.h"
#include "panic.h"

#define LA36_TIMEOUT_DEFAULT 1

#define la36_option_get(option) (la36_option & option)

static uint32_t la36_option;



void la36_send(uint8_t byte)
{
  byte &= 0x7F; /* 7-bit ASCII only. */

  if (la36_option_get(LA36_OPTION_EXIT_ON_BELL)) {
    if (byte == 0x07) {
      exit(EXIT_SUCCESS);
    }
  }

  if (isprint(byte) || isspace(byte)) {
    fputc(byte, stdout);
  }
}



uint8_t la36_recv(void)
{
  int c;

  c = fgetc(stdin);
  if (c == EOF) {
    exit(EXIT_SUCCESS);
  }

  if (la36_option_get(LA36_OPTION_AUTO_LF_TO_CR)) {
    if (c == 0x0A) {
      c= 0x0D;
    }
  }

  if (la36_option_get(LA36_OPTION_AUTO_UPPERCASE)) {
    c = toupper(c);
  }

  return c;
}



bool la36_poll(void)
{
  int result;
  struct pollfd fds[1];

  fds[0].fd = STDIN_FILENO;
  fds[0].events = POLLIN;

  if (la36_option_get(LA36_OPTION_NO_TIMEOUT)) {
    result = poll(fds, 1, 0);
  } else {
    result = poll(fds, 1, LA36_TIMEOUT_DEFAULT);
  }
  if (result > 0) {
    return true;
  } else if (result == -1) {
    if (errno != EINTR) {
      panic("poll() failed with errno: %d\n", errno);
    }
  }

  return false;
}



void la36_pause(void)
{
  /* Restore canonical mode and echo. */
  struct termios ts;
  tcgetattr(STDIN_FILENO, &ts);
  ts.c_lflag |= ICANON | ECHO;
  tcsetattr(STDIN_FILENO, TCSANOW, &ts);
}



void la36_resume(void)
{
  /* Turn off canonical mode and echo. */
  struct termios ts;
  tcgetattr(STDIN_FILENO, &ts);
  ts.c_lflag &= ~ICANON & ~ECHO;
  tcsetattr(STDIN_FILENO, TCSANOW, &ts);
}



void la36_init(uint32_t option)
{
  la36_option = option;

  atexit(la36_pause);
  la36_resume();

  /* Make stdout unbuffered. */
  setvbuf(stdout, NULL, _IONBF, 0);

  dl11_hook_register(la36_send, la36_recv, la36_poll, la36_pause, la36_resume);
}



