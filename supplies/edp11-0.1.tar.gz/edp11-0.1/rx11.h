#ifndef _RX11_H
#define _RX11_H

#include <stdio.h>

#define RX11_ADDRESS_RXCS 0777170
#define RX11_ADDRESS_RXDB 0777172

void rx11_init(void);
int rx11_load_floppy(int drive_unit, const char *filename);

#endif /* _RX11_H */
