#include "rl11.h"
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

#include "unibus.h"

#ifdef RL11_OLD_VERSION
#define RL11_VECTOR_DONE  0000330 /* MAINDEC-11-DZRLA-A-PB needs old vector. */
#else
#define RL11_VECTOR_DONE  0000160
#endif /* RL11_OLD_VERSION */

#define RL11_IRQ_PRIORITY 5

#ifdef RL11_OLD_VERSION
#define RL11_CYLINDERS   256 /* RL01 */
#else
#define RL11_CYLINDERS   512 /* RL02 */
#endif /* RL11_OLD_VERSION */

#define RL11_HEADS       2
#define RL11_SECTORS     40
#define RL11_SECTOR_SIZE 256
#define RL11_IMAGE_SIZE (RL11_CYLINDERS * \
                         RL11_HEADS * \
                         RL11_SECTORS * \
                         RL11_SECTOR_SIZE)
#define RL11_DRIVE_UNITS 4

#define RL11_FUNCTION_CODE_NO_OP         0
#define RL11_FUNCTION_CODE_WRITE_CHECK   1
#define RL11_FUNCTION_CODE_GET_STATUS    2
#define RL11_FUNCTION_CODE_SEEK          3
#define RL11_FUNCTION_CODE_READ_HEADER   4
#define RL11_FUNCTION_CODE_WRITE_DATA    5
#define RL11_FUNCTION_CODE_READ_DATA     6
#define RL11_FUNCTION_CODE_READ_DATA_WHC 7

#define RL11_CSR_DRDY 0
#define RL11_CSR_F0   1
#define RL11_CSR_F1   2
#define RL11_CSR_F2   3
#define RL11_CSR_BA16 4
#define RL11_CSR_BA17 5
#define RL11_CSR_IE   6
#define RL11_CSR_CRDY 7
#define RL11_CSR_DS0  8
#define RL11_CSR_DS1  9
#define RL11_CSR_E0   10
#define RL11_CSR_E1   11
#define RL11_CSR_E2   12
#define RL11_CSR_NXM  13
#define RL11_CSR_DE   14
#define RL11_CSR_ERR  15

#define RL11_DAR_STATUS_MARKER 0
#define RL11_DAR_STATUS_GS     1
#define RL11_DAR_STATUS_RST    3

#define RL11_DAR_SEEK_MARKER 0
#define RL11_DAR_SEEK_DIR    2
#define RL11_DAR_SEEK_HS     4
#define RL11_DAR_SEEK_DF0    7

#define RL11_DAR_DATA_SA0 0
#define RL11_DAR_DATA_HS  6
#define RL11_DAR_DATA_CA0 7

#define RL11_MPR_STATUS_STA  0
#define RL11_MPR_STATUS_STB  1
#define RL11_MPR_STATUS_STC  2
#define RL11_MPR_STATUS_BH   3
#define RL11_MPR_STATUS_HO   4
#define RL11_MPR_STATUS_CO   5
#define RL11_MPR_STATUS_HS   6
#define RL11_MPR_STATUS_DT   7
#define RL11_MPR_STATUS_DSE  8
#define RL11_MPR_STATUS_VC   9
#define RL11_MPR_STATUS_WGE  10
#define RL11_MPR_STATUS_SPE  11
#define RL11_MPR_STATUS_SKTO 12
#define RL11_MPR_STATUS_WL   13
#define RL11_MPR_STATUS_CHE  14
#define RL11_MPR_STATUS_WDE  15

#define rl11_csr_set(bit)  (rl11_csr |=  (1 << bit))
#define rl11_csr_clr(bit)  (rl11_csr &= ~(1 << bit))
#define rl11_csr_get(bit) ((rl11_csr >> bit) & 1)

#define rl11_dar_get(bit) ((rl11_dar >> bit) & 1)
#define rl11_mpr_set(bit)  (rl11_mpr |=  (1 << bit))

typedef enum {
  RL11_MPR_NEXT_NONE,
  RL11_MPR_NEXT_ZEROES,
  RL11_MPR_NEXT_CRC,
} rl11_mpr_next_t;

static rl11_mpr_next_t rl11_mpr_next;
static uint16_t rl11_crc16;

static uint16_t rl11_csr;
static uint16_t rl11_bar;
static uint16_t rl11_dar;
static uint16_t rl11_mpr;

static uint8_t rl11_sector;
static uint8_t rl11_head;
static uint16_t rl11_cylinder;
static uint8_t rl11_drive;
static uint8_t rl11_image[RL11_DRIVE_UNITS][RL11_IMAGE_SIZE];
static bool rl11_volume_check[RL11_DRIVE_UNITS];



static void rl11_transfer(void)
{
  uint8_t function;
  uint32_t index;
  uint16_t value;
  uint32_t unibus_address;
  uint32_t bytes;

  function = (rl11_csr >> RL11_CSR_F0) & 7;

  if (function != RL11_FUNCTION_CODE_READ_DATA_WHC) {
    rl11_cylinder = (rl11_dar >> RL11_DAR_DATA_CA0);
    rl11_head     =  rl11_dar_get(RL11_DAR_DATA_HS);
    rl11_sector   =  rl11_dar & 0x3F; /* RL11_DAR_DATA_SA0 */
  }

  if (rl11_sector >= RL11_SECTORS || rl11_cylinder >= RL11_CYLINDERS) {
    rl11_csr_set(RL11_CSR_E0); /* Header Not Found */
    rl11_csr_set(RL11_CSR_E2);
    rl11_csr_set(RL11_CSR_ERR);
    return;
  }

  index =  (rl11_cylinder * RL11_HEADS * RL11_SECTORS * RL11_SECTOR_SIZE);
  index += (rl11_head * RL11_SECTORS * RL11_SECTOR_SIZE);
  index += (rl11_sector * RL11_SECTOR_SIZE);

  unibus_address = rl11_bar;
  unibus_address |= (rl11_csr_get(RL11_CSR_BA16) << 16);
  unibus_address |= (rl11_csr_get(RL11_CSR_BA17) << 17);
  bytes = 0;
  while ((int16_t)rl11_mpr < 0) {
    if (index >= RL11_IMAGE_SIZE) {
      rl11_csr_set(RL11_CSR_E0); /* Header Not Found */
      rl11_csr_set(RL11_CSR_E2);
      rl11_csr_set(RL11_CSR_ERR);
      break;
    }

    if (function == RL11_FUNCTION_CODE_WRITE_DATA) {
      value = unibus_read_16(unibus_address);
      rl11_image[rl11_drive][index++] = value & 0xFF;
      rl11_image[rl11_drive][index++] = value >> 8;

    } else if (function == RL11_FUNCTION_CODE_READ_DATA ||
               function == RL11_FUNCTION_CODE_READ_DATA_WHC) {
      value  =  rl11_image[rl11_drive][index++];
      value |= (rl11_image[rl11_drive][index++] << 8);
      unibus_write_16(unibus_address, value);

    } else if (function == RL11_FUNCTION_CODE_WRITE_CHECK) {
      value  =  rl11_image[rl11_drive][index++];
      value |= (rl11_image[rl11_drive][index++] << 8);
      if (value != unibus_read_16(unibus_address)) {
        rl11_csr_set(RL11_CSR_E1); /* Write Check Error */
        rl11_csr_set(RL11_CSR_ERR);
      }
    }

    if (unibus_error_occured()) {
      rl11_csr_set(RL11_CSR_NXM); /* Non-Existent Memory */
      rl11_csr_set(RL11_CSR_ERR);
      unibus_error_reset();
      break;
    }

    unibus_address += 2;
    bytes += 2;
    if (bytes > RL11_SECTOR_SIZE) {
      bytes = 0;
      rl11_sector++;
      if (rl11_sector >= RL11_SECTORS) {
        rl11_sector = 0;
#ifdef RL11_OLD_VERSION
        rl11_csr_set(RL11_CSR_E0); /* Header Not Found */
        rl11_csr_set(RL11_CSR_E2);
        rl11_csr_set(RL11_CSR_ERR);
        break;
#endif /* RL11_OLD_VERSION */
      }
    }
    rl11_mpr++;
  }

#ifdef RL11_OLD_VERSION
  /* Write remaining parts of sector to zero. */
  if (function == RL11_FUNCTION_CODE_WRITE_DATA) {
    while (bytes < RL11_SECTOR_SIZE) {
      rl11_image[rl11_drive][index++] = 0;
      rl11_image[rl11_drive][index++] = 0;
      bytes += 2;
    }
  }
#endif /* RL11_OLD_VERSION */

  /* Increment BAR, BA16 and BA17. */
  rl11_bar = unibus_address & 0xFFFF;
  if ((unibus_address >> 16) & 1) {
    rl11_csr_set(RL11_CSR_BA16);
  } else {
    rl11_csr_clr(RL11_CSR_BA16);
  }
  if ((unibus_address >> 17) & 1) {
    rl11_csr_set(RL11_CSR_BA17);
  } else {
    rl11_csr_clr(RL11_CSR_BA17);
  }

  /* Increment sector part of DAR register. */
  if (function == RL11_FUNCTION_CODE_READ_DATA_WHC) {
    rl11_sector = rl11_dar & 0x3F; /* RL11_DAR_DATA_SA0 */
  }
  rl11_dar &= ~0x3F; /* RL11_DAR_DATA_SA0 */
  rl11_dar |= ((rl11_sector + 1) & 0x3F);
}



static void rl11_done(void)
{
  rl11_csr_set(RL11_CSR_CRDY);
  if (rl11_csr_get(RL11_CSR_IE)) {
    unibus_irq_set(RL11_VECTOR_DONE, RL11_IRQ_PRIORITY);
  } else {
    unibus_irq_set(0, RL11_IRQ_PRIORITY);
  }
}



static void rl11_crc16_update(uint8_t byte)
{
  int i;
  rl11_crc16 ^= byte;
  for(i = 0; i < 8; i++) {
    if (rl11_crc16 & 0x0001) {
      rl11_crc16 >>= 1;
      rl11_crc16 ^= 0xA001; /* Reverse 0x8005 */
    } else {
      rl11_crc16 >>= 1;
    }
  }
}



static void rl11_function(void)
{
  rl11_drive = rl11_csr_get(RL11_CSR_DS0) | (rl11_csr_get(RL11_CSR_DS1) << 1);

  switch ((rl11_csr >> RL11_CSR_F0) & 7) {
  case RL11_FUNCTION_CODE_NO_OP:
    rl11_done();
    break;

  case RL11_FUNCTION_CODE_WRITE_CHECK:
    rl11_transfer();
    rl11_done();
    break;

  case RL11_FUNCTION_CODE_GET_STATUS:
    if (rl11_dar_get(RL11_DAR_STATUS_MARKER) &&
        rl11_dar_get(RL11_DAR_STATUS_GS)) {
      if (rl11_dar_get(RL11_DAR_STATUS_RST)) {
        rl11_volume_check[rl11_drive] = false;
      }
      rl11_mpr = 0;
      if (rl11_volume_check[rl11_drive]) {
        rl11_mpr_set(RL11_MPR_STATUS_VC);
      }
      if (rl11_head) {
        rl11_mpr_set(RL11_MPR_STATUS_HS);
      }
      rl11_mpr_set(RL11_MPR_STATUS_DT); /* RL02 */
      rl11_mpr_set(RL11_MPR_STATUS_BH); /* Brush Home */
      rl11_mpr_set(RL11_MPR_STATUS_HO); /* Heads Out */
      rl11_mpr_set(RL11_MPR_STATUS_STA); /* Lock... */
      rl11_mpr_set(RL11_MPR_STATUS_STC); /* ...On */
    } else {
      rl11_csr_set(RL11_CSR_E0); /* Operation Incomplete */
      rl11_csr_clr(RL11_CSR_ERR);
    }
    rl11_done();
    break;

  case RL11_FUNCTION_CODE_SEEK:
    if (rl11_dar_get(RL11_DAR_SEEK_MARKER)) {
      rl11_head = rl11_dar_get(RL11_DAR_SEEK_HS);
      if (rl11_dar_get(RL11_DAR_SEEK_DIR)) {
        rl11_cylinder += (rl11_dar >> RL11_DAR_SEEK_DF0);
      } else {
        rl11_cylinder -= (rl11_dar >> RL11_DAR_SEEK_DF0);
      }
      if (rl11_cylinder >= RL11_CYLINDERS) {
        rl11_cylinder = RL11_CYLINDERS - 1;
      }
    }
    rl11_done();
    break;

  case RL11_FUNCTION_CODE_READ_HEADER:
    rl11_mpr = (rl11_cylinder << 7) | (rl11_head << 6) | rl11_sector;
    rl11_crc16 = 0;
    rl11_crc16_update(rl11_mpr & 0xFF);
    rl11_crc16_update(rl11_mpr >> 8);
    rl11_crc16_update(0);
    rl11_crc16_update(0);
    rl11_mpr_next = RL11_MPR_NEXT_ZEROES;
    /* Automatically seek to next sector. */
    rl11_sector++;
    if (rl11_sector >= RL11_SECTORS) {
      rl11_sector = 0;
    }
    rl11_done();
    break;

  case RL11_FUNCTION_CODE_WRITE_DATA:
    rl11_transfer();
    rl11_done();
    break;

  case RL11_FUNCTION_CODE_READ_DATA:
    rl11_transfer();
    rl11_done();
    break;

  case RL11_FUNCTION_CODE_READ_DATA_WHC:
    rl11_transfer();
    rl11_done();
    break;
  }
}



static void rl11_write(uint32_t unibus_address, uint16_t value)
{
  switch (unibus_address) {
  case RL11_ADDRESS_CSR:
    rl11_csr &= ~0x3FE;
    rl11_csr |= (value & 0x3FE);
    if (rl11_csr_get(RL11_CSR_CRDY) == 0) {
      rl11_csr_clr(RL11_CSR_E0);
      rl11_csr_clr(RL11_CSR_E1);
      rl11_csr_clr(RL11_CSR_E2);
      rl11_csr_clr(RL11_CSR_NXM);
      rl11_csr_clr(RL11_CSR_ERR);
      rl11_function();
    }
    break;

  case RL11_ADDRESS_BAR:
    rl11_bar = value & 0xFFFE;
    break;

  case RL11_ADDRESS_DAR:
    rl11_dar = value;
    break;

  case RL11_ADDRESS_MPR:
    rl11_mpr = value;
    break;
  }
}



static uint16_t rl11_read(uint32_t unibus_address)
{
  uint16_t value;

  switch (unibus_address) {
  case RL11_ADDRESS_CSR:
    return rl11_csr;

  case RL11_ADDRESS_BAR:
    return rl11_bar;

  case RL11_ADDRESS_DAR:
    return rl11_dar;

  case RL11_ADDRESS_MPR:
    value = rl11_mpr;
    switch (rl11_mpr_next) {
    case RL11_MPR_NEXT_ZEROES:
      rl11_mpr = 0;
      rl11_mpr_next = RL11_MPR_NEXT_CRC;
      break;

    case RL11_MPR_NEXT_CRC:
      rl11_mpr = rl11_crc16;
      rl11_mpr_next = RL11_MPR_NEXT_NONE;
      break;

    case RL11_MPR_NEXT_NONE:
    default:
      break;
    }
    return value;
  }

  return 0;
}



static void rl11_reset(void)
{
  rl11_csr = 0;
  rl11_bar = 0;
  rl11_dar = 0;
  rl11_mpr = 0;
  rl11_csr_set(RL11_CSR_CRDY);
  rl11_csr_set(RL11_CSR_DRDY);
}



void rl11_init(void)
{
  int i;
  int j;

  rl11_sector   = 0;
  rl11_head     = 0;
  rl11_cylinder = 0;
  rl11_drive    = 0;

  rl11_mpr_next = RL11_MPR_NEXT_NONE;
  rl11_crc16 = 0;

  for (i = 0; i < RL11_DRIVE_UNITS; i++) {
    for (j = 0; j < RL11_IMAGE_SIZE; j++) {
      rl11_image[i][j] = 0;
    }
    rl11_volume_check[i] = false;
  }

  unibus_read_hook_register(RL11_ADDRESS_CSR, rl11_read);
  unibus_read_hook_register(RL11_ADDRESS_BAR, rl11_read);
  unibus_read_hook_register(RL11_ADDRESS_DAR, rl11_read);
  unibus_read_hook_register(RL11_ADDRESS_MPR, rl11_read);
  unibus_write_hook_register(RL11_ADDRESS_CSR, rl11_write);
  unibus_write_hook_register(RL11_ADDRESS_BAR, rl11_write);
  unibus_write_hook_register(RL11_ADDRESS_DAR, rl11_write);
  unibus_write_hook_register(RL11_ADDRESS_MPR, rl11_write);
  unibus_reset_hook_register(rl11_reset);

  rl11_reset();
}



int rl11_load_disk(int drive_unit, const char *filename)
{
  FILE *fh;
  int c;
  int n;

  if (drive_unit >= RL11_DRIVE_UNITS) {
    fprintf(stdout, "Drive unit out of range: %d\n", drive_unit);
    return -2;
  }

  fh = fopen(filename, "rb");
  if (fh == NULL) {
    fprintf(stdout, "Error opening file: '%s'\n", filename);
    return -1;
  }

  n = 0;
  while ((c = fgetc(fh)) != EOF) {
    rl11_image[drive_unit][n] = c;
    n++;
    if (n >= RL11_IMAGE_SIZE) {
      break;
    }
  }

  rl11_volume_check[drive_unit] = true;
  fclose(fh);
  return 0;
}



