#include "common.h"
#include "object.h"
#include "map.h"
#include <math.h>

void tank_object_reset(object_t *to, short new_player,
                       float new_x, float new_y, long new_id)
{
  to->type = OBJECT_TYPE_TANK;
  to->x = new_x;
  to->y = new_y;
  to->id = new_id;
  to->tank.player_no = new_player;
  to->tank.body_angle = to->tank.cannon_angle = 0;
  to->tank.prev_x = new_x;
  to->tank.prev_y = new_y;
  to->tank.destroyed = 0;
}

void tank_object_move(object_t *to, int body_turning,
                      int cannon_turning, int belt_moving)
{
  if (to->tank.destroyed) {
    return;
  }

  if (body_turning > 0) {
    to->tank.body_angle -= 4;
    if (to->tank.body_angle < 0)
      to->tank.body_angle = 356;
    to->tank.cannon_angle -= 4;
    if (to->tank.cannon_angle < 0)
      to->tank.cannon_angle = 356;

  } else if (body_turning < 0) {
    to->tank.body_angle += 4;
    if (to->tank.body_angle >= 360)
      to->tank.body_angle = 0;
    to->tank.cannon_angle += 4;
    if (to->tank.cannon_angle >= 360)
      to->tank.cannon_angle = 0;
  }

  if (cannon_turning > 0) {
    to->tank.cannon_angle -= 4;
    if (to->tank.cannon_angle < 0)
      to->tank.cannon_angle = 356;

  } else if (cannon_turning < 0) {
    to->tank.cannon_angle += 4;
    if (to->tank.cannon_angle >= 360)
      to->tank.cannon_angle = 0;
  }

  if (belt_moving > 0) {
    to->tank.prev_x = to->x;
    to->tank.prev_y = to->y;
    to->x -= sin(to->tank.body_angle * (M_PI / 180)) * 3;
    to->y += cos(to->tank.body_angle * (M_PI / 180)) * 3;
  } else if (belt_moving < 0) {
    to->tank.prev_x = to->x;
    to->tank.prev_y = to->y;
    to->x += sin(to->tank.body_angle * (M_PI / 180));
    to->y -= cos(to->tank.body_angle * (M_PI / 180));
  }
}

int tank_object_collision_tank(object_t *to1, object_t *to2)
{
  /* Just using circle radius intersection! */
  float dist = sqrt((to1->x - to2->x) * (to1->x - to2->x) + 
                    (to1->y - to2->y) * (to1->y - to2->y));
  /* Reduced from 90.0 to 70.0 to allow closer movement. */
  return (dist < 70.0) ? 1 : 0;
}

int tank_object_collision_bullet(object_t *to, object_t *bo)
{
  int rel_x, rel_y;
  float angle_sin, angle_cos, local_x, local_y;

  if (to->tank.player_no == bo->bullet.player_no) {
    return 0; /* Ignore collisions against self! */
  }

  rel_x = bo->x - to->x;
  rel_y = bo->y - to->y;
  angle_sin = sin(to->tank.body_angle * (M_PI / 180));
  angle_cos = cos(to->tank.body_angle * (M_PI / 180));
  local_x = (angle_cos * rel_x) - (angle_sin * rel_y);
  local_y = (angle_sin * rel_x) + (angle_cos * rel_y);

  return (local_x >= -32 && local_x <= 32 &&
          local_y >= -32 && local_y <= 32) ? 1 : 0;
}

int tank_object_collision_map(object_t *to)
{
  int rel_x, rel_y, corner_x, corner_y;
  float angle_sin, angle_cos;

  /* Check if corners or points on sides intersect with a map wall. */
  for (rel_x = -32; rel_x <= 32; rel_x += 16) {
    for (rel_y = -32; rel_y <= 32; rel_y += 16) {
      angle_sin = sin(to->tank.body_angle * (M_PI / 180));
      angle_cos = cos(to->tank.body_angle * (M_PI / 180));
      corner_x = (int)((rel_x * angle_cos) - (rel_y * angle_sin)) + to->x;
      corner_y = (int)((rel_x * angle_sin) + (rel_y * angle_cos)) + to->y;

      /* Prevent leaving the screen or getting out of bounds first! */
      if (corner_x < 0 || corner_x >= SCREEN_WIDTH) {
        return 1;
      }
      if (corner_y < 0 || corner_y >= SCREEN_HEIGHT) {
        return 1;
      }
      /* Then check the actual map. */
      if (map_screen[corner_x][corner_y]) {
        return 1;
      }
    }
  }

  return 0;
}

