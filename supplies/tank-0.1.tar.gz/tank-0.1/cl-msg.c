#include "message.h"
#include "object.h"
#include "tank.h"
#include "common.h"
#include "map.h"
#include "sound.h"
#include <enet/enet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static ENetHost *client;
static ENetPeer *peer;

int message_open_connection(char *host, object_t *player_to)
{
  ENetAddress address;
  ENetEvent event;
  ENetPacket *packet;
  message_t *recv_msg, send_msg;

  if (enet_initialize() != 0) {
    fprintf(stderr, "Error: Unable to initalize ENet.\n");
    return -1;
  }
  atexit(enet_deinitialize);

  client = enet_host_create(NULL, 1, 0, 0, 0);
  if (client == NULL) {
    fprintf(stderr, "Error: Unable to create ENet client.\n");
    return -1;
  }

  enet_address_set_host(&address, host);
  address.port = NETWORK_PORT;
  peer = enet_host_connect(client, &address, 1, 0);
  if (peer == NULL) {
    fprintf(stderr, "Error: Unable to connect to host.\n");
    return -1;
  }

  if (enet_host_service(client, &event, 3000) > 0 &&
    event.type == ENET_EVENT_TYPE_CONNECT) {
    fprintf(stderr, "Info: Connected to server.\n");
  } else {
    enet_peer_reset(peer);
    fprintf(stderr, "Error: Timeout while waiting for connection.\n");
    return -1;
  }

  send_msg.type = MSG_TYPE_JOIN_REQ;
  packet = enet_packet_create(&send_msg, sizeof(message_t),
    ENET_PACKET_FLAG_RELIABLE);
  enet_peer_send(peer, 0, packet);
  enet_host_flush(client);

  while (enet_host_service(client, &event, 100) > 0) {
    switch (event.type) {
    case ENET_EVENT_TYPE_RECEIVE:
      if (event.packet->dataLength != sizeof(message_t))
        break; /* Bogus package, discard. */

      recv_msg = (message_t *)event.packet->data;
      switch (recv_msg->type) {
      case MSG_TYPE_JOIN_ACK:
        if (recv_msg->join_ack.player_no == -1) {
          fprintf(stderr, "Error: Could not join, server is full.\n");
          enet_packet_destroy(event.packet);
          return -1;
        }
        tank_object_reset(player_to, 
                          recv_msg->join_ack.player_no,
                          recv_msg->join_ack.start_x,
                          recv_msg->join_ack.start_y,
                          recv_msg->join_ack.tank_id);
        enet_packet_destroy(event.packet);
        return 0;

      default:
        break;
      }
      enet_packet_destroy(event.packet);
      break;

    default:
      break;
    }
  }

  fprintf(stderr, "Error: Did not receive join acknowledge.\n");
  return -1;
}

void message_close_connection(void)
{
  ENetEvent event;
  enet_peer_disconnect(peer, 0);

  while (enet_host_service(client, &event, 3000) > 0) {
    switch (event.type) {
    case ENET_EVENT_TYPE_RECEIVE:
      enet_packet_destroy(event.packet);
      break;

    case ENET_EVENT_TYPE_DISCONNECT:
      enet_host_destroy(client);
      return;

    default:
      break;
    }
  }

  enet_peer_reset(peer);
  enet_host_destroy(client);
}

int message_send_object(object_t *o)
{
  ENetPacket *packet;
  message_t msg;

  msg.type = MSG_TYPE_OBJECT;
  memcpy(&msg.object, o, sizeof(object_t));
  packet = enet_packet_create(&msg, sizeof(message_t),
    ENET_PACKET_FLAG_RELIABLE);
  enet_peer_send(peer, 0, packet);
  enet_host_flush(client);

  return 0;
}

void message_recv_objects(object_t *go, int *no_of_objects,
  object_t *player_to)
{
  int objects_deleted = 0;
  message_t *recv_msg, send_msg;
  ENetPacket *packet;
  ENetEvent event;

  send_msg.type = MSG_TYPE_GET_OBJ;
  packet = enet_packet_create(&send_msg, sizeof(message_t),
    ENET_PACKET_FLAG_RELIABLE);
  enet_peer_send(peer, 0, packet);
  enet_host_flush(client);

  /* Note that old data will be kept if times out... */
  while (enet_host_service(client, &event, CLIENT_RECV_TIMEOUT) > 0) {
    switch (event.type) {
    case ENET_EVENT_TYPE_RECEIVE:
      if (event.packet->dataLength != sizeof(message_t))
        break; /* Bogus package, discard. */

      recv_msg = (message_t *)event.packet->data;
      switch (recv_msg->type) {
      case MSG_TYPE_OBJECT:
        /* NOTE: All objects deleted every cycle to get fresh data. */
        if (! objects_deleted) {
          *no_of_objects = 0;
          objects_deleted = 1;
        }
        object_database_update(go, &recv_msg->object.object, no_of_objects);
        break;

      case MSG_TYPE_DESTROYED:
        player_to->tank.destroyed = 1;
        sound_play(SOUND_DESTROY);
        break;

      case MSG_TYPE_BULLET:
        sound_play(SOUND_BULLET);
        break;

      default:
        break;
      }
      enet_packet_destroy(event.packet);
      break;
    
    default:
      break;
    }
  }
}

void message_recv_map(void)
{
  message_t *recv_msg, send_msg;
  ENetPacket *packet;
  ENetEvent event;

  send_msg.type = MSG_TYPE_GET_MAP;
  packet = enet_packet_create(&send_msg, sizeof(message_t),
    ENET_PACKET_FLAG_RELIABLE);
  enet_peer_send(peer, 0, packet);
  enet_host_flush(client);

  while (enet_host_service(client, &event, 1000) > 0) {
    switch (event.type) {
    case ENET_EVENT_TYPE_RECEIVE:
      if (event.packet->dataLength != sizeof(message_t))
        break; /* Bogus package, discard. */

      recv_msg = (message_t *)event.packet->data;
      switch (recv_msg->type) {
      case MSG_TYPE_MAP_DATA:
        map_set_data_line(recv_msg->map.data, recv_msg->map.line_no);
        break;

      default:
        break;
      }
      enet_packet_destroy(event.packet);
      break;

    default:
      break;
    }

    if (map_all_data_gotten()) {
      break; /* Break out early if everything gotten. */
    }
  }
}

