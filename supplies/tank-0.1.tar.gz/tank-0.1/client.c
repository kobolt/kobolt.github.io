#include "cl-msg.h"
#include "object.h"
#include "graphics.h"
#include "tank.h"
#include "bullet.h"
#include "map.h"
#include "sound.h"
#include "common.h"
#include <SDL2/SDL.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int i;
  int no_of_objects = 0;
  int body_turning, cannon_turning, belt_moving;
  int bullet_cooldown = 0;

  SDL_Window *window;
  SDL_Renderer *renderer;
  SDL_Event event;
  Uint32 ticks;

  object_t player_tank;
  object_t game_objects[MAX_GAME_OBJECTS];
  object_t temp_object;

  if (argc != 2) {
    fprintf(stderr, "Usage: %s <server ip>\n", argv[0]);
    exit(EXIT_FAILURE);
  }

  if (message_open_connection(argv[1], &player_tank) != 0) {
    exit(EXIT_FAILURE);
  }

  if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) != 0) {
    fprintf(stderr, "Error: Unable to initalize SDL: %s\n", SDL_GetError());
    exit(EXIT_FAILURE);
  }
  atexit(SDL_Quit);

  if ((window = SDL_CreateWindow("Tank",
    SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
    SCREEN_WIDTH, SCREEN_HEIGHT, 0)) == NULL) {
    fprintf(stderr, "Error: Unable to set video mode: %s\n", SDL_GetError());
    exit(EXIT_FAILURE);
  }

  if ((renderer = SDL_CreateRenderer(window, -1, 0)) == NULL) {
    fprintf(stderr, "Error: Unable to create renderer: %s\n", SDL_GetError());
    exit(EXIT_FAILURE);
  }

  if (graphics_load(renderer) != 0) {
    exit(EXIT_FAILURE);
  }
  atexit(graphics_unload);

  if (sound_load() == 0) {
    atexit(sound_unload);
  }
  /* Can still run the game without sound... */

  message_recv_map();
  if (! map_all_data_gotten()) {
    fprintf(stderr, "Error: Unable to load map data from server!\n");
    exit(EXIT_FAILURE);
  }
  map_update_screen();

  graphics_prepare_map(renderer);

  body_turning = cannon_turning = belt_moving = 0;
  while (1) {
    ticks = SDL_GetTicks();

    if (SDL_PollEvent(&event) == 1) {
      switch (event.type) {
      case SDL_QUIT:
        message_close_connection();
        exit(EXIT_SUCCESS);
        break;

      case SDL_KEYDOWN:
        switch (event.key.keysym.sym) {
        case SDLK_LEFT:
          body_turning = 1;
          break;

        case SDLK_RIGHT:
          body_turning = -1;
          break;

        case SDLK_a:
          cannon_turning = 1;
          break;

        case SDLK_d:
          cannon_turning = -1;
          break;

        case SDLK_UP:
          belt_moving = 1;
          break;

        case SDLK_DOWN:
          belt_moving = -1;
          break;

        case SDLK_SPACE:
          if (! player_tank.tank.destroyed) {
            if (bullet_cooldown == 0) {
              bullet_object_create(&temp_object, &player_tank);
              message_send_object(&temp_object);
              bullet_cooldown = BULLET_COOLDOWN;
            }
          }
          break;

        default:
          break;
        }
        break;

      case SDL_KEYUP:
        switch (event.key.keysym.sym) {
        case SDLK_LEFT:
        case SDLK_RIGHT:
          body_turning = 0;
          break;

        case SDLK_a:
        case SDLK_d:
          cannon_turning = 0;
          break;

        case SDLK_UP:
        case SDLK_DOWN:
          belt_moving = 0;
          break;

        default:
          break;
        }
        break;

      default:
        continue;
      }
    }

    tank_object_move(&player_tank, body_turning, cannon_turning, belt_moving);

    if (bullet_cooldown > 0) {
      bullet_cooldown--;
    }

    message_send_object(&player_tank);
    message_recv_objects(game_objects, &no_of_objects, &player_tank);

    /* Check tank/tank collisions on the client side. */
    for (i = 0; i < no_of_objects; i++) {
      if (game_objects[i].type == OBJECT_TYPE_TANK &&
        game_objects[i].tank.player_no != player_tank.tank.player_no) {
        if (tank_object_collision_tank(&game_objects[i], &player_tank)) {
          /* Backtrack! */
          player_tank.x = player_tank.tank.prev_x;
          player_tank.y = player_tank.tank.prev_y;
        }
      }
    }

    /* Check tank/map collision on the client side. */
    if (tank_object_collision_map(&player_tank)) {
      /* Backtrack! */
      player_tank.x = player_tank.tank.prev_x;
      player_tank.y = player_tank.tank.prev_y;
    }

    graphics_draw_background(renderer);
    graphics_draw_map(renderer);

    /* Draw all other game objects. */
    for (i = 0; i < no_of_objects; i++) {
      switch (game_objects[i].type) {
      case OBJECT_TYPE_TANK:
        if (game_objects[i].tank.player_no != player_tank.tank.player_no)
          graphics_draw_tank(renderer, &game_objects[i]);
        break;
      case OBJECT_TYPE_BULLET:
        graphics_draw_bullet(renderer, &game_objects[i]);
        break;
      }
    }

    /* NOTE: Player tank drawn seperately,
       to get more fluid motion in case of server lag. */
    graphics_draw_tank(renderer, &player_tank);

    SDL_RenderPresent(renderer);

    /* Limit to 50 ticks. */
    while (ticks + 50 > SDL_GetTicks())
      SDL_Delay(1);
  }

  message_close_connection();
  return EXIT_SUCCESS;
}

