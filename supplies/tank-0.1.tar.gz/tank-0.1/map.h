#ifndef _MAP_H
#define _MAP_H

#include "common.h"

extern char map_screen[SCREEN_WIDTH][SCREEN_HEIGHT];

void map_update_screen(void);
void map_update_player_spawn(void);
int map_load_from_file(char *filename);
int map_set_data_line(char *data, int line_no);
char *map_get_data_line(int line_no);
int map_all_data_gotten(void);
void map_player_spawn(short *x, short *y);

#endif /* _MAP_H */
