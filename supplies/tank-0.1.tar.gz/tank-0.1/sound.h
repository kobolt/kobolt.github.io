#ifndef _SOUND_H
#define _SOUND_H

typedef enum {
  SOUND_BULLET,
  SOUND_DESTROY,
} sound_t;

int sound_load(void);
void sound_unload(void);
void sound_play(sound_t sample_no);

#endif /* _SOUND_H */
