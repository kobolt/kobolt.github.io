#ifndef _OBJECT_H
#define _OBJECT_H

typedef enum {
  OBJECT_TYPE_TANK   = 1,
  OBJECT_TYPE_BULLET = 2,
} object_type_t;

typedef struct object_tank_s {
  short body_angle, cannon_angle;
  short player_no; /* Player controlling this tank. */
  float prev_x, prev_y; /* To be used in case of collision and backtracking. */
  int destroyed;
} object_tank_t;

typedef struct object_bullet_s {
  short player_no; /* Player who fired the bullet. */
  short angle;
} object_bullet_t;

typedef struct object_s {
  long id;
  float x, y;
  object_type_t type;
  union {
    object_tank_t tank;
    object_bullet_t bullet;
  };
} object_t;

void object_database_update(object_t *database, object_t *new,
  int *no_of_objects);
void object_database_remove(object_t *database, int *no_of_objects, long id);

#endif /* _OBJECT_H */
