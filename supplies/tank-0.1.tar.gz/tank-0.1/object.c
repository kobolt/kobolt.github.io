#include "common.h"
#include "object.h"
#include <stdio.h>
#include <string.h>

void object_database_update(object_t *database, object_t *new,
  int *no_of_objects)
{
  int i;

  /* Check if object already exists, then just update. */
  for (i = 0; i < *no_of_objects; i++) {
    if (database[i].id == new->id) {
      memcpy(&database[i], new, sizeof(object_t));
      return;
    }
  }

  /* Add new object... */
  if (*no_of_objects >= MAX_GAME_OBJECTS) {
    fprintf(stderr, "Warning: Game object database full.\n");
    return;
  }
  memcpy(&database[*no_of_objects], new, sizeof(object_t));
  *no_of_objects += 1;
}

void object_database_remove(object_t *database, int *no_of_objects, long id)
{
  int i;

  for (i = 0; i < *no_of_objects; i++) {
    if (database[i].id == id)
      break;
  }

  if (i == *no_of_objects)
    return; /* Not found. */

  for (; i < *no_of_objects; i++) {
    if (i < MAX_GAME_OBJECTS)
      memcpy(&database[i], &database[i + 1], sizeof(object_t));
  }
  *no_of_objects -= 1;
}

