#ifndef _CL_MSG_H
#define _CL_MSG_H

#include "object.h"

int message_open_connection(char *host, object_t *player_to);
void message_close_connection(void);
int message_send_object(object_t *o);
void message_recv_objects(object_t *go, int *no_of_objects, 
  object_t *player_to);
void message_recv_map(void);

#endif /* _CL_MSG_H */
