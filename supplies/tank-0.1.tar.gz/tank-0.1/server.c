#include "object.h"
#include "message.h"
#include "common.h"
#include "bullet.h"
#include "tank.h"
#include "map.h"
#include <enet/enet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>

typedef struct peer_data_s {
  int player_no;
  long tank_id;
  int health;
  ENetPeer *peer; /* Reverse reference! */
} peer_data_t;

int main(int argc, char *argv[])
{
  int i, j, k;
  ENetAddress address;
  ENetHost *server;
  ENetEvent event;
  ENetPacket *packet;
  message_t *recv_msg, send_msg;
  peer_data_t *peer;
  char *filename;

  object_t game_objects[MAX_GAME_OBJECTS]; /* Master database. */
  int no_of_objects = 0;
  long id_counter = 1;

  int new_player_no;
  peer_data_t *player_peer[MAX_PLAYERS] = {NULL};

  srandom(time(NULL));

  if (argc >= 2) {
    filename = argv[1];
  } else {
    filename = "map.txt"; /* Default */
  }

  if (map_load_from_file(filename) != 0) {
    fprintf(stderr, "Error: Unable to load map file: %s\n", filename);
    exit(EXIT_FAILURE);
  }
  map_update_screen();
  map_update_player_spawn();

  if (enet_initialize() != 0) {
    fprintf(stderr, "Error: Unable to initalize ENet.\n");
    exit(EXIT_FAILURE);
  }
  atexit(enet_deinitialize);

  address.host = ENET_HOST_ANY;
  address.port = NETWORK_PORT;
  /* Adding two to max players to allow for two additional peers to be able
     to connect and see that the server is full. Otherwise, it will just
     look like there is no connection to the server at all. */
  server = enet_host_create(&address, MAX_PLAYERS + 2, 0, 0, 0);
  if (server == NULL) {
    fprintf(stderr, "Error: Unable to create ENet server.\n");
    exit(EXIT_FAILURE);
  }

  while (1) {

    while (enet_host_service(server, &event, 5) > 0) {
      switch (event.type) {
      case ENET_EVENT_TYPE_CONNECT:
        fprintf(stderr, "New connection from: %d.%d.%d.%d\n",
          event.peer->address.host       & 0xff,
          event.peer->address.host >> 8  & 0xff,
          event.peer->address.host >> 16 & 0xff,
          event.peer->address.host >> 24 & 0xff);

        peer = (peer_data_t *)malloc(sizeof(peer_data_t));
        peer->player_no = -1;
        peer->peer = event.peer;
        event.peer->data = peer;
        break;

      case ENET_EVENT_TYPE_DISCONNECT:
        peer = event.peer->data;
        fprintf(stderr, "P%d: Disconnected\n", peer->player_no);
        object_database_remove(game_objects, &no_of_objects, peer->tank_id);
        player_peer[peer->player_no] = NULL;

        free(event.peer->data);
        event.peer->data = NULL;
        break;

      case ENET_EVENT_TYPE_RECEIVE:
        if (event.packet->dataLength != sizeof(message_t))
          break; /* Bogus package, discard. */

        recv_msg = (message_t *)event.packet->data;
        switch (recv_msg->type) {
        case MSG_TYPE_JOIN_REQ:
          send_msg.type = MSG_TYPE_JOIN_ACK;

          new_player_no = 0;
          while (player_peer[new_player_no] != NULL) {
            new_player_no++;
            if (new_player_no >= MAX_PLAYERS) {
              break;
            }
          }

          if (new_player_no >= MAX_PLAYERS)
            send_msg.join_ack.player_no = -1; /* Server full. */
          else {
            player_peer[new_player_no] = event.peer->data;
            peer = event.peer->data;
            peer->player_no = new_player_no;
            peer->tank_id = id_counter++;
            peer->health = PLAYER_START_HEALTH;
            fprintf(stderr, "P%d: Joined, Tank ID: %ld\n",
              peer->player_no, peer->tank_id);

            send_msg.join_ack.player_no = peer->player_no;
            send_msg.join_ack.tank_id = peer->tank_id;

            /* Prevent spawning on another tank/bullet! */
            object_t temp_object;
            bool occupied;
            do {
              occupied = false;
              map_player_spawn(&send_msg.join_ack.start_x,
                               &send_msg.join_ack.start_y);
              tank_object_reset(&temp_object, -1,
                send_msg.join_ack.start_x, send_msg.join_ack.start_y, -1);

              for (i = 0; i < no_of_objects; i++) {
                switch (game_objects[i].type) {
                case OBJECT_TYPE_TANK:
                  if (tank_object_collision_tank(&temp_object,
                    &game_objects[i])) {
                    occupied = true;
                  }
                  break;
                case OBJECT_TYPE_BULLET:
                  if (tank_object_collision_bullet(&temp_object,
                      &game_objects[i])) {
                    occupied = true;
                  }
                  break;
                }
              }
            } while (occupied);
          }
          packet = enet_packet_create(&send_msg, sizeof(message_t),
            ENET_PACKET_FLAG_RELIABLE);
          enet_peer_send(event.peer, 0, packet);
          enet_host_flush(server);
          break;

        case MSG_TYPE_GET_OBJ:
          send_msg.type = MSG_TYPE_OBJECT;
          for (i = 0; i < no_of_objects; i++) {
            memcpy(&send_msg.object, &game_objects[i], sizeof(object_t));
            packet = enet_packet_create(&send_msg, sizeof(message_t),
              ENET_PACKET_FLAG_RELIABLE);
            enet_peer_send(event.peer, 0, packet);
          }
          enet_host_flush(server);
          break;

        case MSG_TYPE_OBJECT:
          if (recv_msg->object.object.type == OBJECT_TYPE_BULLET) {
            recv_msg->object.object.id = id_counter++;

            for (i = 0; i < MAX_PLAYERS; i++) {
              if (player_peer[i] != NULL) {
                send_msg.type = MSG_TYPE_BULLET;
                packet = enet_packet_create(&send_msg,
                  sizeof(message_t), ENET_PACKET_FLAG_RELIABLE);
                enet_peer_send(player_peer[i]->peer, 0, packet);
                enet_host_flush(server);
              }
            }
          }
          object_database_update(game_objects, &recv_msg->object.object,
            &no_of_objects);
          break;

        case MSG_TYPE_GET_MAP:
          send_msg.type = MSG_TYPE_MAP_DATA;
          send_msg.map.line_no = 0;
          while (map_get_data_line(send_msg.map.line_no) != NULL) {
            strncpy(send_msg.map.data, 
              map_get_data_line(send_msg.map.line_no), MAX_MAP_DATA);
            packet = enet_packet_create(&send_msg, sizeof(message_t),
              ENET_PACKET_FLAG_RELIABLE);
            enet_peer_send(event.peer, 0, packet);
            send_msg.map.line_no++;
          }
          enet_host_flush(server);
          break;

        default:
          break; /* Server should not "receive" the other types! */
        }

        enet_packet_destroy(event.packet);
        break;

      default:
        break;
      }
    }

    /* Check bullets on the server side. */
    for (i = 0; i < no_of_objects; i++) {
      if (game_objects[i].type == OBJECT_TYPE_BULLET) {
        if (bullet_object_out_of_range(&game_objects[i])) {
          object_database_remove(game_objects, &no_of_objects,
            game_objects[i].id);
        } else {
          /* Check for bullet/tank collisions. */
          for (j = 0; j < no_of_objects; j++) {
            if (game_objects[j].type == OBJECT_TYPE_TANK) {
              if (tank_object_collision_bullet(&game_objects[j], 
                  &game_objects[i])) {
                object_database_remove(game_objects, &no_of_objects,
                  game_objects[i].id);

                for (k = 0; k < MAX_PLAYERS; k++) {
                  if (player_peer[k] != NULL) {
                    if (game_objects[j].id == player_peer[k]->tank_id) {
                      player_peer[k]->health--;
                      /* Inform player that it got destroyed. */
                      if (player_peer[k]->health <= 0) {
                        fprintf(stderr, "P%d: Destroyed\n",
                          player_peer[k]->player_no);
                        send_msg.type = MSG_TYPE_DESTROYED;
                        packet = enet_packet_create(&send_msg,
                          sizeof(message_t), ENET_PACKET_FLAG_RELIABLE);
                        enet_peer_send(player_peer[k]->peer, 0, packet);
                        enet_host_flush(server);
                      }
                    }
                  }
                }
              }
            }
          }
          bullet_object_move(&game_objects[i]);
        }
      }
    }
  }

  enet_host_destroy(server);
  return EXIT_SUCCESS;
}

