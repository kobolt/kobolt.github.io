#ifndef _GRAPHICS_H
#define _GRAPHICS_H

#include <SDL2/SDL.h>

int graphics_load(SDL_Renderer *renderer);
void graphics_unload(void);
void graphics_draw_background(SDL_Renderer *renderer);
void graphics_draw_tank(SDL_Renderer *renderer, object_t *to);
void graphics_draw_bullet(SDL_Renderer *renderer, object_t *bo);
int graphics_prepare_map(SDL_Renderer *renderer);
void graphics_draw_map(SDL_Renderer *renderer);

#endif /* _GRAPHICS_H */
