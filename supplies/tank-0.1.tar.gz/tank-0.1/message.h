#ifndef _MESSAGE_H
#define _MESSAGE_H

#include "object.h"

#define MAX_MAP_DATA 65 /* One line of data and terminator. */

typedef enum {
  MSG_TYPE_JOIN_REQ  = 1, /* Join request to server. */
  MSG_TYPE_JOIN_ACK  = 2, /* Join request acknowledge from server. */
  MSG_TYPE_GET_OBJ   = 3, /* Request to get "all" game objects. */
  MSG_TYPE_OBJECT    = 4, /* Game objects, back and forth. */
  MSG_TYPE_GET_MAP   = 5, /* Request map data to for client to draw. */
  MSG_TYPE_MAP_DATA  = 6, /* Map data reply. (Positions of walls, etc.) */
  MSG_TYPE_DESTROYED = 7, /* Player was destroyed. */
  MSG_TYPE_BULLET    = 8, /* Bullet appeared, to use for sound effects. */
} msg_type_t;

typedef struct msg_join_ack_s {
  short player_no; /* Player number, representing color of the tank actually. */
  long tank_id;    /* Gameobject ID assigned by server. */
  short start_x;
  short start_y;
} msg_join_ack_t;

typedef struct msg_object_s {
  object_t object;
} msg_object_t;

typedef struct msg_map_s {
  int line_no;
  char data[MAX_MAP_DATA];
} msg_map_t;

typedef struct message_s {
  msg_type_t type;
  union {
    msg_join_ack_t join_ack;
    msg_object_t object;
    msg_map_t map;
  };
} message_t;

#endif /* _MESSAGE_H */
