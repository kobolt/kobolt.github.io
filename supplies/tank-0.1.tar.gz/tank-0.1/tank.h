#ifndef _TANK_H
#define _TANK_H

#include "object.h"

void tank_object_reset(object_t *to, short new_player,
                       float new_x, float new_y, long new_id);
void tank_object_move(object_t *to, int body_turning,
                      int cannon_turning, int belt_moving);
int tank_object_collision_tank(object_t *to1, object_t *to2);
int tank_object_collision_bullet(object_t *to, object_t *bo);
int tank_object_collision_map(object_t *to);

#endif /* _TANK_H */
