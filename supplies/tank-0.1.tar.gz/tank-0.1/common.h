#ifndef _COMMON_H
#define _COMMON_H

/* Common definitions for both server and clients. */

#include "object.h"

#define MAX_GAME_OBJECTS 256
#define MAX_PLAYERS 6

#define NETWORK_PORT 65032

#define SCREEN_WIDTH 1024
#define SCREEN_HEIGHT 768

#define PLAYER_START_HEALTH 5
#define BULLET_COOLDOWN 50

#define CLIENT_RECV_TIMEOUT 20

#endif /* _COMMON_H */
