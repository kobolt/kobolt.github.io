#include "object.h"
#include "common.h"
#include "map.h"
#include <math.h>

/* Used by the client to create a new bullet to send to server. */
void bullet_object_create(object_t *bo, object_t *to)
{
  bo->type = OBJECT_TYPE_BULLET;
  bo->id = -1; /* Must be created by the server later. */
  bo->bullet.angle = to->tank.cannon_angle;
  bo->bullet.player_no = to->tank.player_no;
  bo->x = to->x;
  bo->y = to->y;

  /* Compensate with the length of the tank cannon nozzle. */
  bo->x -= sin(bo->bullet.angle * (M_PI / 180)) * 42;
  bo->y += cos(bo->bullet.angle * (M_PI / 180)) * 42;
}

/* Used by the server to move the bullet each time-slice. */
void bullet_object_move(object_t *bo)
{
  bo->x -= sin(bo->bullet.angle * (M_PI / 180)) * 5;
  bo->y += cos(bo->bullet.angle * (M_PI / 180)) * 5;
}

int bullet_object_out_of_range(object_t *bo)
{
  int x, y;

  x = (int)bo->x;
  y = (int)bo->y;

  if (x < 0)
    return 1;
  if (y < 0)
    return 1;
  if (x >= SCREEN_WIDTH)
    return 1;
  if (y >= SCREEN_HEIGHT)
    return 1;
  if (map_screen[x][y]) { /* Collision against map wall. */
    return 1;
  }

  return 0;
}

