#include "common.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define MAP_BLOCK_SIZE 16
#define MAP_WIDTH (SCREEN_WIDTH / MAP_BLOCK_SIZE)
#define MAP_HEIGHT (SCREEN_HEIGHT / MAP_BLOCK_SIZE)

#define MAP_MAX_PLAYER_SPAWN 16

typedef struct pos_s {
  short x;
  short y;
} pos_t;

char map_screen[SCREEN_WIDTH][SCREEN_HEIGHT] = {0}; /* Graphics/Collision */
static char map_data[MAP_HEIGHT][MAP_WIDTH] = {0}; /* File/Transfer */
static int map_data_gotten[MAP_HEIGHT] = {0}; /* Transfer Status */
static pos_t player_spawn[MAP_MAX_PLAYER_SPAWN] = {0};
static int player_spawn_total = 0;

void map_update_screen(void)
{
  int x, y;
  char c;

  for (x = 0; x < SCREEN_WIDTH; x++) {
    for (y = 0; y < SCREEN_HEIGHT; y++) {
      c = map_data[y / MAP_BLOCK_SIZE][x / MAP_BLOCK_SIZE];
      if (c == '#') {
        map_screen[x][y] = 1;
      } else {
        map_screen[x][y] = 0;
      }
    }
  }
}

void map_update_player_spawn(void)
{
  int h, w;

  player_spawn_total = 0;
  for (h = 0; h < MAP_HEIGHT; h++) {
    for (w = 0; w < MAP_WIDTH; w++) {
      if (map_data[h][w] == 'T') {
        player_spawn[player_spawn_total].x = w * MAP_BLOCK_SIZE;
        player_spawn[player_spawn_total].y = h * MAP_BLOCK_SIZE;
        player_spawn_total++;
        if (player_spawn_total >= MAP_MAX_PLAYER_SPAWN) {
          return;
        }
      }
    }
  }
}

/* On the server. */
int map_load_from_file(char *filename)
{
  int n;
  FILE *fh;
  char buffer[MAP_WIDTH + 3]; /* Allow for CR/LF and terminator. */

  fh = fopen(filename, "r");
  if (fh == NULL) {
    return -1;
  }

  n = 0;
  while (fgets(buffer, sizeof(buffer), fh) != NULL) {
    strncpy(map_data[n], buffer, MAP_WIDTH);
    n++;
    if (n >= MAP_HEIGHT) {
      break;
    }
  }

  fclose(fh);
  return 0;
}

/* On the clients. */
int map_set_data_line(char *data, int line_no)
{
  if (line_no < 0 || line_no >= MAP_HEIGHT) {
    return -1;
  } else {
    strncpy(map_data[line_no], data, MAP_WIDTH);
    map_data_gotten[line_no] = 1;
    return 0;
  }
}

char *map_get_data_line(int line_no)
{
  if (line_no < 0 || line_no >= MAP_HEIGHT) {
    return NULL;
  } else {
    return &map_data[line_no][0];
  }
}

int map_all_data_gotten(void)
{
  int line_no;
  for (line_no = 0; line_no < MAP_HEIGHT; line_no++) {
    if (! map_data_gotten[line_no]) {
      return 0;
    }
  }
  return 1;
}

void map_player_spawn(short *x, short *y)
{
  int spawn;
  spawn = random() % player_spawn_total;
  *x = player_spawn[spawn].x;
  *y = player_spawn[spawn].y;
}

