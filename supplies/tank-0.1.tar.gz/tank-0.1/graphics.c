#include <SDL2/SDL.h>
#include "object.h"
#include "map.h"
#include "common.h"

static SDL_Texture *map_texture;
static SDL_Texture *tank_body[MAX_PLAYERS], *tank_cannon[MAX_PLAYERS];

static int load_texture(SDL_Texture **texture, const char *filename,
  SDL_Renderer *renderer)
{
  SDL_Surface *temp;
  Uint32 colorkey;

  if ((temp = SDL_LoadBMP(filename)) == NULL) {
    fprintf(stderr, "Error: Unable to load graphics file '%s': %s\n",
      filename, SDL_GetError());
    return -1;
  }

  colorkey = SDL_MapRGB(temp->format, 0x11, 0x11, 0x11);
  SDL_SetColorKey(temp, SDL_TRUE, colorkey);

  if ((*texture = SDL_CreateTextureFromSurface(renderer, temp)) == NULL) {
    fprintf(stderr, "Error: Unable to create texture from file '%s': %s\n",
      filename, SDL_GetError());
    SDL_FreeSurface(temp);
    return -1;
  }

  SDL_FreeSurface(temp);
  return 0;
}

int graphics_load(SDL_Renderer *renderer)
{
  int i;
  char filename[32];

  for (i = 0; i < MAX_PLAYERS; i++) {
    snprintf(filename, sizeof(filename),
      "graphics/player-%d-body.bmp", i + 1);
    if (load_texture(&tank_body[i], filename, renderer) != 0)
      return -1;

    snprintf(filename, sizeof(filename),
      "graphics/player-%d-cannon.bmp", i + 1);
    if (load_texture(&tank_cannon[i], filename, renderer) != 0)
      return -1;
  }

  return 0;
}

void graphics_unload(void)
{
  int i;

  for (i = 0; i < MAX_PLAYERS; i++) {
    SDL_DestroyTexture(tank_body[i]);
    SDL_DestroyTexture(tank_cannon[i]);
  }

  SDL_DestroyTexture(map_texture);
}



void graphics_draw_background(SDL_Renderer *renderer)
{
  SDL_Rect rect;

  rect.x = 0;
  rect.y = 0;
  rect.w = SCREEN_WIDTH;
  rect.h = SCREEN_HEIGHT;

  SDL_SetRenderDrawColor(renderer, 0xbb, 0x88, 0x44, 0xff);
  SDL_RenderFillRect(renderer, &rect);
}

void graphics_draw_tank(SDL_Renderer *renderer, object_t *to)
{
  SDL_Rect src, dst;

  src.w = src.h = dst.w = dst.h = 90;
  dst.x = to->x - 45; 
  dst.y = to->y - 45;
  src.x = ((to->tank.body_angle / 4) % 9) * 90;
  src.y = ((to->tank.body_angle / 4) / 9) * 90;
  SDL_RenderCopy(renderer, tank_body[to->tank.player_no], &src, &dst);

  if (! to->tank.destroyed) {
    src.w = src.h = dst.w = dst.h = 84;
    dst.x = to->x - 42; 
    dst.y = to->y - 42;
    src.x = ((to->tank.cannon_angle / 4) % 9) * 84;
    src.y = ((to->tank.cannon_angle / 4) / 9) * 84;
    SDL_RenderCopy(renderer, tank_cannon[to->tank.player_no], &src, &dst);
  }
}

void graphics_draw_bullet(SDL_Renderer *renderer, object_t *bo)
{
  SDL_Rect rect;

  rect.x = bo->x - 4;
  rect.y = bo->y - 4;
  rect.w = rect.h = 8;

  SDL_SetRenderDrawColor(renderer, 0x00, 0x00, 0x00, 0xff);
  SDL_RenderFillRect(renderer, &rect);
}

int graphics_prepare_map(SDL_Renderer *renderer)
{
  SDL_Surface *map_surface;
  Uint32 color, transparent;
  SDL_Rect rect;

  if ((map_surface = SDL_CreateRGBSurface(0,
    SCREEN_WIDTH, SCREEN_HEIGHT, 24, 0, 0, 0, 0)) == NULL) {
    fprintf(stderr, "Error: Unable to create surface for map: %s\n",
      SDL_GetError());
    return -1;
  }

  color = SDL_MapRGB(map_surface->format, 0x22, 0x22, 0x22);
  transparent = SDL_MapRGB(map_surface->format, 0x11, 0x11, 0x11);
  SDL_SetColorKey(map_surface, SDL_TRUE, transparent);

  rect.w = rect.h = 1;
  for (rect.x = 0; rect.x < SCREEN_WIDTH; rect.x++) {
    for (rect.y = 0; rect.y < SCREEN_HEIGHT; rect.y++) {
      if (map_screen[rect.x][rect.y]) {
        SDL_FillRect(map_surface, &rect, color);
      } else {
        SDL_FillRect(map_surface, &rect, transparent);
      }
    }
  }

  if ((map_texture = SDL_CreateTextureFromSurface(renderer,
    map_surface)) == NULL) {
    SDL_FreeSurface(map_surface);
    fprintf(stderr, "Error: Unable to create texture for map: %s\n",
      SDL_GetError());
    return -1;
  }
  SDL_FreeSurface(map_surface);

  return 0;
}

void graphics_draw_map(SDL_Renderer *renderer)
{
  SDL_Rect src, dst;
  src.w = dst.w = SCREEN_WIDTH;
  src.h = dst.h = SCREEN_HEIGHT;
  src.x = src.y = dst.x = dst.y = 0;

  SDL_RenderCopy(renderer, map_texture, &src, &dst);
}

