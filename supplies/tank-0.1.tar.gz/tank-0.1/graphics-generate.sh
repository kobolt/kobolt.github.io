#!/bin/sh

mkdir graphics || exit 1
cd graphics || exit 1

function rotate
{
  cp "$1" temp-00.bmp
  for r in `seq -w 4 4 356`; do
    echo "$1 : $r degrees"
    convert temp-00.bmp -background '#111111' -rotate $r \
      -define bmp:format=bmp3 -gravity center -extent "$2" temp-$r.bmp
  done
}

for p in `seq 1 6`; do
  # Body
  rotate ../graphics-src/base-player-$p-body.bmp 90x90
  montage `ls temp-*.bmp` -mode Concatenate -tile 9x10 \
    -define bmp:format=bmp3 player-$p-body.bmp
  rm -f temp-*.bmp

  # Cannon
  rotate ../graphics-src/base-player-$p-cannon.bmp 84x84
  montage `ls temp-*.bmp` -mode Concatenate -tile 9x10 \
    -define bmp:format=bmp3 player-$p-cannon.bmp
  rm -f temp-*.bmp
done

