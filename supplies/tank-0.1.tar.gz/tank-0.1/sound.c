#include <SDL2/SDL.h>
#include "sound.h"

typedef struct sound_sample_s {
  Uint8 *buf;
  Uint32 len;
  SDL_AudioSpec spec;
  SDL_AudioDeviceID dev;
} sound_sample_t;

static sound_sample_t bullet = {0};
static sound_sample_t destroy = {0};

static int sound_load_internal(char *filename, sound_sample_t *sample)
{
  if (SDL_LoadWAV(filename,
    &sample->spec, &sample->buf, &sample->len) == NULL) {
    fprintf(stderr, "Error: Unable to open sound file: %s\n", SDL_GetError());
    return -1;
  }

  sample->dev = SDL_OpenAudioDevice(NULL, 0, &sample->spec,
    NULL, SDL_AUDIO_ALLOW_FORMAT_CHANGE);
  if (sample->dev == 0) {
    SDL_FreeWAV(sample->buf);
    return -1;
  }

  /* Always left unpaused and playing silence if nothing happens. */
  SDL_PauseAudioDevice(sample->dev, 0);
  return 0;
}

int sound_load(void)
{
  if (sound_load_internal("sound/bullet.wav", &bullet) != 0) {
    return -1;
  }
  if (sound_load_internal("sound/destroy.wav", &destroy) != 0) {
    SDL_CloseAudioDevice(bullet.dev);
    SDL_FreeWAV(bullet.buf);
    return -1;
  }
  return 0;
}

void sound_unload(void)
{
  SDL_CloseAudioDevice(bullet.dev);
  SDL_CloseAudioDevice(destroy.dev);
  SDL_FreeWAV(bullet.buf);
  SDL_FreeWAV(destroy.buf);
}

void sound_play(sound_t sample_no)
{
  sound_sample_t *sample;

  switch (sample_no) {
  case SOUND_BULLET:
    sample = &bullet;
    break;
  case SOUND_DESTROY:
    sample = &destroy;
    break;
  }

  if (sample->buf == NULL) {
    return; /* Sounds not loaded? */
  }

  SDL_QueueAudio(sample->dev, sample->buf, sample->len);
}

