#ifndef _BULLET_H
#define _BULLET_H

#include "object.h"

void bullet_object_create(object_t *bo, object_t *to);
void bullet_object_move(object_t *bo);
int bullet_object_out_of_range(object_t *bo);

#endif /* _BULLET_H */
